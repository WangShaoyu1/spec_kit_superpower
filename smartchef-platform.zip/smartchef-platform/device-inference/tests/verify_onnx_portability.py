"""跨平台 ONNX 产物最小验证脚本（Python 侧 + 设备侧约定）。

用法:
  python verify_onnx_portability.py --model path/to/model.onnx

说明:
- 该脚本使用 onnxruntime CPU EP 加载模型，模拟设备端最小加载链路。
- C++ 设备侧请复用同一 ONNX 文件与输入输出名，确保二进制兼容。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np


def _build_inputs(session: object, seq_len: int) -> dict[str, np.ndarray]:
    input_names = {item.name for item in session.get_inputs()}
    inputs: dict[str, np.ndarray] = {}
    if "input_ids" in input_names:
        inputs["input_ids"] = np.zeros((1, seq_len), dtype=np.int64)
    if "attention_mask" in input_names:
        inputs["attention_mask"] = np.ones((1, seq_len), dtype=np.int64)
    if "token_type_ids" in input_names:
        inputs["token_type_ids"] = np.zeros((1, seq_len), dtype=np.int64)
    return inputs


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify ONNX portability for device runtime")
    parser.add_argument("--model", required=True, help="ONNX model path")
    parser.add_argument("--seq-len", type=int, default=16, help="Dummy input sequence length")
    args = parser.parse_args()

    model_path = Path(args.model)
    if not model_path.exists():
        print(f"[ERROR] model not found: {model_path}")
        return 2

    import onnxruntime as ort

    session = ort.InferenceSession(str(model_path), providers=["CPUExecutionProvider"])
    inputs = _build_inputs(session, args.seq_len)
    if not inputs:
        print("[ERROR] unsupported input schema for this verifier")
        return 3

    outputs = session.run(None, inputs)
    shapes = [list(np.asarray(o).shape) for o in outputs]
    result = {
        "model": str(model_path),
        "provider": "CPUExecutionProvider",
        "inputs": {k: list(v.shape) for k, v in inputs.items()},
        "output_shapes": shapes,
        "status": "ok",
    }
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
