from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class SlotCreate(BaseModel):
    slot_key: str = Field(..., min_length=1, max_length=64)
    display_name: str = Field(..., min_length=1, max_length=64)
    entity_type: str = Field(..., min_length=1, max_length=64)
    is_required: bool = False
    prompt_text: str | None = None
    constraints: dict | None = None
    sort_order: int = 0


class SlotInfo(BaseModel):
    id: UUID
    slot_key: str
    display_name: str
    entity_type: str
    is_required: bool
    prompt_text: str | None
    constraints: dict | None
    sort_order: int

    model_config = {"from_attributes": True}


class SlotUpdate(BaseModel):
    display_name: str | None = None
    entity_type: str | None = None
    is_required: bool | None = None
    prompt_text: str | None = None
    constraints: dict | None = None
    sort_order: int | None = None


class TrainingDataCreate(BaseModel):
    text: str = Field(..., min_length=1)
    language: str = "zh"
    slot_annotations: dict | list | None = None


class TrainingDataInfo(BaseModel):
    id: UUID
    text: str
    language: str
    slot_annotations: dict | list | None
    is_auto_translated: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class IntentCreate(BaseModel):
    intent_key: str = Field(..., min_length=1, max_length=128)
    display_name: str = Field(..., min_length=1, max_length=128)
    category: str = Field(..., min_length=1, max_length=64)
    description: str | None = None
    slots: list[SlotCreate] = Field(default_factory=list)


class IntentInfo(BaseModel):
    id: UUID
    intent_key: str
    display_name: str
    category: str
    description: str | None
    is_active: bool
    slots: list[SlotInfo] = []
    training_data_count: int = 0
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class IntentUpdate(BaseModel):
    display_name: str | None = None
    category: str | None = None
    description: str | None = None
    is_active: bool | None = None


class IntentListResponse(BaseModel):
    items: list[IntentInfo]
    total: int


class IntentLibraryInfo(BaseModel):
    library_key: str
    display_name: str
    language: str = "zh"
    description: str | None = None
    default_intent_f1_threshold: float = 0.95
    default_slot_f1_threshold: float = 0.90
    intent_count: int


class IntentLibraryListResponse(BaseModel):
    items: list[IntentLibraryInfo]
    total: int


class IntentLibraryCreate(BaseModel):
    library_key: str = Field(..., min_length=1, max_length=64)
    display_name: str = Field(..., min_length=1, max_length=128)
    language: str = Field(..., pattern="^(zh|en)$")
    description: str | None = None
    default_intent_f1_threshold: float = Field(0.95, ge=0.0, le=1.0)
    default_slot_f1_threshold: float = Field(0.90, ge=0.0, le=1.0)


class IntentLibraryUpdate(BaseModel):
    display_name: str | None = Field(None, min_length=1, max_length=128)
    language: str | None = Field(None, pattern="^(zh|en)$")
    description: str | None = None
    default_intent_f1_threshold: float | None = Field(None, ge=0.0, le=1.0)
    default_slot_f1_threshold: float | None = Field(None, ge=0.0, le=1.0)


class TrainingDatasetCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=128)
    source_type: str = Field("manual", pattern="^(manual|llm|mixed)$")
    schema_version: str = Field("v1", max_length=16)
    sample_count: int = Field(0, ge=0)
    config: dict = Field(default_factory=dict)
    file_uri: str | None = None


class TrainingDatasetInfo(BaseModel):
    id: UUID
    library_key: str
    name: str
    source_type: str
    schema_version: str
    sample_count: int
    config: dict
    file_uri: str | None = None

    model_config = {"from_attributes": True}


class EvaluationDatasetCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=128)
    source_type: str = Field("manual", pattern="^(manual|llm|mixed)$")
    schema_version: str = Field("v1", max_length=16)
    sample_count: int = Field(0, ge=0)
    has_full_fields: bool = True
    config: dict = Field(default_factory=dict)
    file_uri: str | None = None


class EvaluationDatasetInfo(BaseModel):
    id: UUID
    library_key: str
    name: str
    source_type: str
    schema_version: str
    sample_count: int
    has_full_fields: bool
    config: dict
    file_uri: str | None = None

    model_config = {"from_attributes": True}


class TrainingSampleRow(BaseModel):
    intent_key: str
    utterance: str
    language: str = Field(..., pattern="^(zh|en)$")
    slots: dict | list | None = None
    source: str = Field("manual", pattern="^(manual|llm|mixed)$")


class EvaluationSampleRow(BaseModel):
    intent_key: str
    utterance: str
    language: str = Field(..., pattern="^(zh|en)$")
    source: str = Field("manual", pattern="^(manual|llm|mixed)$")
    expected_result: dict | str | None = None
    actual_result: dict | str | None = None
    threshold: float | None = Field(None, ge=0.0, le=1.0)
    actual_score: float | None = Field(None, ge=0.0, le=1.0)
    is_hit: bool | None = None


class TrainingDatasetImportRequest(BaseModel):
    rows: list[TrainingSampleRow] = Field(default_factory=list)


class EvaluationDatasetImportRequest(BaseModel):
    rows: list[EvaluationSampleRow] = Field(default_factory=list)


class LibraryModelVersionInfo(BaseModel):
    id: UUID
    library_key: str
    version_name: str
    status: str
    train_dataset_id: UUID | None = None
    artifact_type: str | None = None
    artifact_uri: str | None = None
    artifact_sha256: str | None = None
    metrics: dict
    notes: str | None = None
    is_testable: bool
    is_published: bool

    model_config = {"from_attributes": True}


class TrainModelRequest(BaseModel):
    version_name: str = Field(..., min_length=1, max_length=128)
    train_dataset_id: UUID
    notes: str | None = None


class EvaluateModelRequest(BaseModel):
    dataset_id: UUID
    threshold_intent_f1: float | None = Field(None, ge=0.0, le=1.0)
    threshold_slot_f1: float | None = Field(None, ge=0.0, le=1.0)


class EvaluationRunInfo(BaseModel):
    id: UUID
    library_key: str
    model_version_id: UUID
    dataset_id: UUID
    status: str
    threshold_intent_f1: float
    threshold_slot_f1: float
    result_summary: dict
    analysis: dict

    model_config = {"from_attributes": True}


class ModelSingleTestRequest(BaseModel):
    utterance: str = Field(..., min_length=1)
    language: str = Field("zh", pattern="^(zh|en)$")
    expected_intent: str | None = None
    expected_slots: dict | None = None


class ModelSingleTestResponse(BaseModel):
    model_id: UUID
    library_key: str
    utterance: str
    language: str
    predicted_intent: str
    confidence: float
    predicted_slots: dict = Field(default_factory=dict)
    is_hit: bool
    summary: str
    detail: dict = Field(default_factory=dict)


class PublishModelRequest(BaseModel):
    confirm_publish: bool = False
    publish_note: str | None = None
