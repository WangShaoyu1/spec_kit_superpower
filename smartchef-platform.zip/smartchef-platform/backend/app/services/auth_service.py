import secrets
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import create_access_token, hash_password, verify_password
from app.models.user import Role, User
from app.schemas.user import UserCreate, UserUpdate


async def authenticate_user(db: AsyncSession, username: str, password: str) -> User:
    result = await db.execute(select(User).where(User.username == username))
    user = result.scalar_one_or_none()
    if not user or not await verify_password(password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="用户名或密码错误",
        )
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="账号已禁用")
    return user


async def login(db: AsyncSession, username: str, password: str) -> str:
    user = await authenticate_user(db, username, password)
    token = create_access_token(
        data={"sub": str(user.id), "username": user.username}
    )
    return token


async def create_user(db: AsyncSession, data: UserCreate) -> User:
    existing = await db.execute(select(User).where(User.username == data.username))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="用户名已存在")
    user = User(
        username=data.username,
        password_hash=hash_password(data.password),
        display_name=data.display_name or data.username,
        role_id=data.role_id,
    )
    db.add(user)
    await db.flush()
    await db.refresh(user)
    return user


async def list_users(
    db: AsyncSession,
    *,
    skip: int = 0,
    limit: int = 50,
    search: str | None = None,
    role_id: UUID | None = None,
) -> tuple[list[User], int]:
    filters = []
    if search:
        like = f"%{search.strip()}%"
        filters.append(
            or_(
                User.username.ilike(like),
                User.display_name.ilike(like),
            )
        )
    if role_id:
        filters.append(User.role_id == role_id)

    count_q = select(func.count()).select_from(User)
    if filters:
        count_q = count_q.where(*filters)
    total = (await db.execute(count_q)).scalar() or 0

    query = select(User).order_by(User.created_at.desc()).offset(skip).limit(limit)
    if filters:
        query = query.where(*filters)
    result = await db.execute(query)
    return list(result.scalars().all()), total


async def update_user(db: AsyncSession, user_id: UUID, data: UserUpdate) -> User:
    user = await get_user_by_id(db, user_id)
    updates = data.model_dump(exclude_unset=True)
    for key, value in updates.items():
        setattr(user, key, value)
    await db.flush()
    await db.refresh(user)
    return user


async def reset_user_password(db: AsyncSession, user_id: UUID) -> tuple[User, str]:
    user = await get_user_by_id(db, user_id)
    temp_password = secrets.token_urlsafe(10)
    user.password_hash = hash_password(temp_password)
    await db.flush()
    await db.refresh(user)
    return user, temp_password


async def get_user_by_id(db: AsyncSession, user_id: UUID) -> User:
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="用户不存在")
    return user


async def create_role(db: AsyncSession, name: str, permissions: dict, is_system: bool = False) -> Role:
    role = Role(name=name, permissions=permissions, is_system=is_system)
    db.add(role)
    await db.flush()
    await db.refresh(role)
    return role


async def list_roles(
    db: AsyncSession,
    *,
    skip: int = 0,
    limit: int = 50,
) -> tuple[list[Role], int]:
    total = (await db.execute(select(func.count()).select_from(Role))).scalar() or 0
    result = await db.execute(select(Role).order_by(Role.name).offset(skip).limit(limit))
    return list(result.scalars().all()), total


async def update_role(
    db: AsyncSession, role_id: UUID, name: str | None = None, permissions: dict | None = None
) -> Role:
    result = await db.execute(select(Role).where(Role.id == role_id))
    role = result.scalar_one_or_none()
    if not role:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="角色不存在")
    if role.is_system:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="系统角色不可修改")
    if name is not None:
        role.name = name
    if permissions is not None:
        role.permissions = permissions
    await db.flush()
    await db.refresh(role)
    return role
