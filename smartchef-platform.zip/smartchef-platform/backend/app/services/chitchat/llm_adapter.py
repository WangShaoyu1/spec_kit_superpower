"""LLM adapter: unified interface via ZenMux OpenAI SDK.

ZenMux 文档: https://zenmux.ai/docs/zh/guide/quickstart.html
- base_url: https://zenmux.ai/api/v1
- model 格式: 供应商/模型名，如 openai/gpt-4o-mini
"""
import asyncio
import logging
from typing import TYPE_CHECKING, Any, cast

from openai import AsyncOpenAI

from app.core.config import get_settings

if TYPE_CHECKING:
    from openai.types.chat import ChatCompletionMessageParam

logger = logging.getLogger(__name__)
settings = get_settings()


def _normalize_zenmux_model(model: str) -> str:
    """ZenMux 要求 model 为 供应商/模型名，无斜杠时补 openai/ 前缀。"""
    if "/" in model:
        return model
    return f"openai/{model}"


def get_llm_client() -> AsyncOpenAI:
    return AsyncOpenAI(
        api_key=settings.ZENMUX_API_KEY,
        base_url=settings.ZENMUX_BASE_URL.rstrip("/"),
    )


async def chat_completion(
    messages: list[dict[str, Any]],
    model: str = "gpt-4o-mini",
    temperature: float = 0.7,
    max_tokens: int = 512,
) -> str:
    """Call LLM via ZenMux gateway and return response text."""
    model = _normalize_zenmux_model(model)
    user_text = ""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            user_text = str(msg.get("content") or "").strip()
            break
    if not settings.ZENMUX_API_KEY:
        logger.error("ZENMUX_API_KEY not configured; LLM call skipped")
        return "抱歉，LLM 未配置（ZENMUX_API_KEY 为空），请检查环境变量。"
    try:
        logger.info("[llm] calling model=%s user_len=%d", model, len(user_text))
        client = get_llm_client()
        timeout_s = max(5, settings.PIPELINE_CHAT_TIMEOUT_SECONDS - 1)
        response = await asyncio.wait_for(
            client.chat.completions.create(
                model=model,
                messages=cast("list[ChatCompletionMessageParam]", messages),
                temperature=temperature,
                max_tokens=max_tokens,
            ),
            timeout=float(timeout_s),
        )
        out = response.choices[0].message.content or ""
        logger.info("[llm] done resp_len=%d", len(out))
        return out
    except TimeoutError:
        timeout_used = max(1, settings.PIPELINE_CHAT_TIMEOUT_SECONDS - 1)
        logger.error("LLM call timeout timeout=%ds model=%s user_len=%d", timeout_used, model, len(user_text))
        return "抱歉，回复生成超时，请稍后再试。"
    except Exception as e:
        error_text = str(e).lower()
        is_csrf = ("csrf" in error_text) and ("token" in error_text)
        if is_csrf:
            logger.warning("LLM csrf token failure; using local fallback reply")
            if user_text in {"你好", "您好", "hi", "hello"}:
                return "你好，我在的。可以告诉我你想做什么，我来帮你一步步完成。"
            return f"我收到你的消息了：{user_text or '（空消息）'}。当前云端模型暂时不可用，我可以先给你本地建议。"
        logger.error("LLM call failed: %s", e)
        return "抱歉，暂时无法生成回复，请稍后再试。"
