"""Reference resolver: entity stack + rule-based coreference resolution."""
import re
import logging

logger = logging.getLogger(__name__)

PRONOUN_PATTERNS = [
    r"刚才那个",
    r"上一个",
    r"它|这个|那个|刚才的|上面的|这道|那道",
    r"这|那",
]


def resolve_references(
    text: str,
    entity_stack: list[dict],
) -> tuple[str, list[dict]]:
    """Resolve pronouns and references using entity stack.
    
    Args:
        text: current user input
        entity_stack: list of dicts with keys: type, value, turn
        
    Returns:
        (resolved_text, resolved_entities)
    """
    if not entity_stack:
        return text, []

    resolved_text = text
    resolved_entities = []

    for pattern in PRONOUN_PATTERNS:
        match = re.search(pattern, resolved_text)
        if match:
            target = entity_stack[-1]
            if match.group() == "上一个" and len(entity_stack) >= 2:
                target = entity_stack[-2]

            resolved_text = resolved_text[:match.start()] + target["value"] + resolved_text[match.end():]
            resolved_entities.append({
                "pronoun": match.group(),
                "resolved_to": target["value"],
                "entity_type": target["type"],
            })
            logger.info(f"Resolved '{match.group()}' -> '{target['value']}'")
            break

    # Ellipsis recovery for short follow-up commands (e.g., "再高一点").
    if not resolved_entities and len(text.strip()) < 5:
        target = entity_stack[-1]
        if target.get("type") == "number":
            resolved_text = f"温度{target['value']}{text}"
            resolved_entities.append({
                "ellipsis_recovery": True,
                "entity_type": target["type"],
                "entity_value": target["value"],
            })

    return resolved_text, resolved_entities
