from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.dialog_profile import DialogProfile
from app.models.intent_library import IntentLibrary
from app.models.persona import Persona
from app.schemas.profile import (
    DialogProfileCreate,
    DialogProfileUpdate,
    PersonaCreate,
    PersonaUpdate,
)


async def list_profiles(
    db: AsyncSession,
    *,
    skip: int = 0,
    limit: int = 50,
) -> tuple[list[DialogProfile], int]:
    total = (await db.execute(select(func.count()).select_from(DialogProfile))).scalar() or 0
    result = await db.execute(
        select(DialogProfile)
        .options(selectinload(DialogProfile.persona))
        .order_by(DialogProfile.created_at.desc())
        .offset(skip)
        .limit(limit)
    )
    return list(result.scalars().unique().all()), total


async def get_profile(db: AsyncSession, profile_id: UUID) -> DialogProfile:
    result = await db.execute(
        select(DialogProfile).options(selectinload(DialogProfile.persona)).where(DialogProfile.id == profile_id)
    )
    profile = result.scalar_one_or_none()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="对话方案不存在")
    return profile


async def create_profile(db: AsyncSession, data: DialogProfileCreate, user_id: UUID | None = None) -> DialogProfile:
    await _validate_intent_libraries(db, data.intent_library_keys)
    profile = DialogProfile(
        **data.model_dump(),
        created_by=user_id,
    )
    db.add(profile)
    await db.flush()
    return await get_profile(db, profile.id)


async def update_profile(db: AsyncSession, profile_id: UUID, data: DialogProfileUpdate) -> DialogProfile:
    profile = await get_profile(db, profile_id)
    updates = data.model_dump(exclude_unset=True)
    if "intent_library_keys" in updates:
        await _validate_intent_libraries(db, updates.get("intent_library_keys"))
    for key, value in updates.items():
        setattr(profile, key, value)
    status_explicitly_changed = "status" in updates
    has_content_updates = any(key != "status" for key in updates)
    if profile.status == "published" and has_content_updates and not status_explicitly_changed:
        # Published profile edited without explicit status override reverts to draft.
        profile.status = "draft"
    await db.flush()
    return await get_profile(db, profile_id)


async def delete_profile(db: AsyncSession, profile_id: UUID) -> None:
    profile = await get_profile(db, profile_id)
    await db.delete(profile)
    await db.flush()


# --- Persona operations ---

async def list_personas(
    db: AsyncSession,
    *,
    skip: int = 0,
    limit: int = 50,
) -> tuple[list[Persona], int]:
    total = (await db.execute(select(func.count()).select_from(Persona))).scalar() or 0
    result = await db.execute(
        select(Persona).order_by(Persona.created_at.desc()).offset(skip).limit(limit)
    )
    return list(result.scalars().all()), total


async def get_persona(db: AsyncSession, persona_id: UUID) -> Persona:
    result = await db.execute(select(Persona).where(Persona.id == persona_id))
    persona = result.scalar_one_or_none()
    if not persona:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="人设不存在")
    return persona


async def create_persona(db: AsyncSession, data: PersonaCreate) -> Persona:
    persona = Persona(**data.model_dump())
    db.add(persona)
    await db.flush()
    await db.refresh(persona)
    return persona


async def update_persona(db: AsyncSession, persona_id: UUID, data: PersonaUpdate) -> Persona:
    persona = await get_persona(db, persona_id)
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(persona, key, value)
    await db.flush()
    await db.refresh(persona)
    return persona


async def delete_persona(db: AsyncSession, persona_id: UUID) -> None:
    persona = await get_persona(db, persona_id)
    await db.delete(persona)
    await db.flush()


async def _validate_intent_libraries(db: AsyncSession, keys: list[str] | None) -> None:
    if not keys:
        return
    normalized = [k.strip() for k in keys if k and k.strip()]
    if len(set(normalized)) != len(normalized):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="指令库不允许重复选择")
    result = await db.execute(
        select(IntentLibrary.library_key).where(IntentLibrary.library_key.in_(normalized))
    )
    existing_keys = {row[0] for row in result.all()}
    missing = [k for k in normalized if k not in existing_keys]
    if missing:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"指令库不存在: {', '.join(missing)}",
        )
