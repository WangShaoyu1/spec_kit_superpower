import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.intent import Intent, Slot, TrainingData
from app.models.intent_library import IntentLibrary
from app.models.library_model import (
    EvaluationDataset,
    EvaluationRun,
    LibraryModelVersion,
    TrainingDataset,
)
from app.schemas.intent import (
    EvaluateModelRequest,
    EvaluationDatasetImportRequest,
    EvaluationDatasetCreate,
    IntentLibraryCreate,
    IntentLibraryUpdate,
    ModelSingleTestRequest,
    TrainModelRequest,
    TrainingDatasetImportRequest,
    TrainingDatasetCreate,
    IntentCreate,
    IntentUpdate,
    SlotCreate,
    SlotUpdate,
    TrainingDataCreate,
)
from app.services.nlu.intent_classifier import classify_intent
from app.services.nlu.slot_extractor import extract_slots


async def list_intents(
    db: AsyncSession, category: str | None = None, skip: int = 0, limit: int = 50
) -> tuple[list[Intent], int]:
    query = select(Intent).options(selectinload(Intent.slots))
    count_query = select(func.count(Intent.id))

    if category:
        query = query.where(Intent.category == category)
        count_query = count_query.where(Intent.category == category)

    total = (await db.execute(count_query)).scalar() or 0
    result = await db.execute(
        query.order_by(Intent.category, Intent.intent_key).offset(skip).limit(limit)
    )
    intents = list(result.scalars().unique().all())

    for intent in intents:
        td_count = (await db.execute(
            select(func.count(TrainingData.id)).where(TrainingData.intent_id == intent.id)
        )).scalar() or 0
        intent._td_count = td_count  # type: ignore[attr-defined]

    return intents, total


async def list_intent_libraries(
    db: AsyncSession,
    *,
    skip: int = 0,
    limit: int = 50,
    language: str | None = None,
) -> tuple[list[dict[str, object]], int]:
    base_query = select(IntentLibrary)
    count_query = select(func.count()).select_from(IntentLibrary)
    if language:
        base_query = base_query.where(IntentLibrary.language == language)
        count_query = count_query.where(IntentLibrary.language == language)

    total = (await db.execute(count_query)).scalar() or 0
    result = await db.execute(
        base_query.order_by(IntentLibrary.created_at.desc()).offset(skip).limit(limit)
    )
    libraries = list(result.scalars().all())
    if not libraries:
        return [], total

    keys = [lib.library_key for lib in libraries]
    counts_result = await db.execute(
        select(Intent.category, func.count(Intent.id))
        .where(Intent.category.in_(keys))
        .group_by(Intent.category)
    )
    count_map = {k: int(v or 0) for k, v in counts_result.all()}
    return (
        [
            {
                "library_key": lib.library_key,
                "display_name": lib.display_name,
                "language": lib.language,
                "description": lib.description,
                "default_intent_f1_threshold": lib.default_intent_f1_threshold,
                "default_slot_f1_threshold": lib.default_slot_f1_threshold,
                "intent_count": count_map.get(lib.library_key, 0),
            }
            for lib in libraries
        ],
        int(total),
    )


async def get_intent_library(db: AsyncSession, library_key: str) -> IntentLibrary:
    result = await db.execute(
        select(IntentLibrary).where(IntentLibrary.library_key == library_key)
    )
    library = result.scalar_one_or_none()
    if not library:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="指令库不存在")
    return library


async def create_intent_library(
    db: AsyncSession, data: IntentLibraryCreate, user_id: UUID | None = None
) -> IntentLibrary:
    existing = await db.execute(
        select(IntentLibrary).where(IntentLibrary.library_key == data.library_key)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="library_key 已存在")
    library = IntentLibrary(**data.model_dump(), created_by=user_id)
    db.add(library)
    await db.flush()
    await db.refresh(library)
    return library


async def update_intent_library(
    db: AsyncSession, library_key: str, data: IntentLibraryUpdate
) -> IntentLibrary:
    library = await get_intent_library(db, library_key)
    updates = data.model_dump(exclude_unset=True)
    for key, value in updates.items():
        setattr(library, key, value)
    await db.flush()
    await db.refresh(library)
    return library


async def delete_intent_library(db: AsyncSession, library_key: str) -> None:
    library = await get_intent_library(db, library_key)
    bound_count = (
        await db.execute(
            select(func.count(Intent.id)).where(Intent.category == library.library_key)
        )
    ).scalar() or 0
    if bound_count > 0:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="该指令库仍有关联意图，请先迁移或删除相关意图",
        )
    await db.delete(library)
    await db.flush()


async def list_library_models(db: AsyncSession, library_key: str) -> list[LibraryModelVersion]:
    await get_intent_library(db, library_key)
    result = await db.execute(
        select(LibraryModelVersion)
        .where(LibraryModelVersion.library_key == library_key)
        .order_by(LibraryModelVersion.created_at.desc())
    )
    return list(result.scalars().all())


async def create_training_dataset(
    db: AsyncSession,
    library_key: str,
    data: TrainingDatasetCreate,
    user_id: UUID | None = None,
) -> TrainingDataset:
    await get_intent_library(db, library_key)
    dataset = TrainingDataset(library_key=library_key, created_by=user_id, **data.model_dump())
    db.add(dataset)
    await db.flush()
    await db.refresh(dataset)
    return dataset


async def import_training_dataset_rows(
    db: AsyncSession,
    library_key: str,
    dataset_id: UUID,
    body: TrainingDatasetImportRequest,
) -> TrainingDataset:
    await get_intent_library(db, library_key)
    ds_result = await db.execute(
        select(TrainingDataset).where(
            TrainingDataset.id == dataset_id, TrainingDataset.library_key == library_key
        )
    )
    dataset = ds_result.scalar_one_or_none()
    if not dataset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="训练集不存在")
    rows = [row.model_dump() for row in body.rows]
    dataset.config = {**(dataset.config or {}), "rows": rows}
    dataset.sample_count = len(rows)
    await db.flush()
    await db.refresh(dataset)
    return dataset


async def list_training_datasets(db: AsyncSession, library_key: str) -> list[TrainingDataset]:
    await get_intent_library(db, library_key)
    result = await db.execute(
        select(TrainingDataset)
        .where(TrainingDataset.library_key == library_key)
        .order_by(TrainingDataset.created_at.desc())
    )
    return list(result.scalars().all())


async def get_training_dataset_rows(
    db: AsyncSession, library_key: str, dataset_id: UUID
) -> list[dict]:
    await get_intent_library(db, library_key)
    result = await db.execute(
        select(TrainingDataset).where(
            TrainingDataset.id == dataset_id, TrainingDataset.library_key == library_key
        )
    )
    dataset = result.scalar_one_or_none()
    if not dataset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="训练集不存在")
    rows = dataset.config.get("rows", [])
    return rows if isinstance(rows, list) else []


async def create_evaluation_dataset(
    db: AsyncSession,
    library_key: str,
    data: EvaluationDatasetCreate,
    user_id: UUID | None = None,
) -> EvaluationDataset:
    await get_intent_library(db, library_key)
    dataset = EvaluationDataset(library_key=library_key, created_by=user_id, **data.model_dump())
    db.add(dataset)
    await db.flush()
    await db.refresh(dataset)
    return dataset


async def import_evaluation_dataset_rows(
    db: AsyncSession,
    library_key: str,
    dataset_id: UUID,
    body: EvaluationDatasetImportRequest,
) -> EvaluationDataset:
    await get_intent_library(db, library_key)
    ds_result = await db.execute(
        select(EvaluationDataset).where(
            EvaluationDataset.id == dataset_id, EvaluationDataset.library_key == library_key
        )
    )
    dataset = ds_result.scalar_one_or_none()
    if not dataset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="评估集不存在")
    rows = [row.model_dump() for row in body.rows]
    dataset.config = {**(dataset.config or {}), "rows": rows}
    dataset.sample_count = len(rows)
    await db.flush()
    await db.refresh(dataset)
    return dataset


async def list_evaluation_datasets(db: AsyncSession, library_key: str) -> list[EvaluationDataset]:
    await get_intent_library(db, library_key)
    result = await db.execute(
        select(EvaluationDataset)
        .where(EvaluationDataset.library_key == library_key)
        .order_by(EvaluationDataset.created_at.desc())
    )
    return list(result.scalars().all())


async def get_evaluation_dataset_rows(
    db: AsyncSession, library_key: str, dataset_id: UUID
) -> list[dict]:
    await get_intent_library(db, library_key)
    result = await db.execute(
        select(EvaluationDataset).where(
            EvaluationDataset.id == dataset_id, EvaluationDataset.library_key == library_key
        )
    )
    dataset = result.scalar_one_or_none()
    if not dataset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="评估集不存在")
    rows = dataset.config.get("rows", [])
    return rows if isinstance(rows, list) else []


async def train_library_model(
    db: AsyncSession,
    library_key: str,
    data: TrainModelRequest,
    user_id: UUID | None = None,
) -> LibraryModelVersion:
    await get_intent_library(db, library_key)
    ds_result = await db.execute(
        select(TrainingDataset).where(
            TrainingDataset.id == data.train_dataset_id, TrainingDataset.library_key == library_key
        )
    )
    dataset = ds_result.scalar_one_or_none()
    if not dataset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="训练集不存在")

    count_result = await db.execute(
        select(func.count())
        .select_from(LibraryModelVersion)
        .where(
            LibraryModelVersion.library_key == library_key,
            LibraryModelVersion.status != "archived",
        )
    )
    active_count = int(count_result.scalar() or 0)
    if active_count >= 5:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="请先归档/删除历史模型",
        )

    model = LibraryModelVersion(
        library_key=library_key,
        version_name=data.version_name,
        train_dataset_id=data.train_dataset_id,
        notes=data.notes,
        status="trained",
        created_by=user_id,
    )
    db.add(model)
    await db.flush()
    await db.refresh(model)
    return model


async def set_model_testable(
    db: AsyncSession, library_key: str, model_id: UUID
) -> LibraryModelVersion:
    model = await _get_library_model(db, library_key, model_id)
    result = await db.execute(
        select(LibraryModelVersion).where(
            LibraryModelVersion.library_key == library_key,
            LibraryModelVersion.is_testable.is_(True),
            LibraryModelVersion.id != model_id,
        )
    )
    for old in result.scalars().all():
        old.is_testable = False
        if old.status == "testable":
            old.status = "trained"
    model.is_testable = True
    model.status = "testable"
    await db.flush()
    await db.refresh(model)
    return model


async def publish_library_model(
    db: AsyncSession,
    library_key: str,
    model_id: UUID,
    user_id: UUID | None = None,
    publish_note: str | None = None,
) -> LibraryModelVersion:
    model = await _get_library_model(db, library_key, model_id)
    result = await db.execute(
        select(LibraryModelVersion).where(
            LibraryModelVersion.library_key == library_key,
            LibraryModelVersion.is_published.is_(True),
            LibraryModelVersion.id != model_id,
        )
    )
    for old in result.scalars().all():
        old.is_published = False
        if old.status == "published":
            old.status = "trained"
    model.is_published = True
    model.status = "published"
    model.published_by = user_id
    model.published_at = datetime.now(timezone.utc)
    if publish_note:
        model.notes = publish_note
    await db.flush()
    await db.refresh(model)
    return model


async def archive_library_model(db: AsyncSession, library_key: str, model_id: UUID) -> LibraryModelVersion:
    model = await _get_library_model(db, library_key, model_id)
    model.status = "archived"
    model.is_testable = False
    model.is_published = False
    await db.flush()
    await db.refresh(model)
    return model


async def restore_library_model(db: AsyncSession, library_key: str, model_id: UUID) -> LibraryModelVersion:
    model = await _get_library_model(db, library_key, model_id)
    model.status = "draft"
    await db.flush()
    await db.refresh(model)
    return model


async def evaluate_library_model(
    db: AsyncSession,
    library_key: str,
    model_id: UUID,
    data: EvaluateModelRequest,
    user_id: UUID | None = None,
) -> EvaluationRun:
    library = await get_intent_library(db, library_key)
    model = await _get_library_model(db, library_key, model_id)
    ds_result = await db.execute(
        select(EvaluationDataset).where(
            EvaluationDataset.id == data.dataset_id, EvaluationDataset.library_key == library_key
        )
    )
    dataset = ds_result.scalar_one_or_none()
    if not dataset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="评估集不存在")

    threshold_intent = (
        data.threshold_intent_f1
        if data.threshold_intent_f1 is not None
        else library.default_intent_f1_threshold
    )
    threshold_slot = (
        data.threshold_slot_f1
        if data.threshold_slot_f1 is not None
        else library.default_slot_f1_threshold
    )
    eval_rows = _normalize_eval_rows(dataset.config.get("rows", []))
    scoped_intents = await _load_library_intents(db, library_key)
    (
        updated_rows,
        result_summary,
        analysis,
    ) = await _run_evaluation_rows(eval_rows, scoped_intents, threshold_intent, threshold_slot, data.dataset_id)
    dataset.config = {**(dataset.config or {}), "rows": updated_rows}
    run = EvaluationRun(
        library_key=library_key,
        model_version_id=model.id,
        dataset_id=dataset.id,
        status="completed",
        threshold_intent_f1=threshold_intent,
        threshold_slot_f1=threshold_slot,
        snapshot={
            "library_default_intent_f1": library.default_intent_f1_threshold,
            "library_default_slot_f1": library.default_slot_f1_threshold,
        },
        result_summary=result_summary,
        analysis=analysis,
        created_by=user_id,
    )
    db.add(run)
    model.status = "testable"
    model.is_testable = True
    model.metrics = run.result_summary
    await db.flush()
    await db.refresh(run)
    return run


async def list_evaluation_runs(
    db: AsyncSession, library_key: str, model_id: UUID
) -> list[EvaluationRun]:
    await _get_library_model(db, library_key, model_id)
    result = await db.execute(
        select(EvaluationRun)
        .where(EvaluationRun.library_key == library_key, EvaluationRun.model_version_id == model_id)
        .order_by(EvaluationRun.created_at.desc())
    )
    return list(result.scalars().all())


async def ensure_library_has_published_model(db: AsyncSession, library_key: str) -> bool:
    result = await db.execute(
        select(LibraryModelVersion.id).where(
            LibraryModelVersion.library_key == library_key,
            LibraryModelVersion.is_published.is_(True),
        )
    )
    return result.scalar_one_or_none() is not None


async def get_library_published_models(db: AsyncSession, library_keys: list[str]) -> dict[str, dict]:
    if not library_keys:
        return {}
    result = await db.execute(
        select(LibraryModelVersion)
        .where(
            LibraryModelVersion.library_key.in_(library_keys),
            LibraryModelVersion.is_published.is_(True),
        )
        .order_by(LibraryModelVersion.created_at.desc())
    )
    mapping: dict[str, dict] = {}
    for model in result.scalars().all():
        if model.library_key in mapping:
            continue
        mapping[model.library_key] = {
            "model_id": str(model.id),
            "version_name": model.version_name,
            "artifact_type": model.artifact_type,
            "artifact_uri": model.artifact_uri,
            "artifact_sha256": model.artifact_sha256,
        }
    return mapping


async def run_model_single_test(
    db: AsyncSession,
    library_key: str,
    model_id: UUID,
    body: ModelSingleTestRequest,
) -> dict:
    model = await _get_library_model(db, library_key, model_id)
    scoped_intents = await _load_library_intents(db, library_key)
    if not scoped_intents:
        raise HTTPException(status_code=422, detail="指令库无可用意图")

    intent_result = await classify_intent(body.utterance, body.language, scoped_intents)
    intent_def = next((i for i in scoped_intents if i["intent_key"] == intent_result.intent_key), None)
    slot_defs = intent_def.get("slots", []) if intent_def else []
    slots = await extract_slots(body.utterance, slot_defs)
    predicted_slots = {s.slot_key: s.value for s in slots}
    is_hit = False
    if body.expected_intent:
        is_hit = body.expected_intent == intent_result.intent_key
        if body.expected_slots:
            is_hit = is_hit and all(
                str(predicted_slots.get(k)) == str(v) for k, v in body.expected_slots.items()
            )
    summary = (
        "命中预期"
        if is_hit
        else f"预测意图={intent_result.intent_key}, 置信度={intent_result.confidence:.3f}"
    )
    return {
        "model_id": model.id,
        "library_key": library_key,
        "utterance": body.utterance,
        "language": body.language,
        "predicted_intent": intent_result.intent_key,
        "confidence": intent_result.confidence,
        "predicted_slots": predicted_slots,
        "is_hit": is_hit,
        "summary": summary,
        "detail": {
            "top_k": intent_result.top_k or [],
            "model_version": model.version_name,
            "status": model.status,
            "artifact_type": model.artifact_type,
        },
    }


async def _get_library_model(
    db: AsyncSession, library_key: str, model_id: UUID
) -> LibraryModelVersion:
    result = await db.execute(
        select(LibraryModelVersion).where(
            LibraryModelVersion.id == model_id, LibraryModelVersion.library_key == library_key
        )
    )
    model = result.scalar_one_or_none()
    if not model:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="模型版本不存在")
    return model


async def _load_library_intents(db: AsyncSession, library_key: str) -> list[dict]:
    result = await db.execute(
        select(Intent)
        .options(selectinload(Intent.slots), selectinload(Intent.training_data))
        .where(Intent.category == library_key, Intent.is_active.is_(True))
    )
    intents = list(result.scalars().unique().all())
    rows: list[dict] = []
    for intent in intents:
        rows.append(
            {
                "intent_key": intent.intent_key,
                "display_name": intent.display_name,
                "category": intent.category,
                "library_key": intent.category,
                "slots": [
                    {
                        "slot_key": s.slot_key,
                        "entity_type": s.entity_type,
                        "is_required": s.is_required,
                        "prompt_text": s.prompt_text,
                        "display_name": s.display_name,
                        "sort_order": s.sort_order,
                    }
                    for s in (intent.slots or [])
                ],
                "training_texts": [td.text for td in (intent.training_data or [])],
            }
        )
    return rows


def _normalize_eval_rows(raw_rows: list[dict]) -> list[dict]:
    normalized: list[dict] = []
    for row in raw_rows:
        expected = row.get("expected_result")
        if isinstance(expected, str):
            try:
                expected = json.loads(expected)
            except Exception:
                expected = {"intent_key": row.get("intent_key")}
        if expected is None:
            expected = {"intent_key": row.get("intent_key")}
        normalized.append({**row, "expected_result": expected})
    return normalized


async def _run_evaluation_rows(
    rows: list[dict],
    intents: list[dict],
    threshold_intent: float,
    threshold_slot: float,
    dataset_id: UUID,
) -> tuple[list[dict], dict, dict]:
    if not rows:
        return (
            [],
            {
                "dataset_id": str(dataset_id),
                "intent_f1": 0.0,
                "slot_f1": 0.0,
                "pass_intent_threshold": False,
                "pass_slot_threshold": False,
                "total_samples": 0,
                "hit_count": 0,
            },
            {
                "overall": "无评估样本",
                "top_confusions": [],
                "slot_error_distribution": {},
                "low_score_samples": [],
                "suggestions": ["请先导入评估样本"],
            },
        )
    true_intents: list[str] = []
    pred_intents: list[str] = []
    has_slot_true = 0
    has_slot_pred = 0
    has_slot_hit = 0
    confusions: Counter[tuple[str, str]] = Counter()
    slot_error_distribution: defaultdict[str, int] = defaultdict(int)
    low_score_samples: list[dict] = []
    updated_rows: list[dict] = []
    for idx, row in enumerate(rows):
        utterance = str(row.get("utterance") or "")
        language = str(row.get("language") or "zh")
        expected = row.get("expected_result") or {}
        expected_intent = str(expected.get("intent_key") or row.get("intent_key") or "unknown")
        expected_slots = expected.get("slots") if isinstance(expected, dict) else {}
        expected_slots = expected_slots or {}
        result = await classify_intent(utterance, language, intents)
        pred_intent = result.intent_key
        true_intents.append(expected_intent)
        pred_intents.append(pred_intent)
        confusions[(expected_intent, pred_intent)] += 1
        slot_defs = next((i.get("slots", []) for i in intents if i["intent_key"] == pred_intent), [])
        pred_slots_raw = await extract_slots(utterance, slot_defs)
        pred_slots = {s.slot_key: s.value for s in pred_slots_raw}
        if expected_slots:
            has_slot_true += len(expected_slots)
            has_slot_pred += len(pred_slots)
            for k, v in expected_slots.items():
                if str(pred_slots.get(k)) == str(v):
                    has_slot_hit += 1
                else:
                    slot_error_distribution[k] += 1
        score = float(result.confidence)
        is_hit = pred_intent == expected_intent and score >= threshold_intent
        if expected_slots:
            is_hit = is_hit and all(str(pred_slots.get(k)) == str(v) for k, v in expected_slots.items())
        if score < threshold_intent:
            low_score_samples.append(
                {
                    "index": idx,
                    "utterance": utterance,
                    "expected_intent": expected_intent,
                    "predicted_intent": pred_intent,
                    "score": score,
                }
            )
        updated_rows.append(
            {
                **row,
                "actual_result": {"intent_key": pred_intent, "slots": pred_slots},
                "threshold": threshold_intent,
                "actual_score": score,
                "is_hit": is_hit,
            }
        )
    total = len(true_intents)
    intent_hit = sum(1 for t, p in zip(true_intents, pred_intents) if t == p)
    intent_f1 = intent_hit / total if total else 0.0
    slot_precision = has_slot_hit / has_slot_pred if has_slot_pred else 0.0
    slot_recall = has_slot_hit / has_slot_true if has_slot_true else 0.0
    slot_f1 = (
        2 * slot_precision * slot_recall / (slot_precision + slot_recall)
        if (slot_precision + slot_recall) > 0
        else 0.0
    )
    top_confusions = [
        {"expected": e, "actual": a, "count": c}
        for (e, a), c in confusions.most_common(5)
        if e != a
    ]
    summary = {
        "dataset_id": str(dataset_id),
        "intent_f1": round(intent_f1, 4),
        "slot_f1": round(slot_f1, 4),
        "pass_intent_threshold": intent_f1 >= threshold_intent,
        "pass_slot_threshold": slot_f1 >= threshold_slot,
        "total_samples": total,
        "hit_count": sum(1 for row in updated_rows if row.get("is_hit")),
    }
    analysis = {
        "overall": (
            "评估通过"
            if summary["pass_intent_threshold"] and summary["pass_slot_threshold"]
            else "评估未达标"
        ),
        "top_confusions": top_confusions,
        "slot_error_distribution": dict(slot_error_distribution),
        "low_score_samples": low_score_samples[:20],
        "suggestions": _build_eval_suggestions(summary, top_confusions, slot_error_distribution),
    }
    return updated_rows, summary, analysis


def _build_eval_suggestions(
    summary: dict, top_confusions: list[dict], slot_error_distribution: dict | defaultdict
) -> list[str]:
    suggestions: list[str] = []
    if not summary["pass_intent_threshold"]:
        suggestions.append("补充低分意图训练语料，增加同义表达与边界样本")
    if not summary["pass_slot_threshold"]:
        suggestions.append("补充带槽位样本并优化槽位提示词，优先修复高频槽位错误")
    if top_confusions:
        first = top_confusions[0]
        suggestions.append(
            f"优先治理混淆对: {first['expected']} -> {first['actual']}（{first['count']}次）"
        )
    if slot_error_distribution:
        slot_key = max(slot_error_distribution, key=slot_error_distribution.get)
        suggestions.append(f"重点修复槽位 {slot_key} 的抽取规则和训练样本")
    if not suggestions:
        suggestions.append("当前指标表现稳定，建议继续扩大评估覆盖范围")
    return suggestions


async def get_intent(db: AsyncSession, intent_id: UUID) -> Intent:
    result = await db.execute(
        select(Intent)
        .options(selectinload(Intent.slots), selectinload(Intent.training_data))
        .where(Intent.id == intent_id)
    )
    intent = result.scalar_one_or_none()
    if not intent:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="意图不存在")
    return intent


async def create_intent(db: AsyncSession, data: IntentCreate, user_id: UUID | None = None) -> Intent:
    existing = await db.execute(select(Intent).where(Intent.intent_key == data.intent_key))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="意图标识已存在")

    intent = Intent(
        intent_key=data.intent_key,
        display_name=data.display_name,
        category=data.category,
        description=data.description,
        created_by=user_id,
    )
    db.add(intent)
    await db.flush()

    for slot_data in data.slots:
        slot = Slot(
            intent_id=intent.id,
            slot_key=slot_data.slot_key,
            display_name=slot_data.display_name,
            entity_type=slot_data.entity_type,
            is_required=slot_data.is_required,
            prompt_text=slot_data.prompt_text,
            constraints=slot_data.constraints,
            sort_order=slot_data.sort_order,
        )
        db.add(slot)

    await db.flush()
    return await get_intent(db, intent.id)


async def update_intent(db: AsyncSession, intent_id: UUID, data: IntentUpdate) -> Intent:
    intent = await get_intent(db, intent_id)
    update_data = data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(intent, key, value)
    await db.flush()
    return await get_intent(db, intent_id)


async def delete_intent(db: AsyncSession, intent_id: UUID) -> None:
    intent = await get_intent(db, intent_id)
    await db.delete(intent)
    await db.flush()


# --- Slot operations ---

async def add_slot(db: AsyncSession, intent_id: UUID, data: SlotCreate) -> Slot:
    await get_intent(db, intent_id)
    slot = Slot(intent_id=intent_id, **data.model_dump())
    db.add(slot)
    await db.flush()
    await db.refresh(slot)
    return slot


async def update_slot(db: AsyncSession, slot_id: UUID, data: SlotUpdate) -> Slot:
    result = await db.execute(select(Slot).where(Slot.id == slot_id))
    slot = result.scalar_one_or_none()
    if not slot:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="槽位不存在")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(slot, key, value)
    await db.flush()
    await db.refresh(slot)
    return slot


async def delete_slot(db: AsyncSession, slot_id: UUID) -> None:
    result = await db.execute(select(Slot).where(Slot.id == slot_id))
    slot = result.scalar_one_or_none()
    if not slot:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="槽位不存在")
    await db.delete(slot)


# --- Training data operations ---

async def list_training_data(db: AsyncSession, intent_id: UUID) -> list[TrainingData]:
    result = await db.execute(
        select(TrainingData).where(TrainingData.intent_id == intent_id).order_by(TrainingData.created_at)
    )
    return list(result.scalars().all())


async def add_training_data(db: AsyncSession, intent_id: UUID, data: TrainingDataCreate) -> TrainingData:
    await get_intent(db, intent_id)
    td = TrainingData(intent_id=intent_id, **data.model_dump())
    db.add(td)
    await db.flush()
    await db.refresh(td)
    return td


async def batch_add_training_data(
    db: AsyncSession, intent_id: UUID, items: list[TrainingDataCreate]
) -> list[TrainingData]:
    await get_intent(db, intent_id)
    results = []
    for data in items:
        td = TrainingData(intent_id=intent_id, **data.model_dump())
        db.add(td)
        results.append(td)
    await db.flush()
    for td in results:
        await db.refresh(td)
    return results


async def delete_training_data(db: AsyncSession, td_id: UUID) -> None:
    result = await db.execute(select(TrainingData).where(TrainingData.id == td_id))
    td = result.scalar_one_or_none()
    if not td:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="训练数据不存在")
    await db.delete(td)
