import uuid

from sqlalchemy import Float, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.base import TimestampMixin, UUIDPrimaryKey


class IntentLibrary(UUIDPrimaryKey, TimestampMixin, Base):
    __tablename__ = "intent_libraries"

    library_key: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    display_name: Mapped[str] = mapped_column(String(128), nullable=False)
    language: Mapped[str] = mapped_column(String(8), nullable=False, index=True)  # zh | en
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    default_intent_f1_threshold: Mapped[float] = mapped_column(Float, nullable=False, default=0.95)
    default_slot_f1_threshold: Mapped[float] = mapped_column(Float, nullable=False, default=0.90)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), nullable=True
    )
