import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.base import TimestampMixin, UUIDPrimaryKey


class TrainingDataset(UUIDPrimaryKey, TimestampMixin, Base):
    __tablename__ = "training_datasets"

    library_key: Mapped[str] = mapped_column(
        String(64), ForeignKey("intent_libraries.library_key"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    source_type: Mapped[str] = mapped_column(String(16), default="manual", nullable=False)
    schema_version: Mapped[str] = mapped_column(String(16), default="v1", nullable=False)
    sample_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    config: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    file_uri: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=True
    )


class EvaluationDataset(UUIDPrimaryKey, TimestampMixin, Base):
    __tablename__ = "evaluation_datasets"

    library_key: Mapped[str] = mapped_column(
        String(64), ForeignKey("intent_libraries.library_key"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    source_type: Mapped[str] = mapped_column(String(16), default="manual", nullable=False)
    schema_version: Mapped[str] = mapped_column(String(16), default="v1", nullable=False)
    sample_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    config: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    file_uri: Mapped[str | None] = mapped_column(Text, nullable=True)
    has_full_fields: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=True
    )


class LibraryModelVersion(UUIDPrimaryKey, TimestampMixin, Base):
    __tablename__ = "library_model_versions"

    library_key: Mapped[str] = mapped_column(
        String(64), ForeignKey("intent_libraries.library_key"), nullable=False, index=True
    )
    version_name: Mapped[str] = mapped_column(String(128), nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="draft", nullable=False, index=True)
    train_dataset_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("training_datasets.id"), nullable=True
    )
    artifact_type: Mapped[str | None] = mapped_column(String(32), nullable=True)
    artifact_uri: Mapped[str | None] = mapped_column(Text, nullable=True)
    artifact_sha256: Mapped[str | None] = mapped_column(String(128), nullable=True)
    metrics: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_testable: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)
    is_published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    published_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=True
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=True
    )


class EvaluationRun(UUIDPrimaryKey, TimestampMixin, Base):
    __tablename__ = "evaluation_runs"

    library_key: Mapped[str] = mapped_column(
        String(64), ForeignKey("intent_libraries.library_key"), nullable=False, index=True
    )
    model_version_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("library_model_versions.id"), nullable=False, index=True
    )
    dataset_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("evaluation_datasets.id"), nullable=False
    )
    status: Mapped[str] = mapped_column(String(24), default="pending", nullable=False, index=True)
    threshold_intent_f1: Mapped[float] = mapped_column(Float, nullable=False, default=0.95)
    threshold_slot_f1: Mapped[float] = mapped_column(Float, nullable=False, default=0.90)
    snapshot: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    result_summary: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    analysis: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=True
    )
