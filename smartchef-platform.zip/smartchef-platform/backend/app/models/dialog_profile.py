import uuid
from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

import app.models.persona  # noqa: F401
from app.core.database import Base
from app.models.base import TimestampMixin, UUIDPrimaryKey

if TYPE_CHECKING:
    from app.models.persona import Persona


class DialogProfile(UUIDPrimaryKey, TimestampMixin, Base):
    __tablename__ = "dialog_profiles"

    name: Mapped[str] = mapped_column(String(128), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    llm_provider: Mapped[str] = mapped_column(String(64), nullable=False)
    llm_config: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    persona_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("personas.id"), nullable=True
    )
    routing_strategy: Mapped[str] = mapped_column(String(32), default="command_first", nullable=False)
    session_timeout_minutes: Mapped[int] = mapped_column(Integer, default=10)
    command_threshold: Mapped[float] = mapped_column(default=0.6, nullable=False)
    intent_library_keys: Mapped[list[str] | None] = mapped_column(ARRAY(String(64)), nullable=True)
    intent_ids: Mapped[list | None] = mapped_column(ARRAY(UUID(as_uuid=True)), nullable=True)
    knowledge_base_ids: Mapped[list | None] = mapped_column(ARRAY(UUID(as_uuid=True)), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="draft", nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=True
    )

    persona: Mapped["Persona"] = relationship(lazy="joined")
