"""日志配置：按天文件夹 + 2MB 滚动，后台/开放 API 分双日志。"""
from __future__ import annotations

import logging
import os
from datetime import date
from logging.handlers import RotatingFileHandler
from pathlib import Path

from app.core.config import get_settings

LOG_TYPE_BACKEND = "backend"
LOG_TYPE_API = "api"
API_PATH_PREFIX = "/api/v1/dialog"

# 全局 logger 名
LOGGER_BACKEND = "app.backend"
LOGGER_API = "app.api"
LOGGER_APP = "app"  # 汇聚 app.* 业务日志（pipeline、router、llm 等链式调用）


def _resolve_log_dir() -> Path:
    """解析日志根目录，相对于 backend 目录。"""
    base = Path(__file__).resolve().parent.parent.parent  # backend/
    return base / get_settings().LOG_DIR


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _get_date_dir(log_type: str) -> Path:
    """返回当日日志子目录，如 logs/backend_2026-03-10/。"""
    root = _resolve_log_dir()
    today = date.today().isoformat()
    subdir = root / f"{log_type}_{today}"
    _ensure_dir(subdir)
    return subdir


class DailyDirRotatingFileHandler(RotatingFileHandler):
    """按天建目录、单文件超 2MB 滚动的 Handler。"""

    def __init__(self, log_type: str, filename: str, max_bytes: int | None = None) -> None:
        self._log_type = log_type
        self._base_filename = filename
        settings = get_settings()
        max_bytes = max_bytes or settings.LOG_MAX_BYTES
        # 初始路径，会在 emit 时按日期更新
        self._current_date: date | None = None
        self._date_dir: Path | None = None
        filepath = self._get_filepath()
        super().__init__(filename=str(filepath), maxBytes=max_bytes, backupCount=0, encoding="utf-8")

    def _get_filepath(self) -> Path:
        date_dir = _get_date_dir(self._log_type)
        return date_dir / self._base_filename

    def _should_rollover(self, record: logging.LogRecord) -> bool:
        """若日期变化或文件超大小，则需切换。"""
        today = date.today()
        if self._current_date != today:
            return True
        return super()._should_rollover(record)

    def doRollover(self) -> None:
        """滚动：关闭当前文件，若日期变化则更新路径，否则按大小滚动。"""
        if self.stream:
            self.stream.close()
            self.stream = None

        today = date.today()
        if self._current_date != today:
            self._current_date = today
            self._date_dir = _get_date_dir(self._log_type)
            self.baseFilename = str(self._get_filepath())
        else:
            # 同一天，按大小滚动：app.txt -> app.1.txt
            if os.path.exists(self.baseFilename):
                for i in range(1, 9999):
                    backup = f"{self.baseFilename}.{i}"
                    if not os.path.exists(backup):
                        os.rename(self.baseFilename, backup)
                        break

        if not self.delay:
            self.stream = self._open()

    def emit(self, record: logging.LogRecord) -> None:
        """发射前确保路径为当日目录。"""
        today = date.today()
        if self._current_date is None:
            self._current_date = today
            self._date_dir = _get_date_dir(self._log_type)
            self.baseFilename = str(self._get_filepath())
            if self.stream:
                self.stream.close()
                self.stream = None
            self.stream = self._open()
        elif self._current_date != today:
            self.doRollover()

        super().emit(record)


class ErrorOnlyFilter(logging.Filter):
    """仅允许 ERROR 级别通过的 Filter（error.txt 专用）。"""

    def filter(self, record: logging.LogRecord) -> bool:
        return record.levelno >= logging.ERROR


class AppFormatter(logging.Formatter):
    """app.txt 用：始终不追加 traceback，保持单行可读。"""

    def formatException(self, ei) -> str:
        return ""


class ErrorFormatter(logging.Formatter):
    """error.txt 用：追加完整 traceback。"""

    def format(self, record: logging.LogRecord) -> str:
        s = super().format(record)
        if record.exc_info:
            s += "\n" + self.formatException(record.exc_info) + "\n---"
        return s


def _setup_logger(name: str, log_type: str, level: str) -> logging.Logger:
    """为 backend 或 api 配置 logger：app.txt + error.txt。"""
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    logger.propagate = False  # 不传播到 root，避免重复

    settings = get_settings()
    app_fmt = AppFormatter(
        "%(asctime)s.%(msecs)03d [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    err_fmt = ErrorFormatter(
        "%(asctime)s.%(msecs)03d [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # app.txt：INFO/WARNING/ERROR，单行无 traceback
    app_handler = DailyDirRotatingFileHandler(log_type, "app.txt", settings.LOG_MAX_BYTES)
    app_handler.setLevel(logging.INFO)
    app_handler.setFormatter(app_fmt)
    logger.addHandler(app_handler)

    # error.txt：仅 ERROR，含完整 traceback
    err_handler = DailyDirRotatingFileHandler(log_type, "error.txt", settings.LOG_MAX_BYTES)
    err_handler.setLevel(logging.ERROR)
    err_handler.setFormatter(err_fmt)
    err_handler.addFilter(ErrorOnlyFilter())
    logger.addHandler(err_handler)

    return logger


def init_logging() -> None:
    """初始化 backend / api 两套 logger，并让 app.* 业务日志汇聚到 backend 文件。"""
    settings = get_settings()
    _ensure_dir(_resolve_log_dir())
    _setup_logger(LOGGER_BACKEND, LOG_TYPE_BACKEND, settings.LOG_LEVEL_BACKEND)
    _setup_logger(LOGGER_API, LOG_TYPE_API, settings.LOG_LEVEL_API)
    # app 作为根：pipeline、router、llm 等链式调用的日志汇聚到 backend，便于按时间线排查
    _setup_logger(LOGGER_APP, LOG_TYPE_BACKEND, settings.LOG_LEVEL_BACKEND)


def get_backend_logger() -> logging.Logger:
    return logging.getLogger(LOGGER_BACKEND)


def flush_backend_logger() -> None:
    """刷新 backend logger 的 handlers，确保关键错误日志写入磁盘。"""
    log = get_backend_logger()
    for h in log.handlers:
        if hasattr(h, "flush"):
            h.flush()


def get_api_logger() -> logging.Logger:
    return logging.getLogger(LOGGER_API)


def is_api_path(path: str) -> bool:
    """是否为开放 API 路径（/api/v1/dialog 前缀）。"""
    return path.startswith(API_PATH_PREFIX)
