import redis.asyncio as aioredis

from app.core.config import get_settings

settings = get_settings()
redis_url = settings.REDIS_URL.replace("localhost", "127.0.0.1")

redis_pool = aioredis.ConnectionPool.from_url(
    redis_url,
    max_connections=20,
    decode_responses=True,
    socket_connect_timeout=0.2,
    socket_timeout=0.2,
    retry_on_timeout=False,
    health_check_interval=15,
)

redis_client = aioredis.Redis(connection_pool=redis_pool)


async def get_redis() -> aioredis.Redis:
    return redis_client


async def close_redis():
    await redis_client.aclose()
