"""请求日志中间件：按 path 分流到 backend/api logger，记录请求详情、入参、出参与耗时。"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from typing import Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from app.core.logging_config import (
    get_api_logger,
    get_backend_logger,
    is_api_path,
)

BODY_PREVIEW_LEN = 10000
RESP_PREVIEW_LEN = 200000


def _get_client_ip(request: Request) -> str:
    """从 X-Forwarded-For 或 client 获取 IP。"""
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    if request.client:
        return request.client.host or ""
    return ""


def _get_user_id(request: Request) -> str:
    """从 request.state 获取已登录用户 ID（若有）。"""
    user = getattr(request.state, "user", None)
    if user and hasattr(user, "id"):
        return str(user.id)
    return ""


def _get_device_id(request: Request) -> str:
    """从 request.state 获取 device_id（开放 API 由后续逻辑注入）。"""
    return getattr(request.state, "device_id", "") or ""


def _truncate(s: str, max_len: int, suffix: str = "\n  ...(已截断)") -> str:
    """截断并加提示。"""
    if len(s) <= max_len:
        return s
    return s[:max_len] + suffix


def _safe_body_preview(body_bytes: bytes) -> str:
    """请求体摘要，JSON 格式化、缩进显示。"""
    if not body_bytes:
        return ""
    try:
        raw = body_bytes.decode("utf-8", errors="replace")
        try:
            obj = json.loads(raw)
            formatted = json.dumps(obj, ensure_ascii=False, indent=2)
            return _truncate(formatted, BODY_PREVIEW_LEN)
        except json.JSONDecodeError:
            return _truncate(raw, BODY_PREVIEW_LEN)
    except Exception:
        return "<binary>"


def _safe_resp_preview(body_bytes: bytes) -> str:
    """响应体摘要，JSON 格式化、缩进显示。"""
    if not body_bytes:
        return ""
    try:
        raw = body_bytes.decode("utf-8", errors="replace")
        try:
            obj = json.loads(raw)
            formatted = json.dumps(obj, ensure_ascii=False, indent=2)
            return _truncate(formatted, RESP_PREVIEW_LEN)
        except json.JSONDecodeError:
            return _truncate(raw, RESP_PREVIEW_LEN)
    except Exception:
        return "<binary>"


async def _read_request_body(request: Request) -> bytes:
    """读取请求体并缓存到 scope 供路由使用，返回 body 字节。"""
    if request.method not in ("POST", "PUT", "PATCH"):
        return b""

    receive = request.receive
    chunks: list[bytes] = []
    try:
        while True:
            msg = await receive()
            if msg.get("type") == "http.request":
                chunks.append(msg.get("body", b""))
                if not msg.get("more_body", False):
                    break
    except Exception:
        return b""

    body = b"".join(chunks)

    async def replay_receive():
        return {"type": "http.request", "body": body, "more_body": False}

    request.scope["receive"] = replay_receive
    return body


async def _read_response_body(response: Response) -> bytes:
    """读取响应体并保留可回放。"""
    body = getattr(response, "body", None)
    if body is not None:
        if isinstance(body, bytes):
            return body
        if isinstance(body, str):
            return body.encode("utf-8")
        return bytes(body)

    chunks: list[bytes] = []
    it = getattr(response, "body_iterator", None)
    if it is None:
        return b""
    async for chunk in it:
        chunks.append(chunk)
    return b"".join(chunks)


def _build_log_message(
    request_id: str,
    method: str,
    path: str,
    query: str,
    status_code: int,
    latency_ms: int,
    client_ip: str,
    *,
    user_id: str = "",
    device_id: str = "",
    body_preview: str = "",
    resp_preview: str = "",
) -> str:
    """构造多行可读日志，含入参出参。"""
    parts = [f"[req={request_id}]", method, path]
    if query:
        parts.append(f"?{query}")
    parts.extend([str(status_code), f"{latency_ms}ms", f"ip={client_ip}"])
    if user_id:
        parts.append(f"user={user_id}")
    if device_id:
        parts.append(f"device={device_id}")
    line1 = " ".join(parts)

    lines = [line1]
    if body_preview:
        indented = "\n".join("    " + ln for ln in body_preview.split("\n"))
        lines.append("  body:\n" + indented)
    if resp_preview:
        indented = "\n".join("    " + ln for ln in resp_preview.split("\n"))
        lines.append("  resp:\n" + indented)
    return "\n".join(lines)


class LoggingMiddleware(BaseHTTPMiddleware):
    """记录所有 /api/v1/* 请求，含入参、出参、耗时，按 path 分流到 backend 或 api logger。"""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        path = request.url.path
        if not path.startswith("/api/v1"):
            return await call_next(request)

        request_id = request.headers.get("x-request-id") or str(uuid.uuid4())
        request.state.request_id = request_id
        start = time.perf_counter()

        # 所有 POST/PUT/PATCH 均不预读 body，回放逻辑易破坏 FastAPI 的 body 解析导致超时
        _skip_body_read = request.method in ("POST", "PUT", "PATCH")
        body_bytes = b"" if _skip_body_read else await _read_request_body(request)
        body_preview = _safe_body_preview(body_bytes) if body_bytes else ""

        # 立即记录请求开始，超时/挂起时也能追踪
        _log = get_api_logger() if is_api_path(path) else get_backend_logger()
        _log.info(
            "[req=%s] START %s %s ip=%s",
            request_id, request.method, path, _get_client_ip(request),
        )
        if body_preview:
            for line in body_preview.split("\n")[:5]:  # 前5行摘要
                _log.info("  >> %s", line[:200])

        try:
            response = await call_next(request)
            status_code = response.status_code
            latency_ms = int((time.perf_counter() - start) * 1000)
            client_ip = _get_client_ip(request)
            user_id = _get_user_id(request)
            device_id = _get_device_id(request)
            query = request.url.query or ""

            # 读取响应体（消费后需返回新 Response 以回放）
            resp_bytes = await _read_response_body(response)
            resp_preview = _safe_resp_preview(resp_bytes) if resp_bytes else ""

            # 若消费了 body_iterator，需返回新 Response 以回放内容
            if not getattr(response, "body", None) and resp_bytes:
                from starlette.responses import Response as StarletteResponse
                response = StarletteResponse(
                    content=resp_bytes,
                    status_code=response.status_code,
                    headers=dict(response.headers),
                    media_type=response.headers.get("content-type"),
                )

            msg = _build_log_message(
                request_id,
                request.method,
                path,
                query,
                status_code,
                latency_ms,
                client_ip,
                user_id=user_id,
                device_id=device_id,
                body_preview=body_preview,
                resp_preview=resp_preview,
            )

            if is_api_path(path):
                logger = get_api_logger()
            else:
                logger = get_backend_logger()

            level = logging.WARNING if status_code >= 400 else logging.INFO
            logger.log(level, msg)

            return response

        except asyncio.CancelledError:
            latency_ms = int((time.perf_counter() - start) * 1000)
            _log = get_backend_logger()
            _log.warning(
                "[req=%s] ABORTED %s %s ip=%s latency=%dms (客户端断开/超时)",
                request_id, request.method, path, _get_client_ip(request), latency_ms,
            )
            raise
        except Exception as exc:
            latency_ms = int((time.perf_counter() - start) * 1000)
            client_ip = _get_client_ip(request)
            user_id = _get_user_id(request)
            device_id = _get_device_id(request)
            query = request.url.query or ""

            msg = _build_log_message(
                request_id,
                request.method,
                path,
                query,
                500,
                latency_ms,
                client_ip,
                user_id=user_id,
                device_id=device_id,
                body_preview=body_preview,
                resp_preview="(exception)",
            )
            if is_api_path(path):
                logger = get_api_logger()
            else:
                logger = get_backend_logger()
            logger.error("%s error_type=%s error_message=%s", msg, type(exc).__name__, str(exc), exc_info=True)
            raise
