from functools import lru_cache

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    PROJECT_NAME: str = "SmartChef Dialog Management Platform"
    API_V1_PREFIX: str = "/api/v1"
    DEBUG: bool = False

    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@127.0.0.1:5432/smartchef"
    REDIS_URL: str = "redis://127.0.0.1:6379/0"

    ZENMUX_API_KEY: str = ""
    ZENMUX_BASE_URL: str = "https://zenmux.ai/api/v1"
    BRAVE_SEARCH_API_KEY: str = ""

    SECRET_KEY: str = "change-me-in-production"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480
    ALGORITHM: str = "HS256"

    ADMIN_USERNAME: str = "admin"
    ADMIN_PASSWORD: str = "admin123456"

    CORS_ORIGINS: list[str] = ["http://localhost:3000", "http://localhost:5173"]

    # API 限流 (T138)
    RATE_LIMIT_ENABLED: bool = False
    RATE_LIMIT_QPS: int = 10
    RATE_LIMIT_WINDOW_SECONDS: int = 1
    RATE_LIMIT_REDIS_TIMEOUT_MS: int = 120

    # 输入校验 (T138)
    INPUT_MAX_LENGTH: int = 2048
    INPUT_XSS_FILTER_ENABLED: bool = True

    # 数据加密 (T139)
    ENCRYPTION_KEY: str = ""
    DB_SSL_REQUIRED: bool = False

    # ONNX 模型 (T137)
    ONNX_MODEL_PATH: str = "models/intent_model.onnx"
    ONNX_CACHE_SIZE: int = 512

    # Pipeline / 对话超时：LLM 调用超时，C 端建议 15s，设备语音可改为 5s
    PIPELINE_CHAT_TIMEOUT_SECONDS: int = 15

    # 日志模块 (LOGGING_MODULE_DESIGN.md)
    LOG_DIR: str = "logs"
    LOG_LEVEL_BACKEND: str = "INFO"
    LOG_LEVEL_API: str = "INFO"
    LOG_MAX_BYTES: int = 2 * 1024 * 1024  # 2MB
    LOG_RETENTION_DAYS: int = 30

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8", "extra": "ignore"}


@lru_cache
def get_settings() -> Settings:
    return Settings()
