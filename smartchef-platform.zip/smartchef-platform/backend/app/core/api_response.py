"""Centralized API response envelope and exception handlers.

Envelope format:
    {"code": "000000", "data": <payload>, "msg": "success"}
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import TYPE_CHECKING, Any, cast

from fastapi.responses import JSONResponse, Response
from starlette.middleware.base import BaseHTTPMiddleware

if TYPE_CHECKING:
    from starlette.requests import Request

logger = logging.getLogger(__name__)


SUCCESS_CODE = "000000"
SUCCESS_MSG = "success"


def make_envelope(*, code: str, data: Any = None, msg: str = "") -> dict[str, Any]:
    return {"code": code, "data": data, "msg": msg}


def make_success(data: Any = None, msg: str = SUCCESS_MSG) -> dict[str, Any]:
    return make_envelope(code=SUCCESS_CODE, data=data, msg=msg)


def error_code_from_status(status_code: int) -> str:
    # Keep a stable 6-digit business code while preserving HTTP semantics.
    # Examples: 400 -> 400000, 404 -> 404000, 500 -> 500000
    return f"{status_code:03d}000"


def _extract_error_message(detail: Any, default: str) -> str:
    if isinstance(detail, str):
        return detail
    if isinstance(detail, dict):
        return str(detail.get("message") or detail.get("detail") or default)
    if isinstance(detail, list) and detail:
        first = detail[0]
        if isinstance(first, dict):
            loc = first.get("loc")
            msg = first.get("msg")
            if loc and msg:
                return f"{'.'.join(str(x) for x in loc)}: {msg}"
    return default


class ApiEnvelopeMiddleware(BaseHTTPMiddleware):
    """Wrap JSON success responses under {code,data,msg} for /api/v1/*."""

    def __init__(self, app, api_prefix: str = "/api/v1") -> None:
        super().__init__(app)
        self.api_prefix = api_prefix

    async def dispatch(self, request, call_next):  # type: ignore[override]
        try:
            response = await call_next(request)
        except TimeoutError:
            return JSONResponse(
                status_code=504,
                content=make_envelope(code=error_code_from_status(504), data=None, msg="Request timeout"),
            )
        except asyncio.CancelledError:
            # Client cancelled in-flight request (e.g., frontend timeout).
            return JSONResponse(
                status_code=504,
                content=make_envelope(code=error_code_from_status(504), data=None, msg="Request cancelled"),
            )

        if not request.url.path.startswith(self.api_prefix):
            return response

        content_type = response.headers.get("content-type", "").lower()
        if "application/json" not in content_type:
            return response

        body_bytes = await self._read_response_body(response)
        if not body_bytes:
            return JSONResponse(status_code=response.status_code, content=make_success(None))

        try:
            payload = json.loads(body_bytes)
        except json.JSONDecodeError:
            return response

        if (
            isinstance(payload, dict)
            and set(("code", "data", "msg")).issubset(payload.keys())
            and isinstance(payload.get("code"), str)
        ):
            return response

        if response.status_code < 400:
            wrapped = make_success(payload)
        else:
            msg = _extract_error_message(payload, default="Request failed")
            data = payload if isinstance(payload, (dict, list)) else None
            wrapped = make_envelope(
                code=error_code_from_status(response.status_code),
                data=data,
                msg=msg,
            )
        headers = {k: v for k, v in response.headers.items() if k.lower() != "content-length"}
        return JSONResponse(status_code=response.status_code, content=wrapped, headers=headers)

    async def _read_response_body(self, response: Response) -> bytes:
        body = getattr(response, "body", None)
        if body is not None:
            if isinstance(body, bytes):
                return body
            if isinstance(body, str):
                return body.encode("utf-8")
            return bytes(cast("bytearray", body))

        body_chunks: list[bytes] = []
        iterator = getattr(response, "body_iterator", None)
        if iterator is None:
            return b""

        async for chunk in iterator:  # type: ignore[misc]
            body_chunks.append(chunk)

        body_bytes = b"".join(body_chunks)

        async def replay():
            yield body_bytes

        cast("Any", response).body_iterator = replay()
        return body_bytes


async def http_exception_handler(request: Request, exc) -> JSONResponse:
    status_code = exc.status_code
    msg = _extract_error_message(exc.detail, default="Request failed")
    return JSONResponse(
        status_code=status_code,
        content=make_envelope(code=error_code_from_status(status_code), data=None, msg=msg),
    )


async def validation_exception_handler(request: Request, exc) -> JSONResponse:
    status_code = 422
    msg = _extract_error_message(exc.errors(), default="Validation error")
    return JSONResponse(
        status_code=status_code,
        content=make_envelope(code=error_code_from_status(status_code), data=None, msg=msg),
    )


async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.exception("Unhandled server error: %s", exc)
    status_code = 500
    return JSONResponse(
        status_code=status_code,
        content=make_envelope(code=error_code_from_status(status_code), data=None, msg="Internal server error"),
    )
