import time
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, require_permission
from app.core.logging_config import get_backend_logger
from app.core.database import get_db
from app.schemas.user import (
    RoleCreate,
    RoleInfo,
    RoleUpdate,
    TokenRequest,
    TokenResponse,
    UserCreate,
    UserInfo,
    UserPasswordResetResponse,
    UserUpdate,
)
from app.services import auth_service

router = APIRouter(prefix="/auth", tags=["认证与用户管理"])


@router.post("/login", response_model=TokenResponse)
async def login(body: TokenRequest, db: AsyncSession = Depends(get_db)):
    log = get_backend_logger()
    t0 = time.perf_counter()
    log.info("auth.login ENTER username=%s", body.username)
    try:
        token = await auth_service.login(db, body.username, body.password)
        ms = int((time.perf_counter() - t0) * 1000)
        log.info("auth.login OK username=%s latency=%dms", body.username, ms)
        return TokenResponse(access_token=token)
    except Exception:
        ms = int((time.perf_counter() - t0) * 1000)
        log.warning("auth.login FAIL username=%s latency=%dms", body.username, ms)
        raise


@router.get("/users", response_model=list[UserInfo])
async def get_users(
    response: Response,
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=200),
    search: str | None = Query(None, min_length=1),
    role_id: UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("user_management")),
):
    users, total = await auth_service.list_users(
        db, skip=skip, limit=limit, search=search, role_id=role_id
    )
    response.headers["X-Total-Count"] = str(total)
    return [
        UserInfo(
            id=u.id,
            username=u.username,
            display_name=u.display_name,
            role_id=u.role_id,
            role_name=u.role.name if u.role else None,
            permissions=u.role.permissions if u.role else None,
            is_active=u.is_active,
            created_at=u.created_at,
            updated_at=u.updated_at,
        )
        for u in users
    ]


@router.post("/users", response_model=UserInfo, status_code=201)
async def create_user(
    body: UserCreate,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("user_management")),
):
    user = await auth_service.create_user(db, body)
    return UserInfo(
        id=user.id,
        username=user.username,
        display_name=user.display_name,
        role_id=user.role_id,
        role_name=user.role.name if user.role else None,
        permissions=user.role.permissions if user.role else None,
        is_active=user.is_active,
        created_at=user.created_at,
        updated_at=user.updated_at,
    )


@router.patch("/users/{user_id}", response_model=UserInfo)
async def update_user(
    user_id: UUID,
    body: UserUpdate,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("user_management")),
):
    user = await auth_service.update_user(db, user_id, body)
    return UserInfo(
        id=user.id,
        username=user.username,
        display_name=user.display_name,
        role_id=user.role_id,
        role_name=user.role.name if user.role else None,
        permissions=user.role.permissions if user.role else None,
        is_active=user.is_active,
        created_at=user.created_at,
        updated_at=user.updated_at,
    )


@router.post("/users/{user_id}/password/reset", response_model=UserPasswordResetResponse)
async def reset_user_password(
    user_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission("user_management")),
):
    if not current_user.role or not current_user.role.is_system:
        raise HTTPException(status_code=403, detail="仅系统管理员可重置并查看密码")
    user, temp_password = await auth_service.reset_user_password(db, user_id)
    return UserPasswordResetResponse(
        user_id=user.id,
        username=user.username,
        temporary_password=temp_password,
    )


@router.get("/me", response_model=UserInfo)
async def get_me(current_user=Depends(get_current_user)):
    return UserInfo(
        id=current_user.id,
        username=current_user.username,
        display_name=current_user.display_name,
        role_id=current_user.role_id,
        role_name=current_user.role.name if current_user.role else None,
        permissions=current_user.role.permissions if current_user.role else None,
        is_active=current_user.is_active,
        created_at=current_user.created_at,
        updated_at=current_user.updated_at,
    )


@router.get("/roles", response_model=list[RoleInfo])
async def get_roles(
    response: Response,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    _=Depends(get_current_user),
):
    roles, total = await auth_service.list_roles(db, skip=skip, limit=limit)
    response.headers["X-Total-Count"] = str(total)
    return [RoleInfo.model_validate(r) for r in roles]


@router.post("/roles", response_model=RoleInfo, status_code=201)
async def create_role(
    body: RoleCreate,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("user_management")),
):
    role = await auth_service.create_role(db, body.name, body.permissions)
    return RoleInfo.model_validate(role)


@router.patch("/roles/{role_id}", response_model=RoleInfo)
async def update_role(
    role_id: UUID,
    body: RoleUpdate,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("user_management")),
):
    role = await auth_service.update_role(
        db, role_id, name=body.name, permissions=body.permissions
    )
    return RoleInfo.model_validate(role)
