import hashlib
from pathlib import Path
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import require_permission
from app.core.database import get_db
from app.schemas.intent import (
    EvaluateModelRequest,
    EvaluationDatasetImportRequest,
    EvaluationDatasetCreate,
    EvaluationDatasetInfo,
    EvaluationRunInfo,
    IntentInfo,
    IntentLibraryCreate,
    IntentLibraryInfo,
    IntentLibraryListResponse,
    IntentLibraryUpdate,
    LibraryModelVersionInfo,
    ModelSingleTestRequest,
    ModelSingleTestResponse,
    PublishModelRequest,
    SlotInfo,
    TrainModelRequest,
    TrainingDatasetImportRequest,
    TrainingDatasetCreate,
    TrainingDatasetInfo,
)
from app.services import intent_service

# 使用 /libraries 避免与 /intents/{intent_id} 路径重叠，消除路由顺序依赖
router = APIRouter(prefix="/libraries", tags=["指令库管理"])


@router.post("", response_model=IntentLibraryInfo, status_code=201)
@router.post("/", response_model=IntentLibraryInfo, status_code=201)
async def create_intent_library(
    body: IntentLibraryCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission("intent_management.write")),
):
    library = await intent_service.create_intent_library(db, body, current_user.id)
    return IntentLibraryInfo.model_validate(
        {
            "library_key": library.library_key,
            "display_name": library.display_name,
            "language": library.language,
            "description": library.description,
            "default_intent_f1_threshold": library.default_intent_f1_threshold,
            "default_slot_f1_threshold": library.default_slot_f1_threshold,
            "intent_count": 0,
        }
    )


@router.get("", response_model=IntentLibraryListResponse)
@router.get("/", response_model=IntentLibraryListResponse)
async def list_intent_libraries(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=200),
    language: str | None = Query(None, pattern="^(zh|en)$"),
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.read")),
):
    libraries, total = await intent_service.list_intent_libraries(
        db, skip=skip, limit=limit, language=language
    )
    return IntentLibraryListResponse(
        items=[IntentLibraryInfo.model_validate(item) for item in libraries],
        total=total,
    )


@router.patch("/{library_key}", response_model=IntentLibraryInfo)
async def update_intent_library(
    library_key: str,
    body: IntentLibraryUpdate,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.write")),
):
    library = await intent_service.update_intent_library(db, library_key, body)
    return IntentLibraryInfo.model_validate(
        {
            "library_key": library.library_key,
            "display_name": library.display_name,
            "language": library.language,
            "description": library.description,
            "default_intent_f1_threshold": library.default_intent_f1_threshold,
            "default_slot_f1_threshold": library.default_slot_f1_threshold,
            "intent_count": 0,
        }
    )


@router.delete("/{library_key}", status_code=204)
async def delete_intent_library(
    library_key: str,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.delete")),
):
    await intent_service.delete_intent_library(db, library_key)


@router.get("/{library_key}/intents", response_model=list[IntentInfo])
async def list_library_intents(
    library_key: str,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.read")),
):
    intents, _ = await intent_service.list_intents(db, category=library_key, skip=skip, limit=limit)
    return [
        IntentInfo(
            id=intent.id,
            intent_key=intent.intent_key,
            display_name=intent.display_name,
            category=intent.category,
            description=intent.description,
            is_active=intent.is_active,
            slots=[SlotInfo.model_validate(s) for s in intent.slots],
            training_data_count=getattr(intent, "_td_count", 0),
            created_at=intent.created_at,
            updated_at=intent.updated_at,
        )
        for intent in intents
    ]


@router.get("/{library_key}/models", response_model=list[LibraryModelVersionInfo])
async def list_library_models(
    library_key: str,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.read")),
):
    models = await intent_service.list_library_models(db, library_key)
    return [LibraryModelVersionInfo.model_validate(m) for m in models]


@router.post("/{library_key}/training-datasets", response_model=TrainingDatasetInfo, status_code=201)
async def create_training_dataset(
    library_key: str,
    body: TrainingDatasetCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission("intent_management.write")),
):
    dataset = await intent_service.create_training_dataset(db, library_key, body, current_user.id)
    return TrainingDatasetInfo.model_validate(dataset)


@router.get("/{library_key}/training-datasets", response_model=list[TrainingDatasetInfo])
async def list_training_datasets(
    library_key: str,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.read")),
):
    datasets = await intent_service.list_training_datasets(db, library_key)
    return [TrainingDatasetInfo.model_validate(d) for d in datasets]


@router.post("/{library_key}/training-datasets/{dataset_id}/import", response_model=TrainingDatasetInfo)
async def import_training_dataset(
    library_key: str,
    dataset_id: UUID,
    body: TrainingDatasetImportRequest,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.write")),
):
    dataset = await intent_service.import_training_dataset_rows(
        db, library_key, dataset_id, body
    )
    return TrainingDatasetInfo.model_validate(dataset)


@router.get("/{library_key}/training-datasets/{dataset_id}/rows")
async def get_training_dataset_rows(
    library_key: str,
    dataset_id: UUID,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.read")),
):
    rows = await intent_service.get_training_dataset_rows(db, library_key, dataset_id)
    return {"rows": rows}


@router.post("/{library_key}/evaluation-datasets", response_model=EvaluationDatasetInfo, status_code=201)
async def create_evaluation_dataset(
    library_key: str,
    body: EvaluationDatasetCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission("intent_management.write")),
):
    dataset = await intent_service.create_evaluation_dataset(db, library_key, body, current_user.id)
    return EvaluationDatasetInfo.model_validate(dataset)


@router.get("/{library_key}/evaluation-datasets", response_model=list[EvaluationDatasetInfo])
async def list_evaluation_datasets(
    library_key: str,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.read")),
):
    datasets = await intent_service.list_evaluation_datasets(db, library_key)
    return [EvaluationDatasetInfo.model_validate(d) for d in datasets]


@router.post("/{library_key}/evaluation-datasets/{dataset_id}/import", response_model=EvaluationDatasetInfo)
async def import_evaluation_dataset(
    library_key: str,
    dataset_id: UUID,
    body: EvaluationDatasetImportRequest,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.write")),
):
    dataset = await intent_service.import_evaluation_dataset_rows(
        db, library_key, dataset_id, body
    )
    return EvaluationDatasetInfo.model_validate(dataset)


@router.get("/{library_key}/evaluation-datasets/{dataset_id}/rows")
async def get_evaluation_dataset_rows(
    library_key: str,
    dataset_id: UUID,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.read")),
):
    rows = await intent_service.get_evaluation_dataset_rows(db, library_key, dataset_id)
    return {"rows": rows}


@router.post("/{library_key}/models/train", response_model=LibraryModelVersionInfo, status_code=201)
async def train_library_model(
    library_key: str,
    body: TrainModelRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission("intent_management.write")),
):
    model = await intent_service.train_library_model(db, library_key, body, current_user.id)
    return LibraryModelVersionInfo.model_validate(model)


@router.post("/{library_key}/models/{model_id}/testable", response_model=LibraryModelVersionInfo)
async def set_model_testable(
    library_key: str,
    model_id: UUID,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("model_test_manage")),
):
    model = await intent_service.set_model_testable(db, library_key, model_id)
    return LibraryModelVersionInfo.model_validate(model)


@router.post("/{library_key}/models/{model_id}/publish", response_model=LibraryModelVersionInfo)
async def publish_model(
    library_key: str,
    model_id: UUID,
    body: PublishModelRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission("model_publish")),
):
    if not body.confirm_publish:
        raise HTTPException(status_code=422, detail="请先确认发布")
    model = await intent_service.publish_library_model(
        db,
        library_key,
        model_id,
        current_user.id,
        publish_note=body.publish_note,
    )
    return LibraryModelVersionInfo.model_validate(model)


@router.post("/{library_key}/models/{model_id}/archive", response_model=LibraryModelVersionInfo)
async def archive_model(
    library_key: str,
    model_id: UUID,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.write")),
):
    model = await intent_service.archive_library_model(db, library_key, model_id)
    return LibraryModelVersionInfo.model_validate(model)


@router.post("/{library_key}/models/{model_id}/restore", response_model=LibraryModelVersionInfo)
async def restore_model(
    library_key: str,
    model_id: UUID,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.write")),
):
    model = await intent_service.restore_library_model(db, library_key, model_id)
    return LibraryModelVersionInfo.model_validate(model)


@router.post("/{library_key}/models/{model_id}/evaluate", response_model=EvaluationRunInfo, status_code=201)
async def evaluate_model(
    library_key: str,
    model_id: UUID,
    body: EvaluateModelRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission("intent_management.write")),
):
    run = await intent_service.evaluate_library_model(db, library_key, model_id, body, current_user.id)
    return EvaluationRunInfo.model_validate(run)


@router.get("/{library_key}/models/{model_id}/evaluations", response_model=list[EvaluationRunInfo])
async def list_model_evaluations(
    library_key: str,
    model_id: UUID,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.read")),
):
    runs = await intent_service.list_evaluation_runs(db, library_key, model_id)
    return [EvaluationRunInfo.model_validate(r) for r in runs]


@router.post(
    "/{library_key}/models/{model_id}/test-one",
    response_model=ModelSingleTestResponse,
)
async def test_model_single(
    library_key: str,
    model_id: UUID,
    body: ModelSingleTestRequest,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("model_test_manage")),
):
    result = await intent_service.run_model_single_test(db, library_key, model_id, body)
    return ModelSingleTestResponse.model_validate(result)


@router.post("/{library_key}/models/{model_id}/artifact")
async def register_model_artifact(
    library_key: str,
    model_id: UUID,
    artifact_type: str,
    artifact_uri: str,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.write")),
):
    models = await intent_service.list_library_models(db, library_key)
    model = next((m for m in models if m.id == model_id), None)
    if not model:
        raise HTTPException(status_code=404, detail="模型版本不存在")
    model.artifact_type = artifact_type
    model.artifact_uri = artifact_uri
    path = Path(artifact_uri)
    if path.exists() and path.is_file():
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        model.artifact_sha256 = sha
    await db.flush()
    await db.refresh(model)
    return {
        "model_id": str(model.id),
        "artifact_type": model.artifact_type,
        "artifact_uri": model.artifact_uri,
        "artifact_sha256": model.artifact_sha256,
    }


@router.get("/{library_key}/models/{model_id}/artifact/download")
async def download_model_artifact(
    library_key: str,
    model_id: UUID,
    expected_sha256: str | None = Query(None, min_length=64, max_length=64),
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("intent_management.read")),
):
    models = await intent_service.list_library_models(db, library_key)
    model = next((m for m in models if m.id == model_id), None)
    if not model or not model.artifact_uri:
        raise HTTPException(status_code=404, detail="模型产物不存在")
    path = Path(model.artifact_uri)
    if not path.exists():
        raise HTTPException(status_code=404, detail="模型产物文件不存在")
    actual_sha = hashlib.sha256(path.read_bytes()).hexdigest()
    if model.artifact_sha256 and model.artifact_sha256 != actual_sha:
        raise HTTPException(status_code=409, detail="模型产物哈希与登记值不一致")
    if expected_sha256 and expected_sha256.lower() != actual_sha.lower():
        raise HTTPException(status_code=409, detail="模型产物哈希校验失败")
    return FileResponse(
        path=path,
        filename=path.name,
        media_type="application/octet-stream",
        headers={"X-Artifact-Sha256": actual_sha},
    )
