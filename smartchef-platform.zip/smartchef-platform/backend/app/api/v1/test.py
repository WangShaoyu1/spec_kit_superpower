import asyncio
import logging
import time
from typing import cast
from uuid import UUID

import redis.asyncio as aioredis
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.api.deps import require_permission
from app.core.config import get_settings
from app.core.database import get_db
from app.core.redis import get_redis
from app.models.dialog_profile import DialogProfile
from app.models.intent import Intent
from app.models.intent_library import IntentLibrary
from app.models.test_session import TestSession
from app.schemas.test import (
    TestChatRequest,
    TestChatResponse,
    TestSessionCreate,
    TestSessionInfo,
    TestSessionUpdate,
)
from app.services.chitchat.llm_adapter import chat_completion
from app.services import intent_service
from app.services.nlu.pipeline import PipelineConfig, run_pipeline

router = APIRouter(prefix="/test", tags=["手动测试"])
logger = logging.getLogger(__name__)


@router.get("/sessions", response_model=list[TestSessionInfo])
async def list_test_sessions(
    response: Response,
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("test_debug.read")),
):
    total = (await db.execute(select(func.count()).select_from(TestSession))).scalar() or 0
    response.headers["X-Total-Count"] = str(total)
    result = await db.execute(
        select(TestSession).order_by(TestSession.created_at.desc()).offset(skip).limit(limit)
    )
    return [TestSessionInfo.model_validate(s) for s in result.scalars().all()]


@router.post("/sessions", response_model=TestSessionInfo, status_code=201)
async def create_test_session(
    body: TestSessionCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission("test_debug.write")),
):
    result = await db.execute(select(DialogProfile).where(DialogProfile.id == body.profile_id))
    profile = result.scalar_one_or_none()
    if not profile:
        raise HTTPException(status_code=404, detail="对话方案不存在")

    session = TestSession(
        name=body.name, profile_id=body.profile_id,
        device_context=body.device_context, notes=body.notes,
        created_by=current_user.id,
    )
    db.add(session)
    await db.flush()
    await db.refresh(session)
    return TestSessionInfo.model_validate(session)


@router.patch("/sessions/{session_id}", response_model=TestSessionInfo)
async def update_test_session(
    session_id: UUID,
    body: TestSessionUpdate,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("test_debug.write")),
):
    result = await db.execute(select(TestSession).where(TestSession.id == session_id))
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="测试会话不存在")

    updates = body.model_dump(exclude_unset=True)
    if not updates:
        return TestSessionInfo.model_validate(session)

    if "profile_id" in updates:
        profile_result = await db.execute(
            select(DialogProfile).where(DialogProfile.id == updates["profile_id"])
        )
        if not profile_result.scalar_one_or_none():
            raise HTTPException(status_code=404, detail="对话方案不存在")

    for key, value in updates.items():
        setattr(session, key, value)

    await db.flush()
    await db.refresh(session)
    return TestSessionInfo.model_validate(session)


@router.delete("/sessions/{session_id}", status_code=204)
async def delete_test_session(
    session_id: UUID,
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("test_debug.write")),
):
    result = await db.execute(select(TestSession).where(TestSession.id == session_id))
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="测试会话不存在")

    await db.delete(session)
    await db.flush()


@router.get("/probe")
async def test_probe(
    db: AsyncSession = Depends(get_db),
    redis: aioredis.Redis = Depends(get_redis),
    _=Depends(require_permission("test_debug.read")),
):
    """分阶段诊断：依次测试 DB、Redis、LLM，快速定位哪个环节出问题。"""
    stages = {}
    settings = get_settings()

    # 1. DB
    t0 = time.perf_counter()
    try:
        await db.execute(text("SELECT 1"))
        stages["db"] = {"ok": True, "latency_ms": int((time.perf_counter() - t0) * 1000)}
    except Exception as e:
        stages["db"] = {"ok": False, "error": str(e)}

    # 2. Redis
    t0 = time.perf_counter()
    try:
        await redis.ping()
        stages["redis"] = {"ok": True, "latency_ms": int((time.perf_counter() - t0) * 1000)}
    except Exception as e:
        stages["redis"] = {"ok": False, "error": str(e)}

    # 3. LLM (ZenMux)
    t0 = time.perf_counter()
    try:
        out = await asyncio.wait_for(
            chat_completion(
                [{"role": "user", "content": "回复一个字：好"}],
                model="gpt-4o-mini",
                temperature=0,
            ),
            timeout=15.0,
        )
        stages["llm"] = {
            "ok": True,
            "latency_ms": int((time.perf_counter() - t0) * 1000),
            "response_preview": (out[:50] + "..." if len(out) > 50 else out),
            "model_used": "openai/gpt-4o-mini",
        }
    except TimeoutError:
        stages["llm"] = {"ok": False, "error": "timeout_15s", "latency_ms": 15000}
    except Exception as e:
        stages["llm"] = {
            "ok": False,
            "error": str(e)[:200],
            "latency_ms": int((time.perf_counter() - t0) * 1000),
        }

    return {"stages": stages, "zenmux_configured": bool(settings.ZENMUX_API_KEY)}


@router.post("/chat", response_model=TestChatResponse)
async def test_chat(
    body: TestChatRequest,
    db: AsyncSession = Depends(get_db),
    redis: aioredis.Redis = Depends(get_redis),
    _=Depends(require_permission("test_debug.write")),
):
    result = await db.execute(
        select(TestSession).where(TestSession.id == body.session_id)
    )
    test_session = result.scalar_one_or_none()
    if not test_session:
        raise HTTPException(status_code=404, detail="测试会话不存在")

    result = await db.execute(
        select(DialogProfile).where(DialogProfile.id == test_session.profile_id)
    )
    profile = cast("DialogProfile | None", result.scalar_one_or_none())
    if not profile:
        raise HTTPException(status_code=404, detail="对话方案不存在")

    intents_query = select(Intent).options(
        selectinload(Intent.slots),
        selectinload(Intent.training_data),
    )
    if profile.intent_library_keys:
        intents_query = intents_query.where(Intent.category.in_(profile.intent_library_keys))
    intents_result = await db.execute(intents_query)
    intents = intents_result.scalars().unique().all()

    registered = []
    for intent in intents:
        registered.append({
            "intent_key": intent.intent_key,
            "display_name": intent.display_name,
            "category": intent.category,
            "library_key": intent.category,
            "slots": [
                {"slot_key": s.slot_key, "entity_type": s.entity_type,
                 "is_required": s.is_required, "prompt_text": s.prompt_text,
                 "display_name": s.display_name, "sort_order": s.sort_order}
                for s in (intent.slots or [])
            ],
            "training_texts": [td.text for td in (intent.training_data or [])],
        })

    persona_data = None
    if profile.persona:
        persona_data = {
            "name": profile.persona.name,
            "personality": profile.persona.personality,
            "tone_style": profile.persona.tone_style,
            "system_prompt": profile.persona.system_prompt,
        }

    intent_libraries: list[dict] = []
    if profile.intent_library_keys:
        library_result = await db.execute(
            select(IntentLibrary).where(IntentLibrary.library_key.in_(profile.intent_library_keys))
        )
        intent_libraries = [
            {"library_key": lib.library_key, "language": lib.language}
            for lib in library_result.scalars().all()
        ]
    published_models = await intent_service.get_library_published_models(
        db, profile.intent_library_keys or []
    )

    config = PipelineConfig(
        profile_id=profile.id,
        llm_provider=profile.llm_provider,
        llm_config=profile.llm_config or {},
        persona_data=persona_data,
        routing_strategy=profile.routing_strategy,
        session_timeout_minutes=profile.session_timeout_minutes,
        command_threshold=profile.command_threshold,
        intent_library_keys=profile.intent_library_keys or [],
        intent_libraries=intent_libraries,
        published_models=published_models,
        registered_intents=registered,
        knowledge_base_ids=profile.knowledge_base_ids or [],
        has_knowledge_base=bool(profile.knowledge_base_ids),
    )

    device_id = f"test_{test_session.id}"
    pipeline_timeout = get_settings().PIPELINE_CHAT_TIMEOUT_SECONDS
    try:
        pipeline_result = await asyncio.wait_for(
            run_pipeline(
                db=db, redis=redis, text=body.text,
                device_id=device_id, device_context=test_session.device_context,
                config=config,
            ),
            timeout=pipeline_timeout,
        )
    except TimeoutError:
        logger.warning(
            "Pipeline timeout session_id=%s timeout=%ss",
            body.session_id,
            pipeline_timeout,
        )
        return TestChatResponse(
            domain="chitchat",
            route_confidence=0.0,
            intent=None,
            intent_confidence=None,
            slots={},
            response_text="抱歉，当前请求处理超时，请稍后重试。",
            needs_followup=False,
            language="zh",
            latency_ms=int(pipeline_timeout * 1000),
            debug_info={"fallback_reason": "pipeline_timeout"},
        )
    except Exception as exc:
        error_text = str(exc).lower()
        is_llm_csrf_error = ("csrf" in error_text) and ("token" in error_text)
        if not is_llm_csrf_error:
            raise

        logger.warning("LLM provider csrf token failure; using graceful fallback: %s", exc)
        return TestChatResponse(
            domain="chitchat",
            route_confidence=0.0,
            intent=None,
            intent_confidence=None,
            slots={},
            response_text="抱歉，当前模型服务暂时不可用，请稍后重试。",
            needs_followup=False,
            language="zh",
            latency_ms=0,
            debug_info={"fallback_reason": "llm_invalid_csrf_token"},
        )

    return TestChatResponse(
        domain=pipeline_result.domain,
        route_confidence=pipeline_result.route_confidence,
        intent=pipeline_result.intent,
        intent_confidence=pipeline_result.intent_confidence,
        slots=pipeline_result.slots,
        response_text=pipeline_result.response_text,
        needs_followup=pipeline_result.needs_followup,
        language=pipeline_result.language,
        latency_ms=pipeline_result.latency_ms,
        debug_info=pipeline_result.debug_info,
    )
