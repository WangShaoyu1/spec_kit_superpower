from uuid import UUID

import redis.asyncio as aioredis
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import require_permission
from app.core.database import get_db
from app.core.redis import get_redis
from app.models.dialog_profile import DialogProfile
from app.models.intent_library import IntentLibrary
from app.models.published_version import PublishedVersion
from app.services import intent_service
from app.services.session.device_session import clear_all_sessions

router = APIRouter(prefix="/versions", tags=["版本管理"])


@router.get("")
async def list_versions(
    response: Response,
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    _=Depends(require_permission("version_publish.read")),
):
    total = (await db.execute(select(func.count()).select_from(PublishedVersion))).scalar() or 0
    response.headers["X-Total-Count"] = str(total)
    result = await db.execute(
        select(PublishedVersion)
        .order_by(PublishedVersion.created_at.desc())
        .offset(skip)
        .limit(limit)
    )
    versions = result.scalars().all()
    return [
        {
            "id": str(v.id), "version_tag": v.version_tag,
            "profile_id": str(v.profile_id), "description": v.description,
            "is_active": v.is_active, "created_at": v.created_at.isoformat(),
        }
        for v in versions
    ]


@router.post("", status_code=201)
async def publish_version(
    profile_id: UUID, version_tag: str, description: str | None = None,
    db: AsyncSession = Depends(get_db),
    redis: aioredis.Redis = Depends(get_redis),
    current_user=Depends(require_permission("version_publish.write")),
):
    result = await db.execute(select(DialogProfile).where(DialogProfile.id == profile_id))
    profile = result.scalar_one_or_none()
    if not profile:
        raise HTTPException(status_code=404, detail="对话方案不存在")
    if not profile.intent_library_keys:
        raise HTTPException(status_code=422, detail="发布前校验失败：请至少绑定一个指令库")
    if profile.command_threshold < 0 or profile.command_threshold > 1:
        raise HTTPException(status_code=422, detail="发布前校验失败：指令阈值需在 0~1 之间")
    keys = profile.intent_library_keys or []
    existing = await db.execute(
        select(IntentLibrary.library_key).where(IntentLibrary.library_key.in_(keys))
    )
    existing_keys = {row[0] for row in existing.all()}
    missing = [k for k in keys if k not in existing_keys]
    if missing:
        raise HTTPException(status_code=422, detail=f"发布前校验失败：指令库不存在 {', '.join(missing)}")
    without_published_model: list[str] = []
    for key in keys:
        has_published = await intent_service.ensure_library_has_published_model(db, key)
        if not has_published:
            without_published_model.append(key)
    if without_published_model:
        raise HTTPException(
            status_code=422,
            detail=(
                "发布前校验失败：以下指令库无 published 模型 "
                + ", ".join(without_published_model)
            ),
        )

    await db.execute(update(PublishedVersion).where(PublishedVersion.is_active).values(is_active=False))
    await db.execute(update(DialogProfile).values(status="draft"))
    profile.status = "published"

    version = PublishedVersion(
        profile_id=profile_id, version_tag=version_tag,
        description=description, is_active=True,
        published_by=current_user.id,
    )
    db.add(version)
    await db.flush()

    cleared = await clear_all_sessions(redis)

    return {
        "id": str(version.id), "version_tag": version_tag,
        "is_active": True, "sessions_cleared": cleared,
    }


@router.post("/{version_id}/activate")
async def activate_version(
    version_id: UUID,
    db: AsyncSession = Depends(get_db),
    redis: aioredis.Redis = Depends(get_redis),
    _=Depends(require_permission("version_publish.write")),
):
    result = await db.execute(select(PublishedVersion).where(PublishedVersion.id == version_id))
    version = result.scalar_one_or_none()
    if not version:
        raise HTTPException(status_code=404, detail="版本不存在")

    await db.execute(update(PublishedVersion).where(PublishedVersion.is_active).values(is_active=False))
    profile_result = await db.execute(select(DialogProfile).where(DialogProfile.id == version.profile_id))
    profile = profile_result.scalar_one_or_none()
    if profile:
        await db.execute(update(DialogProfile).values(status="draft"))
        profile.status = "published"
    version.is_active = True
    await db.flush()

    cleared = await clear_all_sessions(redis)

    return {"status": "ok", "version_tag": version.version_tag, "sessions_cleared": cleared}
