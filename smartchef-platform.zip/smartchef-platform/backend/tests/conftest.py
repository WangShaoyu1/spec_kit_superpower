import asyncio

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from app.core.database import Base, get_db
from app.core.security import create_access_token, hash_password
from app.main import app
from app.models import (  # noqa: F401
    alert_rule,
    batch_test,
    dialog_profile,
    intent,
    intent_library,
    knowledge,
    library_model,
    persona,
    published_version,
    request_log,
    test_session,
    test_suite,
)
from app.models.user import Role, User

TEST_DATABASE_URL = "postgresql+asyncpg://postgres:postgres@127.0.0.1:5432/smartchef_test"

# Use NullPool to avoid reusing asyncpg connections across test cases.
test_engine = create_async_engine(
    TEST_DATABASE_URL,
    echo=False,
    poolclass=NullPool,
)
test_session_factory = async_sessionmaker(test_engine, class_=AsyncSession, expire_on_commit=False)


@pytest.fixture(scope="session")
def event_loop():
    """Use one event loop for the entire test session.

    This avoids cross-loop issues for module-level async engine/session fixtures.
    """
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(autouse=True)
async def clean_db():
    """Reset test data between test cases while keeping schema stable."""
    async with test_engine.begin() as conn:
        for table in reversed(Base.metadata.sorted_tables):
            await conn.execute(text(f'TRUNCATE TABLE "{table.name}" RESTART IDENTITY CASCADE'))
    yield


@pytest.fixture(scope="session", autouse=True)
async def setup_db():
    """Create/drop schema once per test session."""
    async with test_engine.begin() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await test_engine.dispose()


@pytest.fixture
async def db_session():
    async with test_session_factory() as session:
        yield session


@pytest.fixture
async def client(db_session):
    async def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac

    app.dependency_overrides.clear()


@pytest.fixture
async def admin_role(db_session):
    role = Role(
        name="管理员",
        permissions={
            "intent_management": {"read": True, "write": True, "delete": True},
            "knowledge_management": {"read": True, "write": True, "delete": True},
            "dialog_profile": {"read": True, "write": True, "delete": True},
            "testing": {"manual": True, "batch": True},
            "test_debug": {"read": True, "write": True},
            "version_publish": True,
            "monitoring": {"dashboard": True, "device_logs": True, "alerts": True},
            "user_management": True,
            "data_management": True,
            "model_publish": True,
            "model_test_manage": True,
        },
        is_system=True,
    )
    db_session.add(role)
    await db_session.flush()
    return role


@pytest.fixture
async def admin_user(db_session, admin_role):
    user = User(
        username="testadmin",
        password_hash=hash_password("test123456"),
        display_name="测试管理员",
        role_id=admin_role.id,
        is_active=True,
    )
    db_session.add(user)
    await db_session.flush()
    return user


@pytest.fixture
async def admin_token(admin_user):
    return create_access_token(data={"sub": str(admin_user.id), "username": admin_user.username})


@pytest.fixture
async def auth_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}
