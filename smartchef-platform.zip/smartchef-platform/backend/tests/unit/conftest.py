import pytest


@pytest.fixture(autouse=True)
async def setup_db():
    """Override parent conftest's setup_db — unit tests don't need a database."""
    yield


@pytest.fixture(autouse=True)
async def clean_db():
    """Override parent conftest's clean_db — unit tests don't need a database."""
    yield
