"""单元测试：日志中间件与配置。"""
import pytest
from starlette.requests import Request
from starlette.responses import JSONResponse

from app.core.logging_config import (
    init_logging,
    get_backend_logger,
    get_api_logger,
    is_api_path,
    LOGGER_BACKEND,
    LOGGER_API,
)


class TestLoggingConfig:
    def test_is_api_path(self):
        assert is_api_path("/api/v1/dialog/chat") is True
        assert is_api_path("/api/v1/dialog/parse") is True
        assert is_api_path("/api/v1/dialog/reset") is True
        assert is_api_path("/api/v1/intents") is False
        assert is_api_path("/api/v1/auth/login") is False
        assert is_api_path("/api/v1/health") is False

    def test_init_logging_creates_loggers(self):
        init_logging()
        backend = get_backend_logger()
        api = get_api_logger()
        assert backend.name == LOGGER_BACKEND
        assert api.name == LOGGER_API
        assert len(backend.handlers) >= 1
        assert len(api.handlers) >= 1

    def test_loggers_accept_log_calls(self):
        init_logging()
        get_backend_logger().info("backend test message")
        get_api_logger().info("api test message")
        # 无异常即通过

    def test_build_log_message_includes_body_resp(self):
        from app.core.logging_middleware import _build_log_message
        msg = _build_log_message(
            "req-1", "POST", "/api/v1/intents", "",
            200, 45, "192.168.1.1",
            user_id="u-001",
            body_preview='{"intent_key":"voice_cmd_start"}',
            resp_preview='{"id":"xxx","intent_key":"voice_cmd_start"}',
        )
        assert "body:" in msg
        assert "resp:" in msg
        assert "voice_cmd_start" in msg
