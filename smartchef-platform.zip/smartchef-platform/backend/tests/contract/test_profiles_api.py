import pytest
from httpx import AsyncClient


def _success_data(resp):
    payload = resp.json()
    if isinstance(payload, dict) and {"code", "data", "msg"}.issubset(payload.keys()):
        assert payload["code"] == "000000"
        return payload["data"]
    return payload


@pytest.mark.asyncio
async def test_create_persona(client: AsyncClient, auth_headers):
    resp = await client.post(
        "/api/v1/profiles/personas",
        json={
            "name": "小厨",
            "personality": "活泼友好、热情开朗",
            "tone_style": "亲切随和、带有趣味",
            "system_prompt": "你是一个名叫小厨的友好厨房助手",
        },
        headers=auth_headers,
    )
    assert resp.status_code == 201
    assert _success_data(resp)["name"] == "小厨"


@pytest.mark.asyncio
async def test_create_dialog_profile(client: AsyncClient, auth_headers):
    await client.post(
        "/api/v1/libraries",
        json={"library_key": "zh_cmd", "display_name": "中文库", "language": "zh"},
        headers=auth_headers,
    )
    resp = await client.post(
        "/api/v1/profiles",
        json={
            "name": "方案A - GPT-4o 活泼版",
            "description": "使用 GPT-4o 配合活泼人设",
            "llm_provider": "gpt-4o",
            "routing_strategy": "command_first",
            "session_timeout_minutes": 10,
            "command_threshold": 0.7,
            "intent_library_keys": ["zh_cmd"],
        },
        headers=auth_headers,
    )
    assert resp.status_code == 201
    data = _success_data(resp)
    assert data["name"] == "方案A - GPT-4o 活泼版"
    assert data["llm_provider"] == "gpt-4o"
    assert data["routing_strategy"] == "command_first"
    assert data["status"] == "draft"
    assert data["command_threshold"] == 0.7
    assert data["intent_library_keys"] == ["zh_cmd"]


@pytest.mark.asyncio
async def test_list_profiles(client: AsyncClient, auth_headers):
    await client.post(
        "/api/v1/libraries",
        json={"library_key": "zh_cmd", "display_name": "中文库", "language": "zh"},
        headers=auth_headers,
    )
    await client.post(
        "/api/v1/profiles",
        json={"name": "方案1", "llm_provider": "gpt-4o", "intent_library_keys": ["zh_cmd"]},
        headers=auth_headers,
    )
    resp = await client.get("/api/v1/profiles", headers=auth_headers)
    assert resp.status_code == 200
    assert len(_success_data(resp)) >= 1


@pytest.mark.asyncio
async def test_update_profile(client: AsyncClient, auth_headers):
    await client.post(
        "/api/v1/libraries",
        json={"library_key": "zh_cmd", "display_name": "中文库", "language": "zh"},
        headers=auth_headers,
    )
    await client.post(
        "/api/v1/libraries",
        json={"library_key": "en_cmd", "display_name": "英文库", "language": "en"},
        headers=auth_headers,
    )
    create_resp = await client.post(
        "/api/v1/profiles",
        json={"name": "更新前", "llm_provider": "gpt-4o", "intent_library_keys": ["zh_cmd"]},
        headers=auth_headers,
    )
    profile_id = _success_data(create_resp)["id"]
    resp = await client.patch(
        f"/api/v1/profiles/{profile_id}",
        json={"name": "更新后", "llm_provider": "qwen-max", "intent_library_keys": ["zh_cmd", "en_cmd"]},
        headers=auth_headers,
    )
    assert resp.status_code == 200
    data = _success_data(resp)
    assert data["name"] == "更新后"
    assert data["llm_provider"] == "qwen-max"
    assert sorted(data["intent_library_keys"]) == ["en_cmd", "zh_cmd"]


@pytest.mark.asyncio
async def test_delete_profile(client: AsyncClient, auth_headers):
    await client.post(
        "/api/v1/libraries",
        json={"library_key": "zh_cmd", "display_name": "中文库", "language": "zh"},
        headers=auth_headers,
    )
    create_resp = await client.post(
        "/api/v1/profiles",
        json={"name": "待删除", "llm_provider": "gpt-4o", "intent_library_keys": ["zh_cmd"]},
        headers=auth_headers,
    )
    profile_id = _success_data(create_resp)["id"]
    resp = await client.delete(f"/api/v1/profiles/{profile_id}", headers=auth_headers)
    assert resp.status_code == 204


@pytest.mark.asyncio
async def test_profile_with_persona(client: AsyncClient, auth_headers):
    await client.post(
        "/api/v1/libraries",
        json={"library_key": "zh_cmd", "display_name": "中文库", "language": "zh"},
        headers=auth_headers,
    )
    persona_resp = await client.post(
        "/api/v1/profiles/personas",
        json={
            "name": "测试人设",
            "personality": "专业可靠",
            "tone_style": "简洁专业",
            "system_prompt": "你是一个专业的厨房助手",
        },
        headers=auth_headers,
    )
    persona_id = _success_data(persona_resp)["id"]

    profile_resp = await client.post(
        "/api/v1/profiles",
        json={
            "name": "带人设方案",
            "llm_provider": "gpt-4o",
            "persona_id": persona_id,
            "intent_library_keys": ["zh_cmd"],
        },
        headers=auth_headers,
    )
    assert profile_resp.status_code == 201
    data = _success_data(profile_resp)
    assert data["persona"] is not None
    assert data["persona"]["name"] == "测试人设"
