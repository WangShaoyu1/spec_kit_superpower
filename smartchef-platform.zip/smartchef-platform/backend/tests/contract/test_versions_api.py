import pytest
from httpx import AsyncClient


def _success_data(resp):
    payload = resp.json()
    if isinstance(payload, dict) and {"code", "data", "msg"}.issubset(payload.keys()):
        assert payload["code"] == "000000"
        return payload["data"]
    return payload


@pytest.mark.asyncio
async def test_publish_version_blocks_when_library_has_no_published_model(
    client: AsyncClient, auth_headers
):
    lib_resp = await client.post(
        "/api/v1/libraries",
        json={"library_key": "zh_gate", "display_name": "中文门禁库", "language": "zh"},
        headers=auth_headers,
    )
    assert lib_resp.status_code == 201

    profile_resp = await client.post(
        "/api/v1/profiles",
        json={"name": "门禁方案", "llm_provider": "gpt-4o", "intent_library_keys": ["zh_gate"]},
        headers=auth_headers,
    )
    assert profile_resp.status_code == 201
    profile_id = _success_data(profile_resp)["id"]

    publish_resp = await client.post(
        "/api/v1/versions",
        params={"profile_id": profile_id, "version_tag": "v-gate-1"},
        headers=auth_headers,
    )
    assert publish_resp.status_code == 422
    payload = publish_resp.json()
    msg = payload.get("msg") if isinstance(payload, dict) else ""
    assert "无 published 模型" in (msg or "")


@pytest.mark.asyncio
async def test_publish_version_passes_after_library_model_published(
    client: AsyncClient, auth_headers
):
    lib_resp = await client.post(
        "/api/v1/libraries",
        json={"library_key": "zh_ok", "display_name": "中文可发布库", "language": "zh"},
        headers=auth_headers,
    )
    assert lib_resp.status_code == 201

    train_ds_resp = await client.post(
        "/api/v1/libraries/zh_ok/training-datasets",
        json={"name": "训练集", "source_type": "manual", "sample_count": 10},
        headers=auth_headers,
    )
    assert train_ds_resp.status_code == 201
    train_ds = _success_data(train_ds_resp)

    model_resp = await client.post(
        "/api/v1/libraries/zh_ok/models/train",
        json={"version_name": "m-ok-1", "train_dataset_id": train_ds["id"]},
        headers=auth_headers,
    )
    assert model_resp.status_code == 201
    model_id = _success_data(model_resp)["id"]

    publish_model_resp = await client.post(
        f"/api/v1/libraries/zh_ok/models/{model_id}/publish",
        json={"confirm_publish": True, "publish_note": "准入发布"},
        headers=auth_headers,
    )
    assert publish_model_resp.status_code == 200

    profile_resp = await client.post(
        "/api/v1/profiles",
        json={"name": "可发布方案", "llm_provider": "gpt-4o", "intent_library_keys": ["zh_ok"]},
        headers=auth_headers,
    )
    assert profile_resp.status_code == 201
    profile_id = _success_data(profile_resp)["id"]

    publish_version_resp = await client.post(
        "/api/v1/versions",
        params={"profile_id": profile_id, "version_tag": "v-ok-1"},
        headers=auth_headers,
    )
    assert publish_version_resp.status_code == 201
