"""用户管理 API 合约测试。

覆盖 GET/POST /api/v1/auth/users、GET/POST /api/v1/auth/roles，
以及重复用户名 409、未认证 403 等场景。
"""
import pytest
from httpx import AsyncClient

# ---------------------------------------------------------------------------
# T122 用户管理测试场景
# ---------------------------------------------------------------------------


def _success_data(resp):
    payload = resp.json()
    if isinstance(payload, dict) and {"code", "data", "msg"}.issubset(payload.keys()):
        assert payload["code"] == "000000"
        return payload["data"]
    return payload


@pytest.mark.asyncio
async def test_get_users(client: AsyncClient, auth_headers):
    """GET /api/v1/auth/users — 列出用户。"""
    resp = await client.get("/api/v1/auth/users", headers=auth_headers)
    assert resp.status_code == 200
    data = _success_data(resp)
    assert isinstance(data, list)
    if len(data) > 0:
        u = data[0]
        assert "id" in u
        assert "username" in u
        assert "display_name" in u
        assert "role_id" in u
        assert "is_active" in u
        assert "created_at" in u
        assert "updated_at" in u


@pytest.mark.asyncio
async def test_post_users_create(client: AsyncClient, auth_headers, admin_role):
    """POST /api/v1/auth/users — 创建用户。"""
    resp = await client.post(
        "/api/v1/auth/users",
        json={
            "username": "newuser001",
            "password": "password123",
            "display_name": "新用户",
            "role_id": str(admin_role.id),
        },
        headers=auth_headers,
    )
    assert resp.status_code == 201
    data = _success_data(resp)
    assert data["username"] == "newuser001"
    assert data["display_name"] == "新用户"
    assert data["role_id"] == str(admin_role.id)
    assert data["is_active"] is True
    assert "id" in data


@pytest.mark.asyncio
async def test_patch_user_update_and_toggle_active(client: AsyncClient, auth_headers, admin_role):
    """PATCH /api/v1/auth/users/{id} — 编辑用户信息并切换启用状态。"""
    create_resp = await client.post(
        "/api/v1/auth/users",
        json={
            "username": "patch_user001",
            "password": "password123",
            "display_name": "待编辑用户",
            "role_id": str(admin_role.id),
        },
        headers=auth_headers,
    )
    user_id = _success_data(create_resp)["id"]

    patch_resp = await client.patch(
        f"/api/v1/auth/users/{user_id}",
        json={"display_name": "已编辑用户", "is_active": False},
        headers=auth_headers,
    )
    assert patch_resp.status_code == 200
    data = _success_data(patch_resp)
    assert data["display_name"] == "已编辑用户"
    assert data["is_active"] is False


@pytest.mark.asyncio
async def test_reset_user_password_for_system_admin(client: AsyncClient, auth_headers, admin_role):
    """POST /api/v1/auth/users/{id}/password/reset — 系统管理员可重置并查看临时密码。"""
    create_resp = await client.post(
        "/api/v1/auth/users",
        json={
            "username": "reset_pwd_user001",
            "password": "password123",
            "display_name": "重置密码用户",
            "role_id": str(admin_role.id),
        },
        headers=auth_headers,
    )
    user_id = _success_data(create_resp)["id"]

    reset_resp = await client.post(
        f"/api/v1/auth/users/{user_id}/password/reset",
        headers=auth_headers,
    )
    assert reset_resp.status_code == 200
    data = _success_data(reset_resp)
    assert data["user_id"] == user_id
    assert data["username"] == "reset_pwd_user001"
    assert isinstance(data["temporary_password"], str)
    assert len(data["temporary_password"]) >= 8


@pytest.mark.asyncio
async def test_post_users_create_without_display_name_uses_username(
    client: AsyncClient, auth_headers, admin_role
):
    """POST /api/v1/auth/users 不传 display_name 时，使用 username 作为显示名。"""
    resp = await client.post(
        "/api/v1/auth/users",
        json={
            "username": "nodisplay_user",
            "password": "password123",
            "role_id": str(admin_role.id),
        },
        headers=auth_headers,
    )
    assert resp.status_code == 201
    data = _success_data(resp)
    assert data["username"] == "nodisplay_user"
    assert data["display_name"] == "nodisplay_user"
    assert data["role_id"] == str(admin_role.id)


@pytest.mark.asyncio
async def test_get_roles(client: AsyncClient, auth_headers):
    """GET /api/v1/auth/roles — 列出角色。"""
    resp = await client.get("/api/v1/auth/roles", headers=auth_headers)
    assert resp.status_code == 200
    data = _success_data(resp)
    assert isinstance(data, list)
    if len(data) > 0:
        r = data[0]
        assert "id" in r
        assert "name" in r
        assert "permissions" in r
        assert "is_system" in r


@pytest.mark.asyncio
async def test_post_roles_create(client: AsyncClient, auth_headers):
    """POST /api/v1/auth/roles — 创建角色。"""
    resp = await client.post(
        "/api/v1/auth/roles",
        json={
            "name": "测试角色",
            "permissions": {"intent_management": {"read": True}},
        },
        headers=auth_headers,
    )
    assert resp.status_code == 201
    data = _success_data(resp)
    assert data["name"] == "测试角色"
    assert data["permissions"] == {"intent_management": {"read": True}}
    assert data["is_system"] is False
    assert "id" in data


@pytest.mark.asyncio
async def test_create_duplicate_username_returns_409(
    client: AsyncClient, auth_headers, admin_role
):
    """创建重复用户名 → 409。"""
    await client.post(
        "/api/v1/auth/users",
        json={
            "username": "dup_user",
            "password": "password123",
            "display_name": "第一个",
            "role_id": str(admin_role.id),
        },
        headers=auth_headers,
    )
    resp = await client.post(
        "/api/v1/auth/users",
        json={
            "username": "dup_user",
            "password": "password456",
            "display_name": "第二个",
            "role_id": str(admin_role.id),
        },
        headers=auth_headers,
    )
    assert resp.status_code == 409


@pytest.mark.asyncio
async def test_users_unauthorized_returns_403(client: AsyncClient):
    """GET /api/v1/auth/users 未认证 → 403 或 401。"""
    resp = await client.get("/api/v1/auth/users")
    assert resp.status_code in (401, 403)


@pytest.mark.asyncio
async def test_roles_unauthorized_returns_403(client: AsyncClient):
    """GET /api/v1/auth/roles 未认证 → 403 或 401。"""
    resp = await client.get("/api/v1/auth/roles")
    assert resp.status_code in (401, 403)


@pytest.mark.asyncio
async def test_post_users_unauthorized_returns_403(client: AsyncClient):
    """POST /api/v1/auth/users 未认证 → 403 或 401。"""
    resp = await client.post(
        "/api/v1/auth/users",
        json={
            "username": "nobody",
            "password": "password123",
            "display_name": "无名",
        },
    )
    assert resp.status_code in (401, 403)
