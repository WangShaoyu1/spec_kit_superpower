"""指令库 API 合约测试。"""
import hashlib

import pytest
from httpx import AsyncClient


def _success_data(resp):
    payload = resp.json()
    if isinstance(payload, dict) and {"code", "data", "msg"}.issubset(payload.keys()):
        assert payload["code"] == "000000"
        return payload["data"]
    return payload


@pytest.mark.asyncio
async def test_list_intent_libraries(client: AsyncClient, auth_headers):
    create_library_resp = await client.post(
        "/api/v1/libraries",
        json={
            "library_key": "厨房控制",
            "display_name": "厨房控制库",
            "language": "zh",
            "description": "中文指令库",
        },
        headers=auth_headers,
    )
    assert create_library_resp.status_code == 201

    create_resp = await client.post(
        "/api/v1/intents",
        json={
            "intent_key": "library_test_intent",
            "display_name": "指令库测试意图",
            "category": "厨房控制",
            "description": "for library endpoint",
            "slots": [],
        },
        headers=auth_headers,
    )
    assert create_resp.status_code == 201

    resp = await client.get("/api/v1/libraries", headers=auth_headers)
    assert resp.status_code == 200
    data = _success_data(resp)
    assert "items" in data
    assert "total" in data
    target = next((item for item in data["items"] if item["library_key"] == "厨房控制"), None)
    assert target is not None
    assert target["language"] == "zh"
    assert target["intent_count"] >= 1


@pytest.mark.asyncio
async def test_list_library_intents(client: AsyncClient, auth_headers):
    await client.post(
        "/api/v1/libraries",
        json={"library_key": "厨房控制", "display_name": "厨房控制库", "language": "zh"},
        headers=auth_headers,
    )
    await client.post(
        "/api/v1/intents",
        json={
            "intent_key": "library_test_intent_2",
            "display_name": "指令库测试意图2",
            "category": "厨房控制",
            "slots": [],
        },
        headers=auth_headers,
    )
    resp = await client.get("/api/v1/libraries/厨房控制/intents", headers=auth_headers)
    assert resp.status_code == 200
    data = _success_data(resp)
    assert isinstance(data, list)
    assert any(item["category"] == "厨房控制" for item in data)


@pytest.mark.asyncio
async def test_create_update_delete_library(client: AsyncClient, auth_headers):
    create_resp = await client.post(
        "/api/v1/libraries",
        json={"library_key": "english_lib", "display_name": "English Lib", "language": "en"},
        headers=auth_headers,
    )
    assert create_resp.status_code == 201
    created = _success_data(create_resp)
    assert created["library_key"] == "english_lib"

    patch_resp = await client.patch(
        "/api/v1/libraries/english_lib",
        json={"display_name": "English Command Library"},
        headers=auth_headers,
    )
    assert patch_resp.status_code == 200
    patched = _success_data(patch_resp)
    assert patched["display_name"] == "English Command Library"

    delete_resp = await client.delete("/api/v1/libraries/english_lib", headers=auth_headers)
    assert delete_resp.status_code == 204


@pytest.mark.asyncio
async def test_library_model_lifecycle_and_datasets(client: AsyncClient, auth_headers):
    create_library_resp = await client.post(
        "/api/v1/libraries",
        json={
            "library_key": "model_lib",
            "display_name": "模型库",
            "language": "zh",
            "default_intent_f1_threshold": 0.96,
            "default_slot_f1_threshold": 0.91,
        },
        headers=auth_headers,
    )
    assert create_library_resp.status_code == 201

    train_ds_resp = await client.post(
        "/api/v1/libraries/model_lib/training-datasets",
        json={
            "name": "训练集A",
            "source_type": "llm",
            "sample_count": 120,
            "config": {"min_per_intent": 10},
        },
        headers=auth_headers,
    )
    assert train_ds_resp.status_code == 201
    train_ds = _success_data(train_ds_resp)

    eval_ds_resp = await client.post(
        "/api/v1/libraries/model_lib/evaluation-datasets",
        json={
            "name": "评估集A",
            "source_type": "manual",
            "sample_count": 80,
            "has_full_fields": True,
        },
        headers=auth_headers,
    )
    assert eval_ds_resp.status_code == 201
    eval_ds = _success_data(eval_ds_resp)

    create_intent_resp = await client.post(
        "/api/v1/intents",
        json={
            "intent_key": "set_temp",
            "display_name": "设置温度",
            "category": "model_lib",
            "slots": [
                {
                    "slot_key": "number",
                    "display_name": "温度",
                    "entity_type": "number",
                    "is_required": True,
                }
            ],
        },
        headers=auth_headers,
    )
    assert create_intent_resp.status_code == 201

    import_eval_resp = await client.post(
        f"/api/v1/libraries/model_lib/evaluation-datasets/{eval_ds['id']}/import",
        json={
            "rows": [
                {
                    "intent_key": "set_temp",
                    "utterance": "请把温度调到180度",
                    "language": "zh",
                    "source": "manual",
                    "expected_result": {
                        "intent_key": "set_temp",
                        "slots": {"number": "180"},
                    },
                }
            ]
        },
        headers=auth_headers,
    )
    assert import_eval_resp.status_code == 200

    fetch_eval_rows_resp = await client.get(
        f"/api/v1/libraries/model_lib/evaluation-datasets/{eval_ds['id']}/rows",
        headers=auth_headers,
    )
    assert fetch_eval_rows_resp.status_code == 200
    assert len(_success_data(fetch_eval_rows_resp)["rows"]) == 1

    train_resp = await client.post(
        "/api/v1/libraries/model_lib/models/train",
        json={
            "version_name": "model-v1",
            "train_dataset_id": train_ds["id"],
        },
        headers=auth_headers,
    )
    assert train_resp.status_code == 201
    model = _success_data(train_resp)
    assert model["status"] == "trained"

    eval_resp = await client.post(
        f"/api/v1/libraries/model_lib/models/{model['id']}/evaluate",
        json={
            "dataset_id": eval_ds["id"],
            "threshold_intent_f1": 0.97,
            "threshold_slot_f1": 0.92,
        },
        headers=auth_headers,
    )
    assert eval_resp.status_code == 201
    run = _success_data(eval_resp)
    assert run["threshold_intent_f1"] == 0.97
    assert run["threshold_slot_f1"] == 0.92
    assert run["result_summary"]["total_samples"] == 1
    assert "top_confusions" in run["analysis"]

    test_one_resp = await client.post(
        f"/api/v1/libraries/model_lib/models/{model['id']}/test-one",
        json={
            "utterance": "设置温度180度",
            "language": "zh",
            "expected_intent": "set_temp",
            "expected_slots": {"number": "180"},
        },
        headers=auth_headers,
    )
    assert test_one_resp.status_code == 200
    test_one = _success_data(test_one_resp)
    assert test_one["predicted_intent"] in {"set_temp", "unknown"}
    assert "detail" in test_one

    testable_resp = await client.post(
        f"/api/v1/libraries/model_lib/models/{model['id']}/testable",
        headers=auth_headers,
    )
    assert testable_resp.status_code == 200
    testable_model = _success_data(testable_resp)
    assert testable_model["is_testable"] is True

    publish_guard_resp = await client.post(
        f"/api/v1/libraries/model_lib/models/{model['id']}/publish",
        json={"confirm_publish": False},
        headers=auth_headers,
    )
    assert publish_guard_resp.status_code == 422

    publish_resp = await client.post(
        f"/api/v1/libraries/model_lib/models/{model['id']}/publish",
        json={"confirm_publish": True, "publish_note": "验收发布"},
        headers=auth_headers,
    )
    assert publish_resp.status_code == 200
    published_model = _success_data(publish_resp)
    assert published_model["is_published"] is True
    assert published_model["notes"] == "验收发布"

    list_models_resp = await client.get("/api/v1/libraries/model_lib/models", headers=auth_headers)
    assert list_models_resp.status_code == 200
    models = _success_data(list_models_resp)
    assert len(models) >= 1


@pytest.mark.asyncio
async def test_model_artifact_hash_verification(
    client: AsyncClient, auth_headers, tmp_path
):
    lib_resp = await client.post(
        "/api/v1/libraries",
        json={"library_key": "artifact_lib", "display_name": "产物库", "language": "zh"},
        headers=auth_headers,
    )
    assert lib_resp.status_code == 201

    train_ds_resp = await client.post(
        "/api/v1/libraries/artifact_lib/training-datasets",
        json={"name": "train", "source_type": "manual", "sample_count": 1},
        headers=auth_headers,
    )
    assert train_ds_resp.status_code == 201
    train_ds = _success_data(train_ds_resp)

    model_resp = await client.post(
        "/api/v1/libraries/artifact_lib/models/train",
        json={"version_name": "artifact-v1", "train_dataset_id": train_ds["id"]},
        headers=auth_headers,
    )
    assert model_resp.status_code == 201
    model = _success_data(model_resp)

    artifact = tmp_path / "model.onnx"
    artifact.write_text("fake-onnx-binary", encoding="utf-8")
    good_sha = hashlib.sha256(artifact.read_bytes()).hexdigest()

    register_resp = await client.post(
        f"/api/v1/libraries/artifact_lib/models/{model['id']}/artifact",
        params={"artifact_type": "onnx", "artifact_uri": str(artifact)},
        headers=auth_headers,
    )
    assert register_resp.status_code == 200

    bad_download = await client.get(
        f"/api/v1/libraries/artifact_lib/models/{model['id']}/artifact/download",
        params={"expected_sha256": "0" * 64},
        headers=auth_headers,
    )
    assert bad_download.status_code == 409

    good_download = await client.get(
        f"/api/v1/libraries/artifact_lib/models/{model['id']}/artifact/download",
        params={"expected_sha256": good_sha},
        headers=auth_headers,
    )
    assert good_download.status_code == 200
