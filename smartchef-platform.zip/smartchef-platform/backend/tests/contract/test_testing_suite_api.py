"""测试套件 API 合约测试。"""
import pytest
from httpx import AsyncClient


def _success_data(resp):
    payload = resp.json()
    if isinstance(payload, dict) and {"code", "data", "msg"}.issubset(payload.keys()):
        assert payload["code"] == "000000"
        return payload["data"]
    return payload


@pytest.mark.asyncio
async def test_create_suite_and_import_cases(client: AsyncClient, auth_headers):
    profile_resp = await client.post(
        "/api/v1/profiles",
        json={"name": "测试套件方案", "llm_provider": "gpt-4o"},
        headers=auth_headers,
    )
    assert profile_resp.status_code == 201
    profile_id = _success_data(profile_resp)["id"]

    suite_resp = await client.post(
        "/api/v1/testing/batch/suites",
        json={"name": "回归套件A", "profile_id": profile_id},
        headers=auth_headers,
    )
    assert suite_resp.status_code == 201
    suite = _success_data(suite_resp)
    suite_id = suite["id"]

    import_resp = await client.post(
        f"/api/v1/testing/batch/suites/{suite_id}/cases",
        json={
            "cases": [
                {"input_text": "开始烹饪", "expected_intent": "voice_cmd_start_cooking", "expected_domain": "command"},
                {"input_text": "红烧肉怎么做", "expected_domain": "knowledge"},
            ]
        },
        headers=auth_headers,
    )
    assert import_resp.status_code == 201
    imported = _success_data(import_resp)
    assert imported["case_count"] == 2

    detail_resp = await client.get(f"/api/v1/testing/batch/suites/{suite_id}", headers=auth_headers)
    assert detail_resp.status_code == 200
    detail = _success_data(detail_resp)
    assert detail["case_count"] == 2
    assert len(detail["cases"]) == 2
