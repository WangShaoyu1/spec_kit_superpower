from pathlib import Path
import subprocess
import sys


def test_device_portability_script_exists_and_runs():
    repo_root = Path(__file__).resolve().parents[3]
    script = repo_root / "device-inference" / "tests" / "verify_onnx_portability.py"
    assert script.exists()

    cmd = [sys.executable, str(script), "--model", "not_exists.onnx"]
    completed = subprocess.run(cmd, capture_output=True, check=False)
    assert completed.returncode == 2
