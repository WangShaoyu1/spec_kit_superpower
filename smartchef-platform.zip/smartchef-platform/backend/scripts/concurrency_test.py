#!/usr/bin/env python3
"""
并发压测脚本：验证 SC-006（并发、设备隔离）。

示例：
  python -m scripts.concurrency_test --base-url http://127.0.0.1:8000 --workers 10 --duration 20
  python -m scripts.concurrency_test --api-key-mode per-worker
"""

from __future__ import annotations

import argparse
import asyncio
import json
import random
import statistics
import time
import uuid
from pathlib import Path
from typing import Any, cast

import httpx

DEFAULT_BASE = "http://127.0.0.1:8000"
API_PREFIX = "/api/v1"
DEFAULT_COMMAND_CORPUS = [
    "设置温度180度",
    "把温度调到200度",
    "帮我设定烹饪时间20分钟",
    "暂停烹饪",
    "继续烹饪",
    "停止烹饪",
    "开始烹饪",
    "解冻模式",
    "音量调高一点",
    "亮度调低一些",
]


def _percentile(values: list[float], p: float) -> float:
    if not values:
        return -1.0
    arr = sorted(values)
    idx = min(int(len(arr) * p), len(arr) - 1)
    return arr[idx]


def _load_corpus(corpus_file: str | None) -> list[dict[str, str]]:
    if not corpus_file:
        return [{"text": t, "language": "zh", "domain": "command"} for t in DEFAULT_COMMAND_CORPUS]

    path = Path(corpus_file)
    if not path.exists():
        raise FileNotFoundError(f"语料文件不存在: {corpus_file}")

    raw = path.read_text(encoding="utf-8").strip()
    if not raw:
        raise ValueError("语料文件为空")

    if path.suffix.lower() in {".json", ".jsonl"}:
        data = json.loads(raw)
        if not isinstance(data, list):
            raise ValueError("JSON 语料需为数组")
        corpus: list[dict[str, str]] = []
        for item in data:
            if isinstance(item, str):
                corpus.append(
                    {"text": item.strip(), "language": "zh", "domain": "command", "difficulty": "unknown"}
                )
            elif isinstance(item, dict) and "text" in item:
                corpus.append({
                    "text": str(item["text"]).strip(),
                    "language": str(item.get("language", "zh")),
                    "domain": str(item.get("domain", "unknown")),
                    "difficulty": str(item.get("difficulty", "unknown")),
                })
        corpus = [x for x in corpus if x["text"]]
        if not corpus:
            raise ValueError("JSON 语料未解析出有效 text")
        return corpus

    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    if not lines:
        raise ValueError("文本语料未解析出有效行")
    return [{"text": ln, "language": "zh", "domain": "command", "difficulty": "unknown"} for ln in lines]


def _filter_corpus_by_domain(
    corpus: list[dict[str, str]],
    domains: list[str] | None,
) -> list[dict[str, str]]:
    if not domains:
        return corpus
    wanted = {d.strip().lower() for d in domains if d.strip()}
    filtered = [item for item in corpus if item.get("domain", "").strip().lower() in wanted]
    if not filtered:
        raise ValueError(f"过滤后语料为空，domains={sorted(wanted)}")
    return filtered


def _filter_corpus_by_difficulty(
    corpus: list[dict[str, str]],
    difficulties: list[str] | None,
) -> list[dict[str, str]]:
    if not difficulties:
        return corpus
    wanted = {d.strip().lower() for d in difficulties if d.strip()}
    filtered = [item for item in corpus if item.get("difficulty", "").strip().lower() in wanted]
    if not filtered:
        raise ValueError(f"过滤后语料为空，difficulties={sorted(wanted)}")
    return filtered


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="SmartChef 并发压测（SC-006）")
    parser.add_argument("--base-url", default=DEFAULT_BASE, help="后端 base URL")
    parser.add_argument("--workers", type=int, default=10, help="并发 worker 数")
    parser.add_argument("--duration", type=int, default=20, help="压测时长（秒）")
    parser.add_argument("--qps", type=float, default=1.0, help="每 worker 目标 QPS（默认 1）")
    parser.add_argument("--interval-ms", type=float, default=500.0, help="最小请求间隔（毫秒，默认 500）")
    parser.add_argument("--corpus-file", type=str, default=None, help="语料文件路径（json/txt）")
    parser.add_argument("--corpus-mode", choices=("cycle", "random"), default="cycle", help="语料采样方式")
    parser.add_argument(
        "--domains",
        nargs="+",
        default=None,
        help="按 domain 过滤语料（如: command knowledge chitchat）",
    )
    parser.add_argument(
        "--difficulties",
        nargs="+",
        default=None,
        help="按 difficulty 过滤语料（如: easy medium hard）",
    )
    parser.add_argument(
        "--api-key-mode",
        choices=("shared", "per-worker"),
        default="shared",
        help="限流 key 模式：shared=同一 key，per-worker=每 worker 独立 key",
    )
    parser.add_argument(
        "--error-rate-threshold",
        type=float,
        default=0.05,
        help="错误率阈值（默认 5%%）",
    )
    return parser.parse_args()


async def _worker(
    worker_id: int,
    duration: int,
    url: str,
    shared_api_key: str,
    per_worker_key: bool,
    target_qps: float,
    min_interval_ms: float,
    corpus: list[dict[str, str]],
    corpus_mode: str,
    client: httpx.AsyncClient,
    stats: dict,
    lock: asyncio.Lock,
) -> None:
    start = time.perf_counter()
    index = 0
    headers = (
        {"x-api-key": f"perf-key-{worker_id}"}
        if per_worker_key
        else {"x-api-key": shared_api_key}
    )

    while time.perf_counter() - start < duration:
        t0 = time.perf_counter()
        sample = (
            random.choice(corpus)
            if corpus_mode == "random"
            else corpus[(worker_id + index) % len(corpus)]
        )
        payload = {
            "device_id": f"perf-{worker_id}-{uuid.uuid4().hex[:8]}-{index}",
            "text": sample["text"],
            "language": sample["language"],
        }
        domain = sample.get("domain", "unknown")
        status_code = 0
        try:
            resp = await client.post(url, json=payload, headers=headers, timeout=10.0)
            status_code = resp.status_code
        except Exception:
            status_code = 0

        elapsed_ms = (time.perf_counter() - t0) * 1000
        async with lock:
            stats["codes"][status_code] = stats["codes"].get(status_code, 0) + 1
            if domain not in stats["domains"]:
                stats["domains"][domain] = {"ok": 0, "errors": 0, "latencies": []}
            if status_code == 200:
                stats["ok"] += 1
                stats["latencies"].append(elapsed_ms)
                stats["domains"][domain]["ok"] += 1
                stats["domains"][domain]["latencies"].append(elapsed_ms)
            else:
                stats["errors"] += 1
                stats["domains"][domain]["errors"] += 1

        index += 1
        min_interval_s = max(
            (1.0 / target_qps) if target_qps > 0 else 0.0,
            (min_interval_ms / 1000.0) if min_interval_ms > 0 else 0.0,
        )
        await asyncio.sleep(max(0, min_interval_s - elapsed_ms / 1000.0))


async def run_test(args: argparse.Namespace) -> dict:
    url = f"{args.base_url.rstrip('/')}{API_PREFIX}/dialog/chat"
    stats: dict[str, Any] = {"ok": 0, "errors": 0, "codes": {}, "latencies": [], "domains": {}}
    lock = asyncio.Lock()
    shared_key = "perf-shared-key"
    per_worker_key = args.api_key_mode == "per-worker"
    corpus = _load_corpus(args.corpus_file)
    corpus = _filter_corpus_by_domain(corpus, args.domains)
    corpus = _filter_corpus_by_difficulty(corpus, args.difficulties)

    async with httpx.AsyncClient() as client:
        tasks = [
            _worker(
                worker_id=i,
                duration=args.duration,
                url=url,
                shared_api_key=shared_key,
                per_worker_key=per_worker_key,
                target_qps=args.qps,
                min_interval_ms=args.interval_ms,
                corpus=corpus,
                corpus_mode=args.corpus_mode,
                client=client,
                stats=stats,
                lock=lock,
            )
            for i in range(args.workers)
        ]
        await asyncio.gather(*tasks)

    total = int(stats["ok"]) + int(stats["errors"])
    latencies = sorted(cast("list[float]", stats["latencies"]))
    p95 = _percentile(latencies, 0.95)
    avg = statistics.mean(latencies) if latencies else -1.0
    error_rate = int(stats["errors"]) / max(total, 1)
    domain_metrics: dict[str, dict[str, float | int]] = {}
    for domain, data in cast("dict[str, dict[str, Any]]", stats["domains"]).items():
        d_latencies = cast("list[float]", data["latencies"])
        d_ok = int(data["ok"])
        d_err = int(data["errors"])
        domain_metrics[domain] = {
            "ok": d_ok,
            "errors": d_err,
            "error_rate": round(d_err / max(d_ok + d_err, 1), 4),
            "avg_ms": round(statistics.mean(d_latencies), 2) if d_latencies else -1.0,
            "p95_ms": round(_percentile(d_latencies, 0.95), 2),
        }

    return {
        "base_url": args.base_url,
        "workers": args.workers,
        "duration_s": args.duration,
        "qps_per_worker": args.qps,
        "min_interval_ms": args.interval_ms,
        "corpus_size": len(corpus),
        "corpus_mode": args.corpus_mode,
        "domains": args.domains or ["all"],
        "difficulties": args.difficulties or ["all"],
        "api_key_mode": args.api_key_mode,
        "total_requests": total,
        "achieved_qps": round(total / max(args.duration, 1), 2),
        "ok": int(stats["ok"]),
        "errors": int(stats["errors"]),
        "error_rate": round(error_rate, 4),
        "status_codes": stats["codes"],
        "domain_metrics": domain_metrics,
        "avg_ms": round(avg, 2),
        "p95_ms": round(p95, 2),
        "pass": error_rate <= args.error_rate_threshold,
    }


def main() -> None:
    args = parse_args()
    result = asyncio.run(run_test(args))
    print(result)


if __name__ == "__main__":
    main()
