#!/usr/bin/env python3
"""
性能测试脚本：采集指令 API 延迟、可选准确率与 QPS。

用法（需后端已启动且已发布版本）：
  python -m scripts.performance_test
  python -m scripts.performance_test --base-url http://localhost:8000 --samples 50
  python -m scripts.performance_test --p95-threshold 200 --warmup 3

输出：P50/P95/P99 延迟（ms）、样本数、是否通过 SC-002 阈值（默认 200ms）。
"""
from __future__ import annotations

import argparse
import json
import random
import statistics
import sys
import time
import uuid
from contextlib import suppress
from pathlib import Path

try:
    import httpx
except ImportError:
    print("pip install httpx", file=sys.stderr)
    sys.exit(1)

DEFAULT_BASE = "http://127.0.0.1:8000"
API_PREFIX = "/api/v1"
DEFAULT_SAMPLES = 50
DEFAULT_WARMUP = 3
DEFAULT_QPS = 1.0
DEFAULT_INTERVAL_MS = 500.0
SC002_P95_MS = 200
DEFAULT_COMMAND_CORPUS = [
    "设置温度180度",
    "把温度调到200度",
    "帮我设定烹饪时间20分钟",
    "暂停烹饪",
    "继续烹饪",
    "停止烹饪",
    "开始烹饪",
    "解冻模式",
    "音量调高一点",
    "亮度调低一些",
]


def _percentile(values: list[float], p: float) -> float:
    if not values:
        return -1.0
    arr = sorted(values)
    idx = min(int(len(arr) * p), len(arr) - 1)
    return arr[idx]


def _load_corpus(corpus_file: str | None) -> list[dict[str, str]]:
    if not corpus_file:
        return [{"text": t, "language": "zh", "domain": "command"} for t in DEFAULT_COMMAND_CORPUS]

    path = Path(corpus_file)
    if not path.exists():
        raise FileNotFoundError(f"语料文件不存在: {corpus_file}")

    raw = path.read_text(encoding="utf-8").strip()
    if not raw:
        raise ValueError("语料文件为空")

    if path.suffix.lower() in {".json", ".jsonl"}:
        data = json.loads(raw)
        if not isinstance(data, list):
            raise ValueError("JSON 语料需为数组")
        corpus: list[dict[str, str]] = []
        for item in data:
            if isinstance(item, str):
                corpus.append(
                    {"text": item.strip(), "language": "zh", "domain": "command", "difficulty": "unknown"}
                )
            elif isinstance(item, dict) and "text" in item:
                corpus.append({
                    "text": str(item["text"]).strip(),
                    "language": str(item.get("language", "zh")),
                    "domain": str(item.get("domain", "unknown")),
                    "difficulty": str(item.get("difficulty", "unknown")),
                })
        corpus = [x for x in corpus if x["text"]]
        if not corpus:
            raise ValueError("JSON 语料未解析出有效 text")
        return corpus

    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    if not lines:
        raise ValueError("文本语料未解析出有效行")
    return [{"text": ln, "language": "zh", "domain": "command", "difficulty": "unknown"} for ln in lines]


def _filter_corpus_by_domain(
    corpus: list[dict[str, str]],
    domains: list[str] | None,
) -> list[dict[str, str]]:
    if not domains:
        return corpus
    wanted = {d.strip().lower() for d in domains if d.strip()}
    filtered = [item for item in corpus if item.get("domain", "").strip().lower() in wanted]
    if not filtered:
        raise ValueError(f"过滤后语料为空，domains={sorted(wanted)}")
    return filtered


def _filter_corpus_by_difficulty(
    corpus: list[dict[str, str]],
    difficulties: list[str] | None,
) -> list[dict[str, str]]:
    if not difficulties:
        return corpus
    wanted = {d.strip().lower() for d in difficulties if d.strip()}
    filtered = [item for item in corpus if item.get("difficulty", "").strip().lower() in wanted]
    if not filtered:
        raise ValueError(f"过滤后语料为空，difficulties={sorted(wanted)}")
    return filtered


def main():
    p = argparse.ArgumentParser(description="SmartChef 指令 API 性能采样")
    p.add_argument("--base-url", default=DEFAULT_BASE, help="后端 base URL")
    p.add_argument("--samples", type=int, default=DEFAULT_SAMPLES, help="采样次数")
    p.add_argument("--warmup", type=int, default=DEFAULT_WARMUP, help="预热次数（不计入统计）")
    p.add_argument("--reuse-device-id", action="store_true", help="复用同一 device_id（默认每次请求使用新 device_id）")
    p.add_argument("--qps", type=float, default=DEFAULT_QPS, help="目标 QPS（默认 1）")
    p.add_argument("--interval-ms", type=float, default=DEFAULT_INTERVAL_MS, help="最小请求间隔（毫秒，默认 500）")
    p.add_argument("--corpus-file", type=str, default=None, help="语料文件路径（json/txt）")
    p.add_argument("--corpus-mode", choices=("cycle", "random"), default="cycle", help="语料采样方式")
    p.add_argument(
        "--domains",
        nargs="+",
        default=None,
        help="按 domain 过滤语料（如: command knowledge chitchat）",
    )
    p.add_argument(
        "--difficulties",
        nargs="+",
        default=None,
        help="按 difficulty 过滤语料（如: easy medium hard）",
    )
    p.add_argument("--p95-threshold", type=float, default=SC002_P95_MS, help="P95 延迟阈值(ms)")
    args = p.parse_args()

    url = f"{args.base_url.rstrip('/')}{API_PREFIX}/dialog/chat"
    corpus = _load_corpus(args.corpus_file)
    corpus = _filter_corpus_by_domain(corpus, args.domains)
    corpus = _filter_corpus_by_difficulty(corpus, args.difficulties)

    latencies_ms: list[float] = []
    domain_stats: dict[str, dict[str, object]] = {}
    errors = 0
    first_error_status: int | None = None
    first_error_body: str = ""

    print(
        f"Target: {url} | warmup={args.warmup} | samples={args.samples} | "
        f"reuse_device_id={args.reuse_device_id} | qps={args.qps} | interval_ms={args.interval_ms} | "
        f"corpus={len(corpus)} | mode={args.corpus_mode} | domains={args.domains or ['all']} | "
        f"difficulties={args.difficulties or ['all']} | "
        f"P95 threshold={args.p95_threshold}ms"
    )

    with httpx.Client(timeout=10.0) as client:
        print("Warmup ...")
        for i in range(max(args.warmup, 0)):
            sample = corpus[i % len(corpus)]
            warm_payload = {
                "text": sample["text"],
                "language": sample["language"],
                "device_id": f"perf-warmup-{uuid.uuid4().hex[:8]}-{i}",
            }
            with suppress(Exception):
                client.post(url, json=warm_payload)

        print("Sampling ...")
        fixed_device_id = f"perf-test-fixed-{uuid.uuid4().hex[:8]}"

        for i in range(args.samples):
            sample = (
                random.choice(corpus)
                if args.corpus_mode == "random"
                else corpus[i % len(corpus)]
            )
            device_id = fixed_device_id if args.reuse_device_id else f"perf-test-{uuid.uuid4().hex[:8]}-{i}"
            payload = {
                "text": sample["text"],
                "language": sample["language"],
                "device_id": device_id,
            }
            domain = sample.get("domain", "unknown")
            if domain not in domain_stats:
                domain_stats[domain] = {"ok": 0, "errors": 0, "latencies": []}

            t0 = time.perf_counter()
            try:
                r = client.post(url, json=payload)
                if r.status_code != 200:
                    if first_error_status is None:
                        first_error_status = r.status_code
                        first_error_body = r.text[:500] if r.text else ""
                    errors += 1
                    domain_stats[domain]["errors"] = int(domain_stats[domain]["errors"]) + 1
                else:
                    elapsed_ms = (time.perf_counter() - t0) * 1000
                    latencies_ms.append(elapsed_ms)
                    domain_stats[domain]["ok"] = int(domain_stats[domain]["ok"]) + 1
                    casted = domain_stats[domain]["latencies"]
                    if isinstance(casted, list):
                        casted.append(elapsed_ms)
            except Exception as e:
                if first_error_status is None:
                    first_error_body = str(e)
                    first_error_status = 0
                errors += 1
                domain_stats[domain]["errors"] = int(domain_stats[domain]["errors"]) + 1

            min_interval_s = max(
                (1.0 / args.qps) if args.qps > 0 else 0.0,
                (args.interval_ms / 1000.0) if args.interval_ms > 0 else 0.0,
            )
            spent_s = time.perf_counter() - t0
            if min_interval_s > spent_s:
                time.sleep(min_interval_s - spent_s)

    if not latencies_ms:
        print("No successful samples; check backend and version.")
        if first_error_status is not None:
            print(f"  First error: HTTP {first_error_status}")
            if first_error_body:
                print(f"  Body: {first_error_body[:300]}")
        print("  Tip: ensure a dialog version is published (e.g. from Versions page).")
        sys.exit(1)

    n = len(latencies_ms)
    sorted_ms = sorted(latencies_ms)
    p50 = sorted_ms[int(n * 0.50)]
    p95 = _percentile(latencies_ms, 0.95)
    p99 = _percentile(latencies_ms, 0.99)
    avg = statistics.mean(latencies_ms)

    print("\n--- Result ---")
    print(f"  Samples: {n} ok, {errors} fail")
    if errors > 0 and first_error_status is not None:
        print(f"  First error: HTTP {first_error_status}")
        if first_error_body:
            print(f"  Body: {first_error_body[:120]}")
    print(f"  Avg:     {avg:.1f} ms")
    print(f"  P50:     {p50:.1f} ms")
    print(f"  P95:     {p95:.1f} ms")
    print(f"  P99:     {p99:.1f} ms")
    if domain_stats:
        print("  Domain breakdown:")
        for domain, stats in sorted(domain_stats.items(), key=lambda x: x[0]):
            d_ok = int(stats["ok"])
            d_err = int(stats["errors"])
            d_latencies = stats["latencies"] if isinstance(stats["latencies"], list) else []
            d_p95 = _percentile(d_latencies, 0.95)
            d_avg = statistics.mean(d_latencies) if d_latencies else -1.0
            print(
                f"    - {domain}: ok={d_ok}, err={d_err}, "
                f"avg={d_avg:.1f}ms, p95={d_p95:.1f}ms"
            )
    print(f"  SC-002 (P95 < {args.p95_threshold}ms): {'PASS' if p95 < args.p95_threshold else 'FAIL'}")

    if p95 >= args.p95_threshold:
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
