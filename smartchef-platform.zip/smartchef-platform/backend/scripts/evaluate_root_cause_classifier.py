#!/usr/bin/env python3
"""
SC-008 评估脚本（代理）：评估 analyzer 规则分类器 `_classify_failure` 的一致性。

说明：
- 当前项目没有“人工标注根因”基准集，本脚本使用规则样本集做回归验证。
- 指标口径：样本分类准确率。
"""

from __future__ import annotations

from dataclasses import dataclass

from app.services.testing.analyzer import _classify_failure


@dataclass
class FailureCase:
    expected_domain: str | None
    actual_domain: str | None
    expected_intent: str | None
    actual_intent: str | None
    intent_confidence: float | None


@dataclass
class LabeledCase:
    case: FailureCase
    expected_category: str


def main() -> None:
    samples: list[LabeledCase] = [
        LabeledCase(FailureCase("command", "knowledge", "set_temp", "set_temp", 0.92), "route_mismatch"),
        LabeledCase(FailureCase("knowledge", "chitchat", None, None, 0.6), "route_mismatch"),
        LabeledCase(FailureCase("command", "command", "set_temp", "set_time", 0.88), "intent_mismatch"),
        LabeledCase(FailureCase("command", "command", "start", "stop", 0.75), "intent_mismatch"),
        LabeledCase(FailureCase("command", "command", "start", None, 0.2), "no_intent_detected"),
        LabeledCase(FailureCase("command", "command", "set_temp", "set_temp", 0.3), "low_confidence"),
        LabeledCase(FailureCase("command", "command", "set_temp", "set_temp", 0.59), "low_confidence"),
        LabeledCase(FailureCase("command", "command", "set_temp", "set_temp", 0.95), "other"),
    ]

    correct = 0
    for sample in samples:
        predicted = _classify_failure(sample.case)  # type: ignore[arg-type]
        if predicted == sample.expected_category:
            correct += 1

    total = len(samples)
    accuracy = correct / total
    print(
        {
            "status": "ok",
            "samples": total,
            "correct": correct,
            "accuracy": round(accuracy, 4),
            "pass_sc008_proxy": accuracy >= 0.8,
            "note": "proxy metric based on rule-labeled synthetic cases",
        }
    )


if __name__ == "__main__":
    main()
