#!/usr/bin/env python3
"""
SC-001 评估脚本：基于当前活跃版本的训练语料，估算意图识别准确率。

说明：
- 数据源为数据库中的 TrainingData（按活跃版本关联的意图范围）
- 评估方式为 top-1 准确率（predicted_intent == expected_intent）
"""

from __future__ import annotations

import asyncio
from collections import defaultdict

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.core.database import async_session_factory
from app.models.dialog_profile import DialogProfile
from app.models.intent import Intent
from app.models.published_version import PublishedVersion
from app.services.nlu.intent_classifier import classify_intent


async def main() -> None:
    async with async_session_factory() as db:
        version_result = await db.execute(
            select(PublishedVersion).where(PublishedVersion.is_active).limit(1)
        )
        version = version_result.scalar_one_or_none()
        if not version:
            print({"status": "no_active_version"})
            return

        query = (
            select(Intent)
            .options(selectinload(Intent.training_data))
            .where(Intent.is_active)
        )
        profile_result = await db.execute(
            select(DialogProfile).where(DialogProfile.id == version.profile_id)
        )
        profile = profile_result.scalar_one_or_none()
        if profile and profile.intent_ids:
            query = query.where(Intent.id.in_(profile.intent_ids))

        intent_result = await db.execute(query)
        intents = list(intent_result.scalars().unique().all())

        registered_intents: list[dict] = []
        eval_samples: list[tuple[str, str]] = []
        for intent in intents:
            training_texts = [td.text for td in (intent.training_data or []) if td.text]
            registered_intents.append(
                {
                    "intent_key": intent.intent_key,
                    "display_name": intent.display_name,
                    "category": intent.category,
                    "training_texts": training_texts,
                }
            )
            for text in training_texts:
                eval_samples.append((text, intent.intent_key))

        if not eval_samples:
            print({"status": "no_training_samples"})
            return

        correct = 0
        per_intent_total: dict[str, int] = defaultdict(int)
        per_intent_correct: dict[str, int] = defaultdict(int)
        for text, expected_intent in eval_samples:
            pred = await classify_intent(text, "zh", registered_intents)
            per_intent_total[expected_intent] += 1
            if pred.intent_key == expected_intent:
                correct += 1
                per_intent_correct[expected_intent] += 1

        total = len(eval_samples)
        accuracy = correct / total

        worst_intents = sorted(
            (
                {
                    "intent_key": intent_key,
                    "accuracy": round(per_intent_correct[intent_key] / cnt, 4),
                    "correct": per_intent_correct[intent_key],
                    "total": cnt,
                }
                for intent_key, cnt in per_intent_total.items()
            ),
            key=lambda x: x["accuracy"],
        )[:10]

        print(
            {
                "status": "ok",
                "samples": total,
                "correct": correct,
                "accuracy": round(accuracy, 4),
                "pass_sc001": accuracy >= 0.95,
                "worst_intents": worst_intents,
            }
        )


if __name__ == "__main__":
    asyncio.run(main())
