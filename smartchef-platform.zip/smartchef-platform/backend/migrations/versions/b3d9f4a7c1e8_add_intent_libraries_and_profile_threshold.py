"""add intent libraries and profile threshold

Revision ID: b3d9f4a7c1e8
Revises: a7f8b9c0d1e2
Create Date: 2026-03-11 10:00:00.000000
"""

import uuid
from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "b3d9f4a7c1e8"
down_revision: str | None = "a7f8b9c0d1e2"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "intent_libraries",
        sa.Column("library_key", sa.String(length=64), nullable=False),
        sa.Column("display_name", sa.String(length=128), nullable=False),
        sa.Column("language", sa.String(length=8), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("library_key"),
    )
    op.create_index(op.f("ix_intent_libraries_library_key"), "intent_libraries", ["library_key"], unique=True)
    op.create_index(op.f("ix_intent_libraries_language"), "intent_libraries", ["language"], unique=False)

    op.add_column(
        "dialog_profiles",
        sa.Column("command_threshold", sa.Float(), server_default=sa.text("0.6"), nullable=False),
    )
    op.add_column(
        "dialog_profiles",
        sa.Column("intent_library_keys", postgresql.ARRAY(sa.String(length=64)), nullable=True),
    )
    # Backfill: existing intent categories become zh intent libraries.
    conn = op.get_bind()
    categories = [
        row[0]
        for row in conn.execute(sa.text("SELECT DISTINCT category FROM intents WHERE category IS NOT NULL"))
    ]
    for category in categories:
        conn.execute(
            sa.text(
                """
                INSERT INTO intent_libraries (id, library_key, display_name, language, created_at, updated_at)
                VALUES (:id, :library_key, :display_name, 'zh', NOW(), NOW())
                ON CONFLICT (library_key) DO NOTHING
                """
            ),
            {
                "id": str(uuid.uuid4()),
                "library_key": category,
                "display_name": category,
            },
        )
    if categories:
        array_literal = ", ".join("'" + c.replace("'", "''") + "'" for c in categories)
        conn.execute(
            sa.text(
                f"UPDATE dialog_profiles SET intent_library_keys = ARRAY[{array_literal}]::varchar[] "
                "WHERE intent_library_keys IS NULL"
            )
        )


def downgrade() -> None:
    op.drop_column("dialog_profiles", "intent_library_keys")
    op.drop_column("dialog_profiles", "command_threshold")

    op.drop_index(op.f("ix_intent_libraries_language"), table_name="intent_libraries")
    op.drop_index(op.f("ix_intent_libraries_library_key"), table_name="intent_libraries")
    op.drop_table("intent_libraries")
