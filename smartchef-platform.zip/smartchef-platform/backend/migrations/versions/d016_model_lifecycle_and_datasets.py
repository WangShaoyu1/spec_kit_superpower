"""add D016 model lifecycle and datasets

Revision ID: d016_model_lifecycle
Revises: b3d9f4a7c1e8
Create Date: 2026-03-12
"""

from typing import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = "d016_model_lifecycle"
down_revision: str | None = "b3d9f4a7c1e8"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column(
        "intent_libraries",
        sa.Column(
            "default_intent_f1_threshold",
            sa.Float(),
            nullable=False,
            server_default=sa.text("0.95"),
        ),
    )
    op.add_column(
        "intent_libraries",
        sa.Column(
            "default_slot_f1_threshold",
            sa.Float(),
            nullable=False,
            server_default=sa.text("0.9"),
        ),
    )

    op.create_table(
        "training_datasets",
        sa.Column("library_key", sa.String(length=64), nullable=False),
        sa.Column("name", sa.String(length=128), nullable=False),
        sa.Column("source_type", sa.String(length=16), nullable=False, server_default="manual"),
        sa.Column("schema_version", sa.String(length=16), nullable=False, server_default="v1"),
        sa.Column("sample_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("config", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("file_uri", sa.Text(), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("NOW()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("NOW()")),
        sa.ForeignKeyConstraint(["library_key"], ["intent_libraries.library_key"]),
        sa.ForeignKeyConstraint(["created_by"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_training_datasets_library_key", "training_datasets", ["library_key"], unique=False)

    op.create_table(
        "evaluation_datasets",
        sa.Column("library_key", sa.String(length=64), nullable=False),
        sa.Column("name", sa.String(length=128), nullable=False),
        sa.Column("source_type", sa.String(length=16), nullable=False, server_default="manual"),
        sa.Column("schema_version", sa.String(length=16), nullable=False, server_default="v1"),
        sa.Column("sample_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("config", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("file_uri", sa.Text(), nullable=True),
        sa.Column("has_full_fields", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("NOW()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("NOW()")),
        sa.ForeignKeyConstraint(["library_key"], ["intent_libraries.library_key"]),
        sa.ForeignKeyConstraint(["created_by"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_evaluation_datasets_library_key", "evaluation_datasets", ["library_key"], unique=False)

    op.create_table(
        "library_model_versions",
        sa.Column("library_key", sa.String(length=64), nullable=False),
        sa.Column("version_name", sa.String(length=128), nullable=False),
        sa.Column("status", sa.String(length=24), nullable=False, server_default="draft"),
        sa.Column("train_dataset_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("artifact_type", sa.String(length=32), nullable=True),
        sa.Column("artifact_uri", sa.Text(), nullable=True),
        sa.Column("artifact_sha256", sa.String(length=128), nullable=True),
        sa.Column("metrics", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("is_testable", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("is_published", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("published_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("published_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("NOW()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("NOW()")),
        sa.ForeignKeyConstraint(["library_key"], ["intent_libraries.library_key"]),
        sa.ForeignKeyConstraint(["train_dataset_id"], ["training_datasets.id"]),
        sa.ForeignKeyConstraint(["published_by"], ["users.id"]),
        sa.ForeignKeyConstraint(["created_by"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_library_model_versions_library_key", "library_model_versions", ["library_key"], unique=False)
    op.create_index("ix_library_model_versions_status", "library_model_versions", ["status"], unique=False)
    op.create_index("ix_library_model_versions_is_testable", "library_model_versions", ["is_testable"], unique=False)
    op.create_index("ix_library_model_versions_is_published", "library_model_versions", ["is_published"], unique=False)

    op.create_table(
        "evaluation_runs",
        sa.Column("library_key", sa.String(length=64), nullable=False),
        sa.Column("model_version_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("dataset_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("status", sa.String(length=24), nullable=False, server_default="pending"),
        sa.Column("threshold_intent_f1", sa.Float(), nullable=False, server_default=sa.text("0.95")),
        sa.Column("threshold_slot_f1", sa.Float(), nullable=False, server_default=sa.text("0.9")),
        sa.Column("snapshot", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("result_summary", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("analysis", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("NOW()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("NOW()")),
        sa.ForeignKeyConstraint(["library_key"], ["intent_libraries.library_key"]),
        sa.ForeignKeyConstraint(["model_version_id"], ["library_model_versions.id"]),
        sa.ForeignKeyConstraint(["dataset_id"], ["evaluation_datasets.id"]),
        sa.ForeignKeyConstraint(["created_by"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_evaluation_runs_library_key", "evaluation_runs", ["library_key"], unique=False)
    op.create_index("ix_evaluation_runs_model_version_id", "evaluation_runs", ["model_version_id"], unique=False)
    op.create_index("ix_evaluation_runs_status", "evaluation_runs", ["status"], unique=False)


def downgrade() -> None:
    op.drop_index("ix_evaluation_runs_status", table_name="evaluation_runs")
    op.drop_index("ix_evaluation_runs_model_version_id", table_name="evaluation_runs")
    op.drop_index("ix_evaluation_runs_library_key", table_name="evaluation_runs")
    op.drop_table("evaluation_runs")

    op.drop_index("ix_library_model_versions_is_published", table_name="library_model_versions")
    op.drop_index("ix_library_model_versions_is_testable", table_name="library_model_versions")
    op.drop_index("ix_library_model_versions_status", table_name="library_model_versions")
    op.drop_index("ix_library_model_versions_library_key", table_name="library_model_versions")
    op.drop_table("library_model_versions")

    op.drop_index("ix_evaluation_datasets_library_key", table_name="evaluation_datasets")
    op.drop_table("evaluation_datasets")

    op.drop_index("ix_training_datasets_library_key", table_name="training_datasets")
    op.drop_table("training_datasets")

    op.drop_column("intent_libraries", "default_slot_f1_threshold")
    op.drop_column("intent_libraries", "default_intent_f1_threshold")
