import { expect, test } from '@playwright/test';

const ok = (data) => ({ code: '000000', data, msg: 'ok' });

async function setupApiMocks(page) {
  const state = {
    libraries: [
      { library_key: 'zh_library', display_name: '中文指令库', language: 'zh', description: '中文', intent_count: 12 },
      { library_key: 'en_library', display_name: '英文指令库', language: 'en', description: 'English', intent_count: 8 },
    ],
    profiles: [],
  };

  await page.route('**/api/v1/**', async (route) => {
    const request = route.request();
    const method = request.method();
    const url = new URL(request.url());
    const path = url.pathname.replace('/api/v1', '');

    if (method === 'GET' && path === '/auth/me') {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(ok({
          id: 'u-1',
          username: 'admin',
          display_name: 'E2E Admin',
          permissions: {
            intent_management: { read: true, write: true, delete: true },
            dialog_profile: { read: true, write: true, delete: true },
            knowledge_management: { read: true },
            testing: { manual: true, batch: true },
            monitoring: { dashboard: true },
            version_publish: true,
            user_management: true,
          },
        })),
      });
      return;
    }

    if (method === 'GET' && path === '/profiles/personas/list') {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        headers: { 'X-Total-Count': '0' },
        body: JSON.stringify(ok([])),
      });
      return;
    }

    if (path === '/libraries' && method === 'GET') {
      const skip = Number(url.searchParams.get('skip') || '0');
      const limit = Number(url.searchParams.get('limit') || '20');
      const items = state.libraries.slice(skip, skip + limit);
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(ok({ items, total: state.libraries.length })),
      });
      return;
    }

    if (path === '/libraries' && method === 'POST') {
      const payload = request.postDataJSON();
      state.libraries.unshift({
        ...payload,
        intent_count: 0,
      });
      await route.fulfill({
        status: 201,
        contentType: 'application/json',
        body: JSON.stringify(ok({ ...payload, intent_count: 0 })),
      });
      return;
    }

    const libPath = path.match(/^\/libraries\/([^/]+)$/);
    if (libPath && method === 'PATCH') {
      const key = decodeURIComponent(libPath[1]);
      const payload = request.postDataJSON();
      state.libraries = state.libraries.map((item) => (item.library_key === key ? { ...item, ...payload } : item));
      const updated = state.libraries.find((item) => item.library_key === key);
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(ok(updated)),
      });
      return;
    }

    if (libPath && method === 'DELETE') {
      const key = decodeURIComponent(libPath[1]);
      state.libraries = state.libraries.filter((item) => item.library_key !== key);
      await route.fulfill({ status: 204, body: '' });
      return;
    }

    const libIntentsPath = path.match(/^\/libraries\/([^/]+)\/intents$/);
    if (libIntentsPath && method === 'GET') {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(ok([])),
      });
      return;
    }

    if (path === '/profiles' && method === 'GET') {
      const skip = Number(url.searchParams.get('skip') || '0');
      const limit = Number(url.searchParams.get('limit') || '20');
      const items = state.profiles.slice(skip, skip + limit);
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        headers: { 'X-Total-Count': String(state.profiles.length) },
        body: JSON.stringify(ok(items)),
      });
      return;
    }

    if (path === '/profiles' && method === 'POST') {
      const payload = request.postDataJSON();
      const profile = {
        id: `p-${Date.now()}`,
        status: 'draft',
        persona: null,
        description: null,
        llm_config: {},
        routing_strategy: 'command_first',
        session_timeout_minutes: 10,
        command_threshold: 0.6,
        intent_library_keys: [],
        ...payload,
      };
      state.profiles.unshift(profile);
      await route.fulfill({
        status: 201,
        contentType: 'application/json',
        body: JSON.stringify(ok(profile)),
      });
      return;
    }

    const profilePath = path.match(/^\/profiles\/([^/]+)$/);
    if (profilePath && method === 'PATCH') {
      const id = decodeURIComponent(profilePath[1]);
      const payload = request.postDataJSON();
      state.profiles = state.profiles.map((item) => (item.id === id ? { ...item, ...payload } : item));
      const updated = state.profiles.find((item) => item.id === id);
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(ok(updated)),
      });
      return;
    }

    if (profilePath && method === 'DELETE') {
      const id = decodeURIComponent(profilePath[1]);
      state.profiles = state.profiles.filter((item) => item.id !== id);
      await route.fulfill({ status: 204, body: '' });
      return;
    }

    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify(ok({})),
    });
  });
}

test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => {
    window.localStorage.setItem('smartchef_token', 'e2e-token');
  });
  await setupApiMocks(page);
});

test('D014: 指令库支持新增编辑删除', async ({ page }) => {
  await page.goto('/intent-libraries');
  await expect(page.getByRole('heading', { name: '指令库管理' })).toBeVisible();

  await page.getByRole('button', { name: '新增指令库' }).click();
  const createModal = page.locator('.ant-modal-content').filter({ hasText: '新增指令库' });
  await expect(createModal).toBeVisible();
  await createModal.locator('input').nth(0).fill('英文命令库');
  await createModal.getByPlaceholder('全局唯一，创建后不可修改').fill('en_commands');
  await createModal.locator('.ant-select').first().click();
  await page.getByTitle('英文').click();
  await createModal.getByRole('button', { name: /确\s*定/ }).click();

  await expect(page.getByText('en_commands')).toBeVisible();
  await expect(page.getByText('英文命令库')).toBeVisible();

  const row = page.locator('tr', { hasText: 'en_commands' });
  await row.getByRole('button', { name: '编辑' }).click();
  const editModal = page.locator('.ant-modal-content').filter({ hasText: '编辑指令库' });
  await editModal.locator('input').nth(0).fill('英文命令库-更新');
  await editModal.getByRole('button', { name: /确\s*定/ }).click();
  await expect(page.getByText('英文命令库-更新')).toBeVisible();

  await page.locator('tr', { hasText: 'en_commands' }).getByRole('button', { name: /删\s*除/ }).click();
  await page.locator('.ant-popover .ant-btn-primary').click();
  await expect(page.getByText('en_commands')).not.toBeVisible();
});

test('D014: 对话方案支持多指令库和指令阈值配置', async ({ page }) => {
  await page.goto('/profiles');
  await expect(page.getByRole('heading', { name: '对话方案配置' })).toBeVisible();

  await page.getByRole('button', { name: '新建方案' }).click();
  const modal = page.locator('.ant-modal-content').filter({ hasText: '新建方案' });
  await expect(modal).toBeVisible();

  // Verify the 2-column form layout exists for simple fields.
  await expect(modal.locator('.ant-row .ant-col-12').first()).toBeVisible();

  await modal.locator('input').first().fill('D014-E2E-Profile');
  await modal.getByRole('combobox', { name: /大模型/ }).click();
  await page.locator('.ant-select-item-option-content', { hasText: /^GPT-4o$/ }).click();
  await modal.getByRole('combobox', { name: /指令库（可多选）/ }).click();
  await page.getByTitle('中文指令库 (中文)').click();
  await page.getByTitle('英文指令库 (英文)').click();
  await modal.locator('input[role="spinbutton"]').nth(1).fill('0.75');
  await modal.getByRole('button', { name: /确\s*定/ }).click();

  await expect(page.getByText('D014-E2E-Profile')).toBeVisible();
  await expect(page.getByText('0.75')).toBeVisible();
});
