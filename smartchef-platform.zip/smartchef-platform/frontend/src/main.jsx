import React from 'react';
import ReactDOM from 'react-dom/client';
import { ConfigProvider } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import App from './App';
import './global.css';

const smartChefTheme = {
  token: {
    colorPrimary: '#d9480f',
    borderRadius: 12,
    colorBgLayout: '#f4efe7',
    colorBgContainer: '#fffdf8',
    colorText: '#2f241f',
    colorTextSecondary: '#6a5148',
    fontFamily: '"Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif',
    boxShadowTertiary: '0 8px 24px rgba(115, 67, 34, 0.12)',
  },
  components: {
    Button: {
      primaryShadow: '0 8px 16px rgba(217, 72, 15, 0.25)',
    },
    Card: {
      borderRadiusLG: 14,
    },
    Modal: {
      borderRadiusLG: 14,
    },
    Table: {
      headerBg: '#f9f2e6',
    },
    Layout: {
      siderBg: '#2f1f17',
      headerBg: '#fff9f0',
      bodyBg: '#f4efe7',
    },
  },
};

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ConfigProvider locale={zhCN} theme={smartChefTheme}>
      <App />
    </ConfigProvider>
  </React.StrictMode>,
);
