import axios from 'axios';

const SUCCESS_CODE = '000000';

class ApiBusinessError extends Error {
  constructor(message, code, status, response) {
    super(message || 'Business error');
    this.name = 'ApiBusinessError';
    this.code = code;
    this.status = status;
    this.response = response;
  }
}

const api = axios.create({
  baseURL: '/api/v1',
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('smartchef_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => {
    const payload = response?.data;
    const isEnvelope = payload && typeof payload === 'object' && 'code' in payload && 'msg' in payload;
    if (!isEnvelope) {
      return response;
    }

    const { code, data, msg } = payload;
    if (code !== SUCCESS_CODE) {
      throw new ApiBusinessError(msg || 'Business error', code, response.status, response);
    }

    response.data = data;
    return response;
  },
  (error) => {
    const status = error.response?.status;
    const payload = error.response?.data;
    const isEnvelope = payload && typeof payload === 'object' && 'code' in payload && 'msg' in payload;

    if (isEnvelope) {
      const { code, msg } = payload;
      if (status === 401) {
        localStorage.removeItem('smartchef_token');
        window.location.href = '/login';
      }
      return Promise.reject(new ApiBusinessError(msg || 'Business error', code, status, error.response));
    }

    if (status === 401) {
      localStorage.removeItem('smartchef_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  },
);

export default api;
export { ApiBusinessError, SUCCESS_CODE };
