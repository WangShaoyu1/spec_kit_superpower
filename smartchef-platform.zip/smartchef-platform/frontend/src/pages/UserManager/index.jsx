import { useEffect, useState, useCallback } from 'react';
import {
  Table, Button, Space, Tag, Input, Select, Modal, Form, message,
  Typography, Popconfirm, Switch, Tabs,
} from 'antd';
import {
  PlusOutlined, EditOutlined, SearchOutlined, UserOutlined,
  SafetyCertificateOutlined, KeyOutlined,
} from '@ant-design/icons';
import api from '../../services/api';
import RoleEditor from './RoleEditor';
import { useAuthStore } from '../../stores/authStore';

const { Title } = Typography;

export default function UserManagerPage() {
  const { user: currentUser } = useAuthStore();
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [searchText, setSearchText] = useState('');
  const [roleFilter, setRoleFilter] = useState(null);
  const [passwordPreview, setPasswordPreview] = useState(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [form] = Form.useForm();
  const isSystemAdmin = !!currentUser?.role_name && currentUser.role_name.includes('管理员');

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get('/auth/users', {
        params: {
          skip: (page - 1) * pageSize,
          limit: pageSize,
          search: searchText || undefined,
          role_id: roleFilter || undefined,
        },
      });
      setUsers(res.data);
      setTotal(Number(res.headers?.['x-total-count'] || 0));
    } catch {
      message.error('加载用户列表失败');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, searchText, roleFilter]);

  const fetchRoles = useCallback(async () => {
    try {
      const res = await api.get('/auth/roles', { params: { skip: 0, limit: 200 } });
      setRoles(res.data);
    } catch { /* 静默失败 */ }
  }, []);

  useEffect(() => { fetchRoles(); }, [fetchRoles]);
  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  // 创建用户
  const openCreate = () => {
    setEditingUser(null);
    form.resetFields();
    setModalVisible(true);
  };

  // 编辑用户
  const openEdit = (user) => {
    setEditingUser(user);
    form.setFieldsValue({
      display_name: user.display_name,
      role_id: user.role_id,
    });
    setModalVisible(true);
  };

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      if (editingUser) {
        await api.patch(`/auth/users/${editingUser.id}`, {
          display_name: values.display_name,
          role_id: values.role_id,
        });
        message.success('更新成功');
      } else {
        await api.post('/auth/users', values);
        message.success('创建成功');
      }
      setModalVisible(false);
      form.resetFields();
      fetchUsers();
    } catch (err) {
      if (err.response) message.error(err.response.data?.detail || '操作失败');
    }
  };

  // 切换启用/禁用
  const handleToggleActive = async (user) => {
    try {
      await api.patch(`/auth/users/${user.id}`, { is_active: !user.is_active });
      message.success(user.is_active ? '已禁用' : '已启用');
      fetchUsers();
    } catch {
      message.error('操作失败');
    }
  };

  const columns = [
    {
      title: '用户名',
      dataIndex: 'username',
      key: 'username',
      sorter: (a, b) => a.username.localeCompare(b.username),
    },
    {
      title: '显示名',
      dataIndex: 'display_name',
      key: 'display_name',
    },
    {
      title: '角色',
      dataIndex: 'role_name',
      key: 'role_name',
      render: (v) => v ? <Tag color="blue">{v}</Tag> : <Tag>未分配</Tag>,
    },
    {
      title: '状态',
      dataIndex: 'is_active',
      key: 'is_active',
      render: (v, record) => (
        <Popconfirm
          title={v ? '确认禁用此用户？' : '确认启用此用户？'}
          onConfirm={() => handleToggleActive(record)}
        >
          <Switch checked={v} size="small" checkedChildren="活跃" unCheckedChildren="禁用" />
        </Popconfirm>
      ),
    },
    {
      title: '创建时间',
      dataIndex: 'created_at',
      key: 'created_at',
      render: (v) => v ? new Date(v).toLocaleString('zh-CN') : '-',
      sorter: (a, b) => new Date(a.created_at) - new Date(b.created_at),
    },
    {
      title: '操作',
      key: 'action',
      width: 240,
      render: (_, record) => (
        <Space>
          <Button size="small" icon={<EditOutlined />} onClick={() => openEdit(record)}>
            编辑
          </Button>
          {isSystemAdmin && (
            <Popconfirm
              title="重置并查看临时密码？"
              description="仅系统管理员可执行，用户将使用临时密码登录。"
              onConfirm={async () => {
                try {
                  const resp = await api.post(`/auth/users/${record.id}/password/reset`);
                  setPasswordPreview(resp.data);
                  message.success('临时密码已生成');
                } catch (err) {
                  message.error(err?.msg || '操作失败');
                }
              }}
            >
              <Button size="small" icon={<KeyOutlined />}>
                查看密码
              </Button>
            </Popconfirm>
          )}
        </Space>
      ),
    },
  ];

  const userTab = (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
        <Space>
          <Input allowClear
            placeholder="搜索用户名/显示名"
            prefix={<SearchOutlined />}
            style={{ width: 240 }}
            value={searchText}
            onChange={(e) => {
              setSearchText(e.target.value);
              setPage(1);
            }}
          />
          <Select
            allowClear
            placeholder="按角色筛选"
            style={{ width: 160 }}
            value={roleFilter}
            onChange={(value) => {
              setRoleFilter(value);
              setPage(1);
            }}
            options={roles.map((r) => ({ label: r.name, value: r.id }))}
          />
        </Space>
        <Button type="primary" icon={<PlusOutlined />} onClick={openCreate}>
          添加用户
        </Button>
      </div>

      <Table
        rowKey="id"
        columns={columns}
        dataSource={users}
        loading={loading}
        pagination={{
          current: page,
          pageSize,
          total,
          showSizeChanger: true,
          showTotal: (t) => `共 ${t} 个用户`,
          onChange: (nextPage, nextPageSize) => {
            if (nextPageSize !== pageSize) {
              setPageSize(nextPageSize);
              setPage(1);
              return;
            }
            setPage(nextPage);
          },
        }}
      />

      <Modal maskClosable={false}
        title={editingUser ? '编辑用户' : '添加用户'}
        open={modalVisible}
        onOk={handleSave}
        onCancel={() => setModalVisible(false)}
        destroyOnHidden
        width={480}
      >
        <Form form={form} layout="vertical">
          {!editingUser && (
            <>
              <Form.Item
                name="username"
                label="用户名"
                rules={[{ required: true, message: '请输入用户名' }, { min: 2, message: '至少 2 个字符' }]}
              >
                <Input allowClear placeholder="唯一登录名" />
              </Form.Item>
              <Form.Item
                name="password"
                label="密码"
                rules={[{ required: true, message: '请输入密码' }, { min: 6, message: '至少 6 个字符' }]}
              >
                <Input.Password allowClear placeholder="至少 6 位" />
              </Form.Item>
            </>
          )}
          <Form.Item
            name="display_name"
            label="显示名"
            rules={[{ required: !editingUser, message: '请输入显示名' }]}
          >
            <Input allowClear placeholder="用户昵称" />
          </Form.Item>
          <Form.Item
            name="role_id"
            label="角色"
            rules={[{ required: true, message: '请选择角色' }]}
          >
            <Select
              placeholder="选择角色"
              options={roles.map((r) => ({ label: r.name, value: r.id }))}
            />
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        maskClosable={false}
        title="临时密码（仅展示一次）"
        open={!!passwordPreview}
        footer={null}
        onCancel={() => setPasswordPreview(null)}
      >
        {passwordPreview && (
          <Space direction="vertical" style={{ width: '100%' }}>
            <Tag color="orange">用户：{passwordPreview.username}</Tag>
            <Input value={passwordPreview.temporary_password} readOnly />
          </Space>
        )}
      </Modal>
    </div>
  );

  const tabItems = [
    {
      key: 'users',
      label: (
        <span><UserOutlined /> 用户列表</span>
      ),
      children: userTab,
    },
    {
      key: 'roles',
      label: (
        <span><SafetyCertificateOutlined /> 角色管理</span>
      ),
      children: <RoleEditor roles={roles} onRolesChange={fetchRoles} />,
    },
  ];

  return (
    <div>
      <Title level={4} style={{ marginBottom: 16 }}>用户与角色管理</Title>
      <Tabs items={tabItems} />
    </div>
  );
}
