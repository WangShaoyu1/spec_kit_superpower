import { useState } from 'react';
import { Modal, Table, Button, Form, Input, Space, message, Popconfirm } from 'antd';
import { PlusOutlined, DeleteOutlined, EditOutlined } from '@ant-design/icons';
import api from '../../services/api';

export default function PersonaEditor({ visible, onClose, personas, onUpdate }) {
  const [createVisible, setCreateVisible] = useState(false);
  const [editingPersona, setEditingPersona] = useState(null);
  const [form] = Form.useForm();
  const [editForm] = Form.useForm();

  const handleCreate = async () => {
    try {
      const values = await form.validateFields();
      await api.post('/profiles/personas', values);
      message.success('创建成功');
      setCreateVisible(false);
      form.resetFields();
      onUpdate?.();
    } catch (err) {
      message.error(err?.msg || '创建失败');
    }
  };

  const openEdit = (persona) => {
    setEditingPersona(persona);
    editForm.setFieldsValue(persona);
  };

  const handleEdit = async () => {
    if (!editingPersona) return;
    try {
      const values = await editForm.validateFields();
      await api.patch(`/profiles/personas/${editingPersona.id}`, values);
      message.success('更新成功');
      setEditingPersona(null);
      onUpdate?.();
    } catch (err) {
      message.error(err?.msg || '更新失败');
    }
  };

  const handleDelete = async (id) => {
    await api.delete(`/profiles/personas/${id}`);
    message.success('删除成功');
    onUpdate?.();
  };

  const columns = [
    { title: '名称', dataIndex: 'name', width: 100 },
    { title: '性格', dataIndex: 'personality', ellipsis: true },
    { title: '语气', dataIndex: 'tone_style', ellipsis: true },
    {
      title: '操作', key: 'action', width: 80,
      render: (_, r) => (
        <Space>
          <Button size="small" icon={<EditOutlined />} onClick={() => openEdit(r)} />
          <Popconfirm title="确认删除？" onConfirm={() => handleDelete(r.id)}>
            <Button size="small" danger icon={<DeleteOutlined />} />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <Modal maskClosable={false} title="闲聊人设管理" open={visible} onCancel={onClose} footer={null} width={700}>
      <Button icon={<PlusOutlined />} onClick={() => { form.resetFields(); setCreateVisible(true); }}
        style={{ marginBottom: 12 }}
      >
        新建人设
      </Button>
      <Table
        rowKey="id"
        columns={columns}
        dataSource={personas}
        size="small"
        pagination={{
          pageSize: 10,
          showSizeChanger: true,
          showTotal: (t) => `共 ${t} 条`,
        }}
      />

      <Modal maskClosable={false} title="新建人设" open={createVisible} onOk={handleCreate} onCancel={() => setCreateVisible(false)}>
        <Form form={form} layout="vertical">
          <Form.Item name="name" label="助手名称" rules={[{ required: true }]}>
            <Input allowClear placeholder="如：小厨" />
          </Form.Item>
          <Form.Item name="personality" label="性格特征" rules={[{ required: true }]}>
            <Input.TextArea allowClear rows={2} placeholder="活泼友好、专业可靠、幽默风趣..." />
          </Form.Item>
          <Form.Item name="tone_style" label="语气风格" rules={[{ required: true }]}>
            <Input.TextArea allowClear rows={2} placeholder="亲切随和、简洁专业..." />
          </Form.Item>
          <Form.Item name="system_prompt" label="系统提示词" rules={[{ required: true }]}>
            <Input.TextArea allowClear rows={4} placeholder="你是一个友好的厨房助手..." />
          </Form.Item>
        </Form>
      </Modal>

      <Modal maskClosable={false} title="编辑人设" open={!!editingPersona} onOk={handleEdit} onCancel={() => setEditingPersona(null)}>
        <Form form={editForm} layout="vertical">
          <Form.Item name="name" label="助手名称" rules={[{ required: true }]}>
            <Input allowClear placeholder="如：小厨" />
          </Form.Item>
          <Form.Item name="personality" label="性格特征" rules={[{ required: true }]}>
            <Input.TextArea allowClear rows={2} placeholder="活泼友好、专业可靠、幽默风趣..." />
          </Form.Item>
          <Form.Item name="tone_style" label="语气风格" rules={[{ required: true }]}>
            <Input.TextArea allowClear rows={2} placeholder="亲切随和、简洁专业..." />
          </Form.Item>
          <Form.Item name="system_prompt" label="系统提示词" rules={[{ required: true }]}>
            <Input.TextArea allowClear rows={4} placeholder="你是一个友好的厨房助手..." />
          </Form.Item>
        </Form>
      </Modal>
    </Modal>
  );
}
