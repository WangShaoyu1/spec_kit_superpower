import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Button,
  Card,
  Descriptions,
  Empty,
  Form,
  Input,
  InputNumber,
  message,
  Modal,
  Select,
  Space,
  Steps,
  Table,
  Tag,
  Typography,
} from 'antd';
import { FileExcelOutlined, PlusOutlined, RocketOutlined } from '@ant-design/icons';
import * as XLSX from 'xlsx';
import api from '../../services/api';
import AnalysisReport from './AnalysisReport';

const { Title, Text } = Typography;

export default function BatchTestPage() {
  const [suites, setSuites] = useState([]);
  const [suiteTotal, setSuiteTotal] = useState(0);
  const [suitePage, setSuitePage] = useState(1);
  const [suitePageSize, setSuitePageSize] = useState(10);
  const [profiles, setProfiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [createVisible, setCreateVisible] = useState(false);
  const [importVisible, setImportVisible] = useState(false);
  const [reportVisible, setReportVisible] = useState(false);
  const [selectedSuite, setSelectedSuite] = useState(null);
  const [importCases, setImportCases] = useState([]);
  const [latestReport, setLatestReport] = useState(null);
  const [detailCases, setDetailCases] = useState([]);
  const [createForm] = Form.useForm();
  const [thresholdForm] = Form.useForm();
  const fileInputRef = useRef(null);

  const fetchSuites = async () => {
    setLoading(true);
    try {
      const res = await api.get('/testing/batch/suites', {
        params: { skip: (suitePage - 1) * suitePageSize, limit: suitePageSize },
      });
      setSuites(res.data);
      setSuiteTotal(Number(res.headers?.['x-total-count'] || 0));
    } catch { message.error('加载失败'); }
    finally { setLoading(false); }
  };

  const fetchProfiles = async () => {
    try {
      const res = await api.get('/profiles', { params: { skip: 0, limit: 200 } });
      setProfiles(res.data);
    } catch { /* */ }
  };

  useEffect(() => {
    fetchProfiles();
  }, []);

  useEffect(() => {
    fetchSuites();
  }, [suitePage, suitePageSize]);

  const handleCreateSuite = async () => {
    try {
      const values = await createForm.validateFields();
      const resp = await api.post('/testing/batch/suites', values);
      message.success('批次创建成功，请继续上传测试用例');
      setCreateVisible(false);
      createForm.resetFields();
      setSelectedSuite(resp.data);
      setImportCases([]);
      setImportVisible(true);
      fetchSuites();
    } catch (err) {
      message.error(err?.msg || '创建失败');
    }
  };

  const parseRowsToCases = (rows) => rows
    .map((row) => {
      const input_text = String(row.input_text || row['输入文本'] || row.text || '').trim();
      const expected_intent = String(row.expected_intent || row['期望意图'] || '').trim() || null;
      const expected_domain = String(row.expected_domain || row['期望域'] || '').trim() || null;
      return { input_text, expected_intent, expected_domain };
    })
    .filter((item) => item.input_text);

  const handleFilePicked = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const buffer = await file.arrayBuffer();
      if (file.name.toLowerCase().endsWith('.csv')) {
        const text = new TextDecoder().decode(new Uint8Array(buffer));
        const lines = text.split(/\r?\n/).filter((line) => line.trim());
        const rows = lines.slice(1).map((line) => {
          const [input_text, expected_intent, expected_domain] = line.split(',');
          return { input_text, expected_intent, expected_domain };
        });
        setImportCases(parseRowsToCases(rows));
      } else {
        const workbook = XLSX.read(buffer, { type: 'array' });
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(firstSheet, { defval: '' });
        setImportCases(parseRowsToCases(rows));
      }
      message.success('文件解析成功');
    } catch {
      message.error('文件解析失败，请检查模板格式');
    } finally {
      event.target.value = '';
    }
  };

  const handleImportCases = async () => {
    if (!selectedSuite) return;
    if (!importCases.length) {
      message.warning('请先上传并解析测试用例文件');
      return;
    }

    try {
      await api.post(`/testing/batch/suites/${selectedSuite.id}/cases`, { cases: importCases });
      message.success(`已导入 ${importCases.length} 条用例`);
      await fetchSuites();
      setImportVisible(false);
    } catch (err) {
      message.error(err?.msg || '导入失败');
    }
  };

  const openImportForSuite = async (suite) => {
    setSelectedSuite(suite);
    setImportCases([]);
    setImportVisible(true);
    try {
      const detailResp = await api.get(`/testing/batch/suites/${suite.id}`);
      setImportCases(detailResp.data.cases || []);
    } catch {
      // ignore
    }
  };

  const executeSuite = async (suite) => {
    try {
      const values = await thresholdForm.validateFields();
      await api.post(`/testing/batch/suites/${suite.id}/execute`, {
        accuracy_threshold: values.accuracy_threshold / 100,
        latency_threshold_ms: values.latency_threshold_ms,
      });
      message.success('批量测试执行完成');
      await viewReport(suite);
      fetchSuites();
    } catch (err) {
      message.error(err?.msg || '执行失败');
    }
  };

  const viewReport = async (suite) => {
    setSelectedSuite(suite);
    setReportVisible(true);
    setLatestReport(null);
    setDetailCases([]);
    try {
      const [detailResp, reportResp] = await Promise.all([
        api.get(`/testing/batch/suites/${suite.id}`),
        api.get(`/testing/batch/suites/${suite.id}/report`).catch(() => ({ data: null })),
      ]);
      setDetailCases(detailResp.data.cases || []);
      setLatestReport(reportResp.data);
    } catch {
      message.error('加载报告失败');
    }
  };

  const currentStep = useMemo(() => {
    if (!selectedSuite) return 0;
    if (!importCases.length) return 1;
    return 2;
  }, [selectedSuite, importCases.length]);

  const columns = [
    { title: '批次名称', dataIndex: 'name' },
    { title: '用例数', dataIndex: 'case_count', width: 100 },
    { title: '创建时间', dataIndex: 'created_at', render: (v) => new Date(v).toLocaleString() },
    {
      title: '操作',
      width: 360,
      render: (_, record) => (
        <Space>
          <Button size="small" icon={<FileExcelOutlined />} onClick={() => openImportForSuite(record)}>
            上传用例
          </Button>
          <Button
            size="small"
            type="primary"
            icon={<RocketOutlined />}
            disabled={!record.case_count}
            onClick={() => executeSuite(record)}
          >
            执行
          </Button>
          <Button size="small" onClick={() => viewReport(record)}>查看结论</Button>
        </Space>
      ),
    },
  ];

  const caseColumns = [
    { title: '输入文本', dataIndex: 'input_text', ellipsis: true },
    { title: '期望意图', dataIndex: 'expected_intent', width: 160 },
    { title: '期望域', dataIndex: 'expected_domain', width: 120 },
  ];

  const reportSummary = latestReport ? (
    <Descriptions size="small" bordered column={4}>
      <Descriptions.Item label="总用例">{latestReport.total_cases}</Descriptions.Item>
      <Descriptions.Item label="通过">{latestReport.passed_cases}</Descriptions.Item>
      <Descriptions.Item label="失败">{latestReport.failed_cases}</Descriptions.Item>
      <Descriptions.Item label="达标">
        {latestReport.is_passed ? <Tag color="green">达标</Tag> : <Tag color="red">不达标</Tag>}
      </Descriptions.Item>
      <Descriptions.Item label="准确率">{Math.round((latestReport.accuracy || 0) * 1000) / 10}%</Descriptions.Item>
      <Descriptions.Item label="平均延迟">{latestReport.avg_latency_ms?.toFixed(1) || '-'} ms</Descriptions.Item>
      <Descriptions.Item label="P95 延迟">{latestReport.p95_latency_ms?.toFixed(1) || '-'} ms</Descriptions.Item>
      <Descriptions.Item label="执行时间">{new Date(latestReport.executed_at).toLocaleString()}</Descriptions.Item>
    </Descriptions>
  ) : (
    <Empty description="该批次尚未执行测试" />
  );

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
        <Title level={4} style={{ margin: 0 }}>批量测试与分析</Title>
        <Button type="primary" icon={<PlusOutlined />} onClick={() => { createForm.resetFields(); setCreateVisible(true); }}>
          新建批次
        </Button>
      </div>

      <Alert
        showIcon
        type="info"
        style={{ marginBottom: 12 }}
        message="两步流：先创建批次，再上传 Excel/CSV 用例，最后执行并查看测试结论。"
      />
      <Table
        rowKey="id"
        columns={columns}
        dataSource={suites}
        loading={loading}
        pagination={{
          current: suitePage,
          pageSize: suitePageSize,
          total: suiteTotal,
          showSizeChanger: true,
          showTotal: (t) => `共 ${t} 条`,
          onChange: (nextPage, nextPageSize) => {
            if (nextPageSize !== suitePageSize) {
              setSuitePageSize(nextPageSize);
              setSuitePage(1);
              return;
            }
            setSuitePage(nextPage);
          },
        }}
      />

      <Modal
        maskClosable={false}
        title="步骤 1：新建测试批次"
        open={createVisible}
        onOk={handleCreateSuite}
        onCancel={() => setCreateVisible(false)}
        width={640}
      >
        <Form form={createForm} layout="vertical">
          <Form.Item name="name" label="批次名称" rules={[{ required: true }]}><Input allowClear /></Form.Item>
          <Form.Item name="profile_id" label="对话方案" rules={[{ required: true }]}>
            <Select options={profiles.map((p) => ({ label: `${p.name} (${p.llm_provider})`, value: p.id }))} />
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        maskClosable={false}
        title={`步骤 2：上传测试用例 - ${selectedSuite?.name || ''}`}
        open={importVisible}
        onOk={handleImportCases}
        onCancel={() => setImportVisible(false)}
        width={980}
      >
        <Steps
          current={currentStep}
          size="small"
          items={[
            { title: '新建批次' },
            { title: '导入用例文件' },
            { title: '执行并查看结论' },
          ]}
          style={{ marginBottom: 16 }}
        />
        <Space style={{ marginBottom: 12 }}>
          <Button onClick={() => fileInputRef.current?.click()} icon={<FileExcelOutlined />}>选择 Excel/CSV 文件</Button>
          <Button
            type="link"
            onClick={() => {
              const ws = XLSX.utils.json_to_sheet([
                { input_text: '开始烹饪', expected_intent: 'voice_cmd_start_cooking', expected_domain: 'command' },
                { input_text: '红烧肉怎么做', expected_intent: '', expected_domain: 'knowledge' },
                { input_text: '你好', expected_intent: '', expected_domain: 'chitchat' },
              ]);
              const wb = XLSX.utils.book_new();
              XLSX.utils.book_append_sheet(wb, ws, 'cases');
              XLSX.writeFile(wb, 'batch_test_template.xlsx');
            }}
          >
            下载 Excel 模板
          </Button>
        </Space>
        <input ref={fileInputRef} type="file" accept=".xlsx,.xls,.csv" style={{ display: 'none' }} onChange={handleFilePicked} />
        <Table
          rowKey={(r, i) => `${r.input_text}-${i}`}
          dataSource={importCases}
          columns={caseColumns}
          size="small"
          pagination={{ pageSize: 8 }}
          locale={{ emptyText: '尚未导入用例' }}
        />
      </Modal>

      <Modal
        maskClosable={false}
        title={`批量测试结论 - ${selectedSuite?.name || ''}`}
        open={reportVisible}
        onCancel={() => setReportVisible(false)}
        footer={null}
        width={1200}
      >
        <Card size="small" style={{ marginBottom: 12 }}>
          {reportSummary}
        </Card>
        <Card size="small" title="智能分析报告" style={{ marginBottom: 12 }}>
          {latestReport ? (
            <AnalysisReport report={{
              confusion_matrix: latestReport.analysis_report?.confusion_matrix || {},
              attributions: latestReport.analysis_report?.attributions || latestReport.analysis_report?.failure_analysis || [],
              suggestions: latestReport.analysis_report?.suggestions || latestReport.analysis_report?.optimization_suggestions || [],
              overall_accuracy: latestReport.accuracy || 0,
            }}
            />
          ) : (
            <Empty description="暂无分析报告" />
          )}
        </Card>
        <Card size="small" title="测试用例清单">
          <Table
            rowKey={(r, i) => `${r.input_text}-${i}`}
            dataSource={detailCases}
            columns={caseColumns}
            size="small"
            scroll={{ y: 260 }}
            pagination={false}
          />
        </Card>
      </Modal>
    </div>
  );
}
