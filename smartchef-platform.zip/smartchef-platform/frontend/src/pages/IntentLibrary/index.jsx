import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Button,
  Card,
  Empty,
  Form,
  Input,
  Modal,
  Popconfirm,
  Select,
  Space,
  Table,
  Tag,
  Typography,
  message,
} from 'antd';
import { EditOutlined, PlusOutlined, SettingOutlined } from '@ant-design/icons';
import api from '../../services/api';
import IntentManager from '../IntentManager/index';
import ModelManager from './ModelManager';
import { useLocation, useNavigate, useParams } from 'react-router-dom';

const { Title, Text } = Typography;

export default function IntentLibraryPage() {
  const { libraryKey } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const [libraries, setLibraries] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form] = Form.useForm();

  const fetchLibraries = useCallback(async () => {
    setLoading(true);
    try {
      const params = { skip: (page - 1) * pageSize, limit: pageSize };
      const res = await api.get('/libraries', { params });
      setLibraries(res.data.items || []);
      setTotal(Number(res.data.total || 0));
    } catch (err) {
      message.error('加载指令库失败');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize]);

  useEffect(() => {
    fetchLibraries();
  }, [fetchLibraries]);

  const categories = useMemo(
    () => libraries.map((lib) => ({ ...lib, name: lib.display_name, key: lib.library_key, count: lib.intent_count })),
    [libraries],
  );

  const openCreate = () => {
    setEditing(null);
    form.resetFields();
    form.setFieldsValue({ language: 'zh' });
    setModalOpen(true);
  };

  const openEdit = (record) => {
    setEditing(record);
    form.setFieldsValue(record);
    setModalOpen(true);
  };

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      if (editing) {
        await api.patch(`/libraries/${editing.library_key}`, values);
        message.success('更新成功');
      } else {
        await api.post('/libraries', values);
        message.success('创建成功');
        setPage(1);
      }
      setModalOpen(false);
      fetchLibraries();
    } catch (err) {
      message.error(err?.msg || '保存失败');
    }
  };

  const handleDelete = async (key) => {
    try {
      await api.delete(`/libraries/${key}`);
      message.success('删除成功');
      if (page > 1 && libraries.length === 1) {
        setPage(page - 1);
      } else {
        fetchLibraries();
      }
    } catch (err) {
      message.error(err?.msg || '删除失败');
    }
  };

  if (libraryKey && location.pathname.endsWith('/models')) {
    return (
      <div>
        <Space style={{ marginBottom: 12 }}>
          <Tag color="purple">当前指令库：{libraryKey}</Tag>
          <Tag style={{ cursor: 'pointer' }} onClick={() => navigate('/intent-libraries')}>返回指令库列表</Tag>
        </Space>
        <ModelManager libraryKey={libraryKey} />
      </div>
    );
  }

  if (libraryKey) {
    return (
      <div>
        <Space style={{ marginBottom: 12 }}>
          <Tag color="blue">当前指令库：{libraryKey}</Tag>
          <Tag style={{ cursor: 'pointer' }} onClick={() => navigate('/intent-libraries')}>返回指令库列表</Tag>
        </Space>
        <IntentManager
          forcedCategory={libraryKey}
          pageTitle={`${libraryKey} - 意图列表`}
        />
      </div>
    );
  }

  return (
    <div>
      <Space style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <Title level={4} style={{ margin: 0 }}>指令库管理 <Text type="secondary">一级：指令库（固定中/英语种） → 二级：进入后查看该库意图列表</Text></Title>
        <Button type="primary" icon={<PlusOutlined />} onClick={openCreate}>新增指令库</Button>
      </Space>
      

      {categories.length === 0 ? (
        <Card style={{ marginTop: 16 }}>
          <Empty description="暂无可用指令库，请先新增指令库" />
        </Card>
      ) : (
        <Table
          style={{ marginTop: 16 }}
          rowKey="library_key"
          loading={loading}
          dataSource={categories}
          pagination={{
            current: page,
            pageSize,
            total,
            showSizeChanger: true,
            showTotal: (t) => `共 ${t} 条`,
            onChange: (nextPage, nextSize) => {
              if (nextSize !== pageSize) {
                setPageSize(nextSize);
                setPage(1);
                return;
              }
              setPage(nextPage);
            },
          }}
          columns={[
            {
              title: '指令库',
              dataIndex: 'display_name',
              width: 240,
              render: (_, record) => (
                <a onClick={() => navigate(`/intent-libraries/${encodeURIComponent(record.library_key)}/intents`)}>
                  {record.display_name}
                </a>
              ),
            },
            { title: 'library_key', dataIndex: 'library_key', width: 240 },
            {
              title: '语种',
              dataIndex: 'language',
              width: 240,
              render: (value) => <Tag color={value === 'en' ? 'blue' : 'green'}>{value === 'en' ? '英文' : '中文'}</Tag>,
            },
            { title: '描述', dataIndex: 'description', ellipsis: true},
            {
              title: '操作',
              width: 300,
              render: (_, record) => (
                <Space>
                  <Button
                    size="small"
                    type="primary"
                    icon={<SettingOutlined />}
                    onClick={() => navigate(`/intent-libraries/${encodeURIComponent(record.library_key)}/intents`)}
                  >
                    意图
                  </Button>
                  <Button size="small" onClick={() => navigate(`/intent-libraries/${encodeURIComponent(record.library_key)}/models`)}>
                    模型
                  </Button>
                  <Button size="small" icon={<EditOutlined />} onClick={() => openEdit(record)}>编辑</Button>
                  <Popconfirm
                    title="确认删除该指令库？"
                    description="若存在关联意图将删除失败，请先迁移或删除意图。"
                    onConfirm={() => handleDelete(record.library_key)}
                  >
                    <Button size="small" danger>删除</Button>
                  </Popconfirm>
                </Space>
              ),
            },
          ]}
        />
      )}

      <Modal
        maskClosable={false}
        title={editing ? '编辑指令库' : '新增指令库'}
        open={modalOpen}
        onOk={handleSave}
        onCancel={() => setModalOpen(false)}
      >
        <Form form={form} layout="vertical">
          <Form.Item name="display_name" label="名称" rules={[{ required: true }]}>
            <Input allowClear />
          </Form.Item>
          <Form.Item
            name="library_key"
            label="library_key"
            rules={[{ required: true }, { pattern: /^[a-zA-Z0-9_\-\u4e00-\u9fa5]+$/, message: '仅支持中英文、数字、下划线、中划线' }]}
          >
            <Input allowClear disabled={!!editing} placeholder="全局唯一，创建后不可修改" />
          </Form.Item>
          <Form.Item name="language" label="语种" rules={[{ required: true }]}>
            <Select
              options={[
                { label: '中文', value: 'zh' },
                { label: '英文', value: 'en' },
              ]}
            />
          </Form.Item>
          <Form.Item name="description" label="描述">
            <Input.TextArea allowClear rows={3} />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}
