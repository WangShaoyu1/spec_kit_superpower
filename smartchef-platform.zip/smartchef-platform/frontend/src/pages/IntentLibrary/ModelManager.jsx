import { useCallback, useEffect, useMemo, useState } from 'react';
import { Button, Card, Checkbox, Collapse, Form, Input, InputNumber, Modal, Select, Space, Table, Tag, Typography, message } from 'antd';
import * as XLSX from 'xlsx';
import api from '../../services/api';

const { Title, Text } = Typography;

export default function ModelManager({ libraryKey }) {
  const [models, setModels] = useState([]);
  const [trainingDatasets, setTrainingDatasets] = useState([]);
  const [evaluationDatasets, setEvaluationDatasets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [trainOpen, setTrainOpen] = useState(false);
  const [evalOpen, setEvalOpen] = useState(false);
  const [evalModelId, setEvalModelId] = useState(null);
  const [trainingDatasetOpen, setTrainingDatasetOpen] = useState(false);
  const [evaluationDatasetOpen, setEvaluationDatasetOpen] = useState(false);
  const [singleTestOpen, setSingleTestOpen] = useState(false);
  const [singleTestModelId, setSingleTestModelId] = useState(null);
  const [singleTestResult, setSingleTestResult] = useState(null);
  const [evalRunsOpen, setEvalRunsOpen] = useState(false);
  const [evalRuns, setEvalRuns] = useState([]);
  const [publishOpen, setPublishOpen] = useState(false);
  const [publishModelId, setPublishModelId] = useState(null);
  const [importOpen, setImportOpen] = useState(false);
  const [importKind, setImportKind] = useState('training');
  const [importFile, setImportFile] = useState(null);
  const [exportOpen, setExportOpen] = useState(false);
  const [exportKind, setExportKind] = useState('training');
  const [trainForm] = Form.useForm();
  const [evalForm] = Form.useForm();
  const [trainDsForm] = Form.useForm();
  const [evalDsForm] = Form.useForm();
  const [singleTestForm] = Form.useForm();
  const [publishForm] = Form.useForm();
  const [importForm] = Form.useForm();
  const [exportForm] = Form.useForm();

  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const [modelsRes, trainDsRes, evalDsRes] = await Promise.all([
        api.get(`/libraries/${encodeURIComponent(libraryKey)}/models`),
        api.get(`/libraries/${encodeURIComponent(libraryKey)}/training-datasets`),
        api.get(`/libraries/${encodeURIComponent(libraryKey)}/evaluation-datasets`),
      ]);
      setModels(modelsRes.data || []);
      setTrainingDatasets(trainDsRes.data || []);
      setEvaluationDatasets(evalDsRes.data || []);
    } catch {
      message.error('加载模型信息失败');
    } finally {
      setLoading(false);
    }
  }, [libraryKey]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const datasetOptions = useMemo(
    () => trainingDatasets.map((d) => ({ label: `${d.name} (${d.sample_count})`, value: d.id })),
    [trainingDatasets],
  );

  const evalDatasetOptions = useMemo(
    () => evaluationDatasets.map((d) => ({ label: `${d.name} (${d.sample_count})`, value: d.id })),
    [evaluationDatasets],
  );

  const importDatasetOptions = importKind === 'training' ? datasetOptions : evalDatasetOptions;
  const exportDatasetOptions = exportKind === 'training' ? datasetOptions : evalDatasetOptions;

  const downloadTemplate = (kind) => {
    const rows = kind === 'training'
      ? [{ intent_key: '', utterance: '', language: 'zh', slots: '{}', source: 'manual' }]
      : [{
        intent_key: '', utterance: '', language: 'zh', source: 'manual', expected_result: '{}', actual_result: '', threshold: '', actual_score: '', is_hit: '',
      }];
    const sheet = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, sheet, 'template');
    XLSX.writeFile(wb, kind === 'training' ? 'training_dataset_template.xlsx' : 'evaluation_dataset_template.xlsx');
  };

  const parseJsonSafe = (value) => {
    if (value === null || value === undefined || value === '') return undefined;
    if (typeof value === 'object') return value;
    try {
      return JSON.parse(String(value));
    } catch {
      return value;
    }
  };

  const parseBoolSafe = (value) => {
    if (value === null || value === undefined || value === '') return undefined;
    if (typeof value === 'boolean') return value;
    const text = String(value).trim().toLowerCase();
    if (['true', '1', 'yes', 'y', '是'].includes(text)) return true;
    if (['false', '0', 'no', 'n', '否'].includes(text)) return false;
    return undefined;
  };

  const importExcelRows = async () => {
    try {
      const values = await importForm.validateFields();
      if (!importFile) {
        message.error('请先选择 Excel 文件');
        return;
      }
      const buf = await importFile.arrayBuffer();
      const wb = XLSX.read(buf, { type: 'array' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rawRows = XLSX.utils.sheet_to_json(ws, { defval: '' });
      if (!Array.isArray(rawRows) || rawRows.length === 0) {
        message.error('Excel 无有效数据');
        return;
      }
      const rows = rawRows.map((row) => (importKind === 'training'
        ? {
          intent_key: String(row.intent_key || '').trim(),
          utterance: String(row.utterance || '').trim(),
          language: String(row.language || 'zh').trim(),
          slots: parseJsonSafe(row.slots) || {},
          source: String(row.source || 'manual').trim(),
        }
        : {
          intent_key: String(row.intent_key || '').trim(),
          utterance: String(row.utterance || '').trim(),
          language: String(row.language || 'zh').trim(),
          source: String(row.source || 'manual').trim(),
          expected_result: parseJsonSafe(row.expected_result),
          actual_result: parseJsonSafe(row.actual_result),
          threshold: row.threshold === '' ? undefined : Number(row.threshold),
          actual_score: row.actual_score === '' ? undefined : Number(row.actual_score),
          is_hit: parseBoolSafe(row.is_hit),
        }));
      const path = importKind === 'training'
        ? `/libraries/${encodeURIComponent(libraryKey)}/training-datasets/${values.dataset_id}/import`
        : `/libraries/${encodeURIComponent(libraryKey)}/evaluation-datasets/${values.dataset_id}/import`;
      await api.post(path, { rows });
      message.success(`已导入 ${rows.length} 条${importKind === 'training' ? '训练' : '评估'}样本`);
      setImportOpen(false);
      setImportFile(null);
      importForm.resetFields();
      fetchAll();
    } catch (err) {
      message.error(err?.message || 'Excel 导入失败');
    }
  };

  const exportExcelRows = async () => {
    try {
      const values = await exportForm.validateFields();
      const path = exportKind === 'training'
        ? `/libraries/${encodeURIComponent(libraryKey)}/training-datasets/${values.dataset_id}/rows`
        : `/libraries/${encodeURIComponent(libraryKey)}/evaluation-datasets/${values.dataset_id}/rows`;
      const res = await api.get(path);
      const rows = res.data?.rows || [];
      const normalized = rows.map((row) => ({
        ...row,
        expected_result: typeof row.expected_result === 'object' ? JSON.stringify(row.expected_result) : row.expected_result,
        actual_result: typeof row.actual_result === 'object' ? JSON.stringify(row.actual_result) : row.actual_result,
        slots: typeof row.slots === 'object' ? JSON.stringify(row.slots) : row.slots,
      }));
      const sheet = XLSX.utils.json_to_sheet(normalized);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, sheet, 'rows');
      XLSX.writeFile(wb, `${libraryKey}_${exportKind}_dataset_rows.xlsx`);
      setExportOpen(false);
      exportForm.resetFields();
      message.success('样本导出成功');
    } catch (err) {
      message.error(err?.message || '样本导出失败');
    }
  };

  const trainModel = async () => {
    try {
      const values = await trainForm.validateFields();
      await api.post(`/libraries/${encodeURIComponent(libraryKey)}/models/train`, values);
      message.success('训练任务已创建');
      setTrainOpen(false);
      trainForm.resetFields();
      fetchAll();
    } catch (err) {
      message.error(err?.message || '创建训练任务失败');
    }
  };

  const createTrainingDataset = async () => {
    try {
      const values = await trainDsForm.validateFields();
      await api.post(`/libraries/${encodeURIComponent(libraryKey)}/training-datasets`, values);
      message.success('训练集已创建');
      setTrainingDatasetOpen(false);
      trainDsForm.resetFields();
      fetchAll();
    } catch (err) {
      message.error(err?.message || '创建训练集失败');
    }
  };

  const createEvaluationDataset = async () => {
    try {
      const values = await evalDsForm.validateFields();
      await api.post(`/libraries/${encodeURIComponent(libraryKey)}/evaluation-datasets`, values);
      message.success('评估集已创建');
      setEvaluationDatasetOpen(false);
      evalDsForm.resetFields();
      fetchAll();
    } catch (err) {
      message.error(err?.message || '创建评估集失败');
    }
  };

  const evaluateModel = async () => {
    try {
      const values = await evalForm.validateFields();
      await api.post(`/libraries/${encodeURIComponent(libraryKey)}/models/${evalModelId}/evaluate`, values);
      message.success('评估已完成并生成分析');
      setEvalOpen(false);
      setEvalModelId(null);
      evalForm.resetFields();
      fetchAll();
    } catch (err) {
      message.error(err?.message || '评估失败');
    }
  };

  const callAction = async (path, okMessage) => {
    try {
      await api.post(path);
      message.success(okMessage);
      fetchAll();
    } catch (err) {
      message.error(err?.message || '操作失败');
    }
  };

  const publishModel = async () => {
    try {
      const values = await publishForm.validateFields();
      await api.post(`/libraries/${encodeURIComponent(libraryKey)}/models/${publishModelId}/publish`, values);
      message.success('模型已发布');
      setPublishOpen(false);
      setPublishModelId(null);
      publishForm.resetFields();
      fetchAll();
    } catch (err) {
      message.error(err?.message || '发布失败');
    }
  };

  const runSingleTest = async () => {
    try {
      const values = await singleTestForm.validateFields();
      const res = await api.post(
        `/libraries/${encodeURIComponent(libraryKey)}/models/${singleTestModelId}/test-one`,
        values,
      );
      setSingleTestResult(res.data);
      message.success('单条测试已完成');
    } catch (err) {
      message.error(err?.message || '单条测试失败');
    }
  };

  const viewEvalRuns = async (modelId) => {
    try {
      const res = await api.get(`/libraries/${encodeURIComponent(libraryKey)}/models/${modelId}/evaluations`);
      setEvalRuns(res.data || []);
      setEvalRunsOpen(true);
    } catch {
      message.error('加载评估记录失败');
    }
  };

  return (
    <div>
      <Space style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <Title level={4} style={{ margin: 0 }}>
          模型管理 <Text type="secondary">库：{libraryKey}</Text>
        </Title>
        <Space>
          <Button onClick={() => downloadTemplate('training')}>训练模板</Button>
          <Button onClick={() => downloadTemplate('evaluation')}>评估模板</Button>
          <Button onClick={() => { setImportKind('training'); setImportOpen(true); }}>导入训练Excel</Button>
          <Button onClick={() => { setImportKind('evaluation'); setImportOpen(true); }}>导入评估Excel</Button>
          <Button onClick={() => { setExportKind('training'); setExportOpen(true); }}>导出训练样本</Button>
          <Button onClick={() => { setExportKind('evaluation'); setExportOpen(true); }}>导出评估样本</Button>
          <Button onClick={() => setTrainingDatasetOpen(true)}>新增训练集</Button>
          <Button onClick={() => setEvaluationDatasetOpen(true)}>新增评估集</Button>
          <Button type="primary" onClick={() => setTrainOpen(true)}>训练模型</Button>
        </Space>
      </Space>

      <Card size="small" style={{ marginBottom: 12 }}>
        <Space wrap>
          <Tag color="geekblue">训练集: {trainingDatasets.length}</Tag>
          <Tag color="purple">评估集: {evaluationDatasets.length}</Tag>
          <Tag color="orange">模型上限: 5 (代码常量)</Tag>
        </Space>
      </Card>

      <Table
        rowKey="id"
        loading={loading}
        dataSource={models}
        columns={[
          { title: '版本名', dataIndex: 'version_name' },
          { title: '状态', dataIndex: 'status', render: (v) => <Tag>{v}</Tag> },
          { title: 'testable', dataIndex: 'is_testable', render: (v) => (v ? '是' : '否') },
          { title: 'published', dataIndex: 'is_published', render: (v) => (v ? '是' : '否') },
          {
            title: '指标',
            dataIndex: 'metrics',
            render: (v) => (
              <Text type="secondary">
                intent_f1={v?.intent_f1 ?? '-'} / slot_f1={v?.slot_f1 ?? '-'}
              </Text>
            ),
          },
          {
            title: '操作',
            render: (_, record) => (
              <Space wrap>
                <Button
                  size="small"
                  onClick={() =>
                    callAction(
                      `/libraries/${encodeURIComponent(libraryKey)}/models/${record.id}/testable`,
                      '已设为测试模型',
                    )
                  }
                >
                  设为测试
                </Button>
                <Button
                  size="small"
                  type="primary"
                  onClick={() => {
                    setPublishModelId(record.id);
                    setPublishOpen(true);
                    publishForm.setFieldsValue({ confirm_publish: false, publish_note: '' });
                  }}
                >
                  发布
                </Button>
                <Button
                  size="small"
                  onClick={() => {
                    setEvalModelId(record.id);
                    setEvalOpen(true);
                  }}
                >
                  评估
                </Button>
                <Button
                  size="small"
                  onClick={() => {
                    setSingleTestModelId(record.id);
                    setSingleTestOpen(true);
                    setSingleTestResult(null);
                  }}
                >
                  单条测试
                </Button>
                <Button size="small" onClick={() => viewEvalRuns(record.id)}>
                  评估记录
                </Button>
                <Button
                  size="small"
                  danger
                  onClick={() =>
                    callAction(
                      `/libraries/${encodeURIComponent(libraryKey)}/models/${record.id}/archive`,
                      '已归档',
                    )
                  }
                >
                  归档
                </Button>
              </Space>
            ),
          },
        ]}
      />

      <Modal maskClosable={false} title="训练模型" open={trainOpen} onCancel={() => setTrainOpen(false)} onOk={trainModel}>
        <Form form={trainForm} layout="vertical">
          <Form.Item name="version_name" label="模型版本名" rules={[{ required: true }]}>
            <Input allowClear />
          </Form.Item>
          <Form.Item name="train_dataset_id" label="训练集" rules={[{ required: true }]}>
            <Select options={datasetOptions} placeholder="请选择训练集" />
          </Form.Item>
          <Form.Item name="notes" label="备注">
            <Input.TextArea allowClear rows={3} />
          </Form.Item>
        </Form>
      </Modal>

      <Modal maskClosable={false} title="创建训练集" open={trainingDatasetOpen} onCancel={() => setTrainingDatasetOpen(false)} onOk={createTrainingDataset}>
        <Form form={trainDsForm} layout="vertical" initialValues={{ source_type: 'manual', sample_count: 0 }}>
          <Form.Item name="name" label="名称" rules={[{ required: true }]}>
            <Input allowClear />
          </Form.Item>
          <Form.Item name="source_type" label="来源">
            <Select options={[{ label: 'manual', value: 'manual' }, { label: 'llm', value: 'llm' }, { label: 'mixed', value: 'mixed' }]} />
          </Form.Item>
          <Form.Item name="sample_count" label="样本数">
            <InputNumber min={0} style={{ width: '100%' }} />
          </Form.Item>
        </Form>
      </Modal>

      <Modal maskClosable={false} title="创建评估集" open={evaluationDatasetOpen} onCancel={() => setEvaluationDatasetOpen(false)} onOk={createEvaluationDataset}>
        <Form form={evalDsForm} layout="vertical" initialValues={{ source_type: 'manual', sample_count: 0, has_full_fields: true }}>
          <Form.Item name="name" label="名称" rules={[{ required: true }]}>
            <Input allowClear />
          </Form.Item>
          <Form.Item name="source_type" label="来源">
            <Select options={[{ label: 'manual', value: 'manual' }, { label: 'llm', value: 'llm' }, { label: 'mixed', value: 'mixed' }]} />
          </Form.Item>
          <Form.Item name="sample_count" label="样本数">
            <InputNumber min={0} style={{ width: '100%' }} />
          </Form.Item>
        </Form>
      </Modal>

      <Modal maskClosable={false} title="评估模型" open={evalOpen} onCancel={() => setEvalOpen(false)} onOk={evaluateModel}>
        <Form form={evalForm} layout="vertical">
          <Form.Item name="dataset_id" label="评估集" rules={[{ required: true }]}>
            <Select options={evalDatasetOptions} placeholder="请选择评估集" />
          </Form.Item>
          <Form.Item name="threshold_intent_f1" label="intent_f1 阈值（可覆盖）">
            <InputNumber min={0} max={1} step={0.01} style={{ width: '100%' }} />
          </Form.Item>
          <Form.Item name="threshold_slot_f1" label="slot_f1 阈值（可覆盖）">
            <InputNumber min={0} max={1} step={0.01} style={{ width: '100%' }} />
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        maskClosable={false}
        title="单条测试"
        open={singleTestOpen}
        onCancel={() => setSingleTestOpen(false)}
        onOk={runSingleTest}
      >
        <Form form={singleTestForm} layout="vertical" initialValues={{ language: 'zh' }}>
          <Form.Item name="utterance" label="测试语句" rules={[{ required: true }]}>
            <Input.TextArea rows={3} allowClear />
          </Form.Item>
          <Form.Item name="language" label="语种">
            <Select options={[{ label: 'zh', value: 'zh' }, { label: 'en', value: 'en' }]} />
          </Form.Item>
          <Form.Item name="expected_intent" label="预期意图(可选)">
            <Input allowClear />
          </Form.Item>
        </Form>
        {singleTestResult && (
          <Card size="small">
            <Text strong>{singleTestResult.summary}</Text>
            <br />
            <Text type="secondary">
              预测意图: {singleTestResult.predicted_intent} / 置信度: {singleTestResult.confidence}
            </Text>
            <Collapse
              style={{ marginTop: 8 }}
              items={[
                {
                  key: 'detail',
                  label: '查看详细结果',
                  children: <pre style={{ margin: 0 }}>{JSON.stringify(singleTestResult.detail, null, 2)}</pre>,
                },
              ]}
            />
          </Card>
        )}
      </Modal>

      <Modal
        maskClosable={false}
        title="评估记录与智能分析"
        width={860}
        open={evalRunsOpen}
        footer={null}
        onCancel={() => setEvalRunsOpen(false)}
      >
        <Table
          rowKey="id"
          pagination={{ pageSize: 5 }}
          dataSource={evalRuns}
          columns={[
            { title: '创建时间', dataIndex: 'created_at' },
            { title: 'intent_f1', render: (_, r) => r?.result_summary?.intent_f1 ?? '-' },
            { title: 'slot_f1', render: (_, r) => r?.result_summary?.slot_f1 ?? '-' },
            { title: '结论', render: (_, r) => r?.analysis?.overall ?? '-' },
            {
              title: '详情',
              render: (_, r) => (
                <Collapse
                  items={[
                    {
                      key: 'a',
                      label: '展开智能分析',
                      children: <pre style={{ margin: 0 }}>{JSON.stringify(r.analysis || {}, null, 2)}</pre>,
                    },
                  ]}
                />
              ),
            },
          ]}
        />
      </Modal>

      <Modal
        maskClosable={false}
        title="发布模型（二次确认）"
        open={publishOpen}
        onCancel={() => setPublishOpen(false)}
        onOk={publishModel}
      >
        <Form form={publishForm} layout="vertical">
          <Form.Item
            name="confirm_publish"
            valuePropName="checked"
            rules={[{ validator: (_, v) => (v ? Promise.resolve() : Promise.reject(new Error('请勾选确认发布'))) }]}
          >
            <Checkbox>我确认将该模型设为当前库的唯一发布模型</Checkbox>
          </Form.Item>
          <Form.Item name="publish_note" label="发布备注（可选）">
            <Input.TextArea rows={3} allowClear placeholder="可留空" />
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        maskClosable={false}
        title={importKind === 'training' ? '导入训练集 Excel' : '导入评估集 Excel'}
        open={importOpen}
        onCancel={() => {
          setImportOpen(false);
          setImportFile(null);
        }}
        onOk={importExcelRows}
      >
        <Form form={importForm} layout="vertical">
          <Form.Item name="dataset_id" label="目标数据集" rules={[{ required: true }]}>
            <Select options={importDatasetOptions} placeholder="请选择数据集" />
          </Form.Item>
          <Form.Item label="Excel 文件">
            <input
              type="file"
              accept=".xlsx,.xls"
              onChange={(e) => setImportFile(e.target.files?.[0] || null)}
            />
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        maskClosable={false}
        title={exportKind === 'training' ? '导出训练样本' : '导出评估样本'}
        open={exportOpen}
        onCancel={() => setExportOpen(false)}
        onOk={exportExcelRows}
      >
        <Form form={exportForm} layout="vertical">
          <Form.Item name="dataset_id" label="选择数据集" rules={[{ required: true }]}>
            <Select options={exportDatasetOptions} placeholder="请选择数据集" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}
